(function(){
'use strict';
/*DATA*/
/*ICONS*/
/*CHARTS*/

/* =============== Helpers base =============== */
const MODULE_NAME='Front de inversiones';
const TIP=t=>' data-tip="'+esc(t)+'"';
const info=t=>'<span class="mk-info" tabindex="0" data-tip="'+esc(t)+'">i</span>';
const okNum=v=>parseFloat(String(v).replace(/[^0-9.\-]/g,''))||0;
function fmtD(ts){return new Date(ts).toLocaleDateString('es-ES',{day:'2-digit',month:'2-digit',year:'numeric'})}
function isoD(ts){const d=new Date(ts);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function fromIso(v){if(!v)return null;const[y,m,d]=v.split('-');return new Date(+y,+m-1,+d,12).getTime()}
const badge=(t,c,w)=>'<span class="mk-badge mk-badge--'+(c||'info')+(w?' mk-badge--wide':'')+'">'+esc(t)+'</span>';
const pcs=v=>(v>=0?'+':'')+pct(v,2);
const fdRow=(l,v)=>'<div class="mk-detail"><span class="mk-detail__label">'+esc(l)+'</span><span class="mk-detail__value">'+(v==null||v===''?'—':v)+'</span></div>';
const alertB=(kind,title,text,close)=>'<div class="mk-alert mk-alert--'+kind+'"><span class="mk-alert__icon">'+ic(kind==='danger'?'alert':kind==='success'?'badge':'info')+'</span><div class="mk-alert__body">'+(title?'<strong>'+esc(title)+'</strong>':'')+text+'</div>'+(close?'<button class="mk-alert__close" aria-label="Cerrar" onclick="this.parentNode.remove()">&times;</button>':'')+'</div>';
const kpiBox=(l,v,cls,tip)=>'<div class="mk-kpi'+(cls?' mk-kpi--'+cls:'')+'"><div class="mk-kpi__l">'+l+(tip?info(tip):'')+'</div><div class="mk-kpi__v">'+v+'</div></div>';
const OPDATE=(()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')})();
const dfac=d=>d===OPDATE?1:1+((hash(d)%21)-10)/200;
const TIP_OP='Fecha operativa. Viene con el día en curso y muestra la foto a ese día: lo del día y lo que siga abierto de días anteriores. Puedes cambiarla para ver otro día; no se deja en blanco, porque una pantalla operativa siempre trabaja sobre un día.';
const perKey=(a,b)=>{const n=(new Date(b)-new Date(a))/864e5;return n<=35?'MTD':n<=300?'YTD':n<=420?'12M':'SI'};
const valC=(v,txt)=>'<span class="'+(v>=0?'pos':'neg')+'">'+txt+'</span>';

/* Campos de fecha */
const opField=v=>fld('Fecha operativa','<div class="mk-datepicker"><input class="mk-input" type="date" name="op" value="'+v+'"></div>',{tip:TIP_OP,name:'op'});
const rangeFields=(d1,d2,ctx,pre)=>{pre=pre||'';return fld('Fecha inicial','<div class="mk-datepicker"><input class="mk-input" type="date" name="'+pre+'d1" value="'+(d1||'')+'"></div>',{tip:'Inicio de '+ctx+'. Déjala en blanco para no limitar desde el principio.',name:pre+'d1'})+fld('Fecha final','<div class="mk-datepicker"><input class="mk-input" type="date" name="'+pre+'d2" value="'+(d2||'')+'"></div>',{tip:'Fin de '+ctx+'. Debe ser igual o posterior a la fecha inicial.',name:pre+'d2'})};
function bindOp(root,st,onChange){const i=$('[name=op]',root);if(!i)return;i.addEventListener('change',()=>{if(!i.value){i.value=st.op||OPDATE;toast('La fecha operativa no se deja en blanco; se restableció el último día válido.','warning','Fecha operativa');return}st.op=i.value;onChange&&onChange()})}
/* Tooltips (capa flotante): aparecen al pasar el cursor o con teclado y se ocultan siempre */
let tipT=null,tipFor=null;
function hideTip(){const tp=$('#mkTip');if(tp)tp.classList.remove('show');tipFor=null;clearTimeout(tipT)}
function showTip(t){const tp=$('#mkTip');if(!tp||!t.dataset.tip)return;tp.textContent=t.dataset.tip;tp.classList.add('show');const r=t.getBoundingClientRect(),w=tp.offsetWidth,h=tp.offsetHeight;let x=Math.max(8,Math.min(innerWidth-w-8,r.left+r.width/2-w/2)),y=r.top-h-8;if(y<8)y=r.bottom+8;tp.style.left=x+'px';tp.style.top=y+'px';tipFor=t;clearTimeout(tipT);tipT=setTimeout(hideTip,6000)}
document.addEventListener('mouseover',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(t){if(t!==tipFor)showTip(t)}else if(tipFor)hideTip()});
document.addEventListener('mouseout',e=>{if(tipFor&&!(e.relatedTarget&&tipFor.contains&&tipFor.contains(e.relatedTarget)))hideTip()});
document.addEventListener('mousemove',e=>{if(tipFor&&(!tipFor.isConnected||!tipFor.contains(e.target)))hideTip()});
document.addEventListener('focusin',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(t&&e.target.matches&&e.target.matches(':focus-visible'))showTip(t)});
document.addEventListener('focusout',hideTip);
['mousedown','keydown','scroll','wheel','touchstart'].forEach(ev=>document.addEventListener(ev,hideTip,true));
window.addEventListener('blur',hideTip);

/* Toast (Sonner) */
function toast(msg,type,title){type=type||'info';const w=$('#mkSonner');if(!w)return;const t=document.createElement('div');t.className='mk-toast mk-toast--'+type;t.innerHTML='<span class="mk-alert__icon">'+ic(type==='danger'?'alert':type==='success'?'badge':'info')+'</span><div class="mk-alert__body">'+(title?'<strong>'+esc(title)+'</strong>':'')+msg+'</div><button class="mk-toast__close" onclick="this.parentNode.remove()">&times;</button>';w.appendChild(t);while(w.children.length>3)w.removeChild(w.firstChild);setTimeout(()=>t.remove(),type==='danger'?9000:4500)}
/* Modal */
function openModal(o){hideTip();const ov=document.createElement('div');ov.className='mk-modal-overlay open';ov.style.zIndex=o.z||70;ov.innerHTML='<div class="mk-modal '+(o.cls||'')+'" role="dialog" aria-modal="true"><div class="mk-modal__head'+(o.brand?' mk-modal__head--brand':'')+'">'+(o.brand?'<span>'+esc(o.title)+'</span>':esc(o.title))+'<button class="mk-sidebar__close" data-x aria-label="Cerrar" style="position:static">&times;</button></div>'+(o.sub?'<div class="mk-modal__sub">'+o.sub+'</div>':'')+'<div class="mk-modal__body">'+(o.body||'')+'</div><div class="mk-modal__foot">'+(o.foot||'')+'</div></div>';document.body.appendChild(ov);const close=()=>{ov.remove();o.onClose&&o.onClose()};$('[data-x]',ov).addEventListener('click',close);ov.addEventListener('mousedown',e=>{if(e.target===ov&&!o.sticky)close()});ov.addEventListener('keydown',e=>{if(e.key==='Escape')close()});return {el:ov,close,body:$('.mk-modal__body',ov),foot:$('.mk-modal__foot',ov)}}
function mkConfirm(o){const m=openModal({title:o.title||'Confirmar',body:alertB(o.danger?'danger':'warning','',o.message||'¿Deseas continuar?'),foot:'<button class="mk-btn mk-btn--secondary" data-c>'+(o.cancelText||'Cancelar')+'</button><button class="mk-btn'+(o.danger?' mk-btn--danger-solid':'')+'" data-ok>'+(o.confirmText||'Confirmar')+'</button>'});$('[data-c]',m.el).addEventListener('click',m.close);$('[data-ok]',m.el).addEventListener('click',()=>{m.close();o.onConfirm&&o.onConfirm()});$('[data-c]',m.el).focus()}

/* =============== Campos de formulario (nativos, como la Plataforma) =============== */
const fld=(label,ctrl,o)=>{o=o||{};return '<div class="mk-field'+(o.cls?' '+o.cls:'')+'" data-f="'+(o.name||'')+'"><label class="mk-label"><span>'+esc(label)+'</span>'+(o.req?'<span class="req">*</span>':'')+(o.tip?info(o.tip):'')+'</label>'+ctrl+'<div class="mk-help mk-help--error" hidden></div></div>'};
const inpF=(name,label,val,o)=>{o=o||{};return fld(label,'<input class="mk-input" name="'+name+'" type="'+(o.type||'text')+'" value="'+esc(val==null?'':val)+'" placeholder="'+esc(o.ph||'')+'" '+(o.ro?'readonly ':'')+(o.attrs||'')+'>',Object.assign({name},o))};
const selF=(name,label,opts,val,o)=>{o=o||{};return fld(label,'<div class="mk-combobox"><select class="mk-select" name="'+name+'"><option value="">'+(o.ph||'Seleccionar')+'</option>'+opts.map(x=>{const v=typeof x==='object'?x.value:x,l=typeof x==='object'?x.label:x;return '<option value="'+esc(v)+'"'+(String(v)===String(val)?' selected':'')+'>'+esc(l)+'</option>'}).join('')+'</select></div>',Object.assign({name},o))};
const dateF=(name,label,ts,o)=>fld(label,'<div class="mk-datepicker"><input class="mk-input" type="date" name="'+name+'" value="'+(ts?isoD(ts):'')+'"></div>',Object.assign({name},o||{}));
const radiosF=(name,label,opts,val,o)=>fld(label,'<div class="mk-radiorow">'+opts.map(x=>'<label class="mk-radio"><input type="radio" name="'+name+'" value="'+esc(x)+'"'+(x===val?' checked':'')+'> '+esc(x)+'</label>').join('')+'</div>',Object.assign({name},o||{}));
const rv=(f,n)=>{const e=$('[name="'+n+'"]:checked',f);return e?e.value:''};
function acF(name,label,ph,val,o){return fld(label,'<div class="ac-wrap" style="position:relative"><input class="mk-input" name="'+name+'" value="'+esc(val||'')+'" placeholder="'+esc(ph)+'" autocomplete="off"></div>',Object.assign({name},o||{}))}
function bindAC(f,name,list){const inp=$('[name="'+name+'"]',f),w=inp.parentElement;inp.addEventListener('input',()=>{$$('.ac-list',w).forEach(x=>x.remove());const q=inp.value.toLowerCase();if(!q)return;const m=list.filter(x=>x.toLowerCase().includes(q)).slice(0,8);if(!m.length)return;const ul=document.createElement('div');ul.className='ac-list';ul.innerHTML=m.map(x=>'<div class="opt">'+esc(x)+'</div>').join('');ul.addEventListener('click',e=>{const o=e.target.closest('.opt');if(o){inp.value=o.textContent;ul.remove();clearErr(inp)}});w.appendChild(ul)})}
document.addEventListener('click',e=>{if(!e.target.closest('.ac-wrap'))$$('.ac-list').forEach(x=>x.remove());if(!e.target.closest('.mk-multiselect'))$$('.mk-multiselect.open').forEach(x=>x.classList.remove('open'))});
function errOn(f,name,msg){const c=$('[name="'+name+'"]',f);if(!c)return;const box=c.closest('.mk-field');if(c.classList)c.classList.add('mk-input--error');const h=$('.mk-help--error',box);if(h){h.textContent=msg||'Campo obligatorio';h.hidden=false}}
function clearErr(c){const box=c.closest&&c.closest('.mk-field');if(!box)return;$$('.mk-input--error',box).forEach(x=>x.classList.remove('mk-input--error'));const h=$('.mk-help--error',box);if(h)h.hidden=true}
function bindClear(f){f.addEventListener('input',e=>clearErr(e.target));f.addEventListener('change',e=>clearErr(e.target))}
const mask={qty:v=>(parseFloat(String(v).replace(/[^0-9.]/g,''))||0).toFixed(2),rate:v=>(parseFloat(String(v).replace(/[^0-9.]/g,''))||0).toFixed(2)+'%',money:v=>'$'+(parseFloat(String(v).replace(/[^0-9.]/g,''))||0).toFixed(2)};
function bindMask(f,name,fn){const i=$('[name="'+name+'"]',f);if(i)i.addEventListener('blur',()=>{i.value=fn(i.value)})}

/* =============== Tabla de datos (DataTable de la Plataforma) =============== */
/* Convención de la Plataforma: Acciones como primera columna y Estado al final. */
function DataTable(host,o){
 const st={q:'',page:1,sort:o.defaultSort||null,dir:o.defaultDir||1,f:{},d1:'',d2:'',op:OPDATE};
 const rowsAll=()=>o.rows(st);
 function filtered(){let rows=rowsAll();
  (o.filters||[]).forEach(fl=>{const v=st.f[fl.id];if(v)rows=rows.filter(r=>String(fl.get(r))===v)});
  if(o.dateRange){const a=st.d1?new Date(st.d1+'T00:00:00').getTime():null,b=st.d2?new Date(st.d2+'T23:59:59').getTime():null;rows=rows.filter(r=>{const t=r[o.dateRange.k];return (!a||t>=a)&&(!b||t<=b)})}
  if(st.q){const q=st.q.toLowerCase();rows=rows.filter(r=>o.cols.some(c=>String(c.txt?c.txt(r):(c.fmt?c.fmt(r[c.k]):r[c.k])).toLowerCase().includes(q)))}
  if(st.sort){const c=o.cols.find(c=>c.h===st.sort);rows=rows.slice().sort((a,b)=>{const x=c.sv?c.sv(a):a[c.k],y=c.sv?c.sv(b):b[c.k];return (x>y?1:x<y?-1:0)*st.dir})}return rows}
 function render(){
  const all=filtered(),ps=o.pageSize||10,pages=o.noPage?1:Math.max(1,Math.ceil(all.length/ps));if(st.page>pages)st.page=pages;
  const rows=o.noPage?all:all.slice((st.page-1)*ps,st.page*ps);
  const hasActs=!!o.acts;
  const th=(hasActs?'<th>Acciones</th>':'')+o.cols.map(c=>'<th'+(c.sortable?' style="cursor:pointer" data-h="'+esc(c.h)+'"':'')+'>'+(c.tip?'<span class="mk-th-info">'+esc(c.h)+info(c.tip)+'</span>':esc(c.h))+(st.sort===c.h?' <span style="font-size:11px">'+(st.dir>0?'▲':'▼')+'</span>':'')+'</th>').join('')+(o.estado?'<th>Estado</th>':'');
  const body=rows.length?rows.map((r,i)=>'<tr data-i="'+i+'">'+(hasActs?'<td>'+actsHTML(o.acts(r),i)+'</td>':'')+o.cols.map(c=>'<td'+(c.cls?' class="'+c.cls+'"':'')+'>'+(c.html?c.html(r):esc(c.fmt?c.fmt(r[c.k]):r[c.k]))+'</td>').join('')+(o.estado?'<td>'+o.estado(r)+'</td>':'')+'</tr>').join(''):'<tr><td colspan="'+(o.cols.length+(hasActs?1:0)+(o.estado?1:0))+'"><div class="mk-empty">'+(o.empty||'Sin resultados')+'</div></td></tr>';
  const tot=o.totals&&rows.length?'<tr style="font-weight:700;border-top:2px solid var(--mk-primary)">'+(hasActs?'<td></td>':'')+o.totals(all).map(t=>'<td>'+t+'</td>').join('')+'</tr>':'';
  let pager='';if(!o.noPage&&pages>1){pager='<div class="mk-pagination"><span class="mk-pagination__info">Página '+st.page+' de '+pages+'</span><button data-pp="1" aria-label="Primera página"'+(st.page===1?' disabled':'')+'>«</button><button data-pp="'+(st.page-1)+'" aria-label="Página anterior"'+(st.page===1?' disabled':'')+'>‹</button>';for(let p=1;p<=pages;p++)pager+='<button data-pp="'+p+'" class="'+(p===st.page?'active':'')+'">'+p+'</button>';pager+='<button data-pp="'+(st.page+1)+'" aria-label="Página siguiente"'+(st.page===pages?' disabled':'')+'>›</button><button data-pp="'+pages+'" aria-label="Última página"'+(st.page===pages?' disabled':'')+'>»</button></div>'}
  const exp=o.noTools?'':'<div class="mk-export" style="margin-left:auto"><button class="mk-btn mk-btn--secondary" data-x="csv"'+TIP('Descargar los datos filtrados en CSV')+'>'+ic('clouddl')+'CSV</button><button class="mk-btn mk-btn--excel" data-x="xls"'+TIP('Descargar los datos filtrados en Excel')+'>'+ic('clouddl')+'Excel</button></div>';
  const filt=o.noFilters?'':'<div class="mk-tplfilters mk-filters"><div class="mk-field mk-field--search"><label class="mk-label">Buscar</label><input class="mk-input" data-q placeholder="'+esc(o.searchPh||'Buscar...')+'" value="'+esc(st.q)+'"></div>'+(o.opDate?opField(st.op):'')+(o.dateRange?rangeFields(st.d1,st.d2,'la '+o.dateRange.label):'')+(o.filters||[]).map(fl=>'<div class="mk-field"><label class="mk-label">'+esc(fl.label)+'</label><div class="mk-combobox"><select class="mk-select" data-fl="'+fl.id+'"><option value="">Todos</option>'+fl.opts().map(v=>'<option'+(st.f[fl.id]===v?' selected':'')+'>'+esc(v)+'</option>').join('')+'</select></div></div>').join('')+'<button class="mk-btn mk-btn--secondary" data-clear>Limpiar</button>'+exp+'</div>';
  host.innerHTML=(o.kpis&&!o.noFilters?'<div class="mk-kpis">'+o.kpis(filtered()).map(k=>kpiBox(k[0],k[1],k[2])).join('')+'</div>':'')+filt+'<div class="mk-card">'+(o.noTools||!o.noFilters?'':'<div class="mk-datatable__toolbar"><div class="mk-search"></div>'+exp+'</div>')+'<div class="mk-tablewrap"><table class="mk-table"><thead><tr>'+th+'</tr></thead><tbody>'+body+tot+'</tbody></table></div>'+(o.noFoot?'':'<div class="mk-datatable__foot"><span class="mk-rowinfo">Mostrando '+rows.length+' de '+all.length+' '+(o.noun||'registros')+'</span>'+pager+'</div>')+'</div>';
  const q=$('[data-q]',host);if(q)q.addEventListener('input',()=>{st.q=q.value;st.page=1;const p=q.selectionStart;render();const n=$('[data-q]',host);n.focus();n.setSelectionRange(p,p)});
  $$('[data-fl]',host).forEach(s=>s.addEventListener('change',()=>{st.f[s.dataset.fl]=s.value;st.page=1;render()}));
  $$('[name=d1],[name=d2]',host).forEach(i=>i.addEventListener('change',()=>{const n=i.name,prev=st[n];st[n]=i.value;if(st.d1&&st.d2&&st.d1>st.d2){st[n]=prev;toast('La fecha inicial no puede ser posterior a la final.','warning','Rango de fechas');render();return}st.page=1;render()}));
  const opi=$('[name=op]',host);if(opi)opi.addEventListener('change',()=>{if(!opi.value){opi.value=st.op;toast('La fecha operativa no se deja en blanco; se restableció el último día válido.','warning','Fecha operativa');return}st.op=opi.value;st.page=1;render()});
  const cl=$('[data-clear]',host);if(cl)cl.addEventListener('click',()=>{st.q='';st.f={};st.d1='';st.d2='';st.page=1;render()});
  $$('th[data-h]',host).forEach(t=>t.addEventListener('click',()=>{if(st.sort===t.dataset.h)st.dir*=-1;else{st.sort=t.dataset.h;st.dir=1}render()}));
  $$('[data-pp]',host).forEach(b=>b.addEventListener('click',()=>{st.page=+b.dataset.pp;render()}));
  $$('[data-x]',host).forEach(b=>b.addEventListener('click',()=>{const a=filtered(),name=(o.fileName||'datos')+'-'+new Date().toISOString().slice(0,10);if(!a.length){toast('No hay datos para descargar.','warning');return}const heads=o.cols.map(c=>c.h).concat(o.estado?['Estado']:[]),rowsX=a.map(r=>o.cols.map(c=>xvCell(c,r)).concat(o.estado?[htmlTxt(o.estado(r))]:[]));exportTable(name,b.dataset.x==='csv'?'csv':'xlsx',heads,rowsX,o.fileName||'Datos');toast(a.length+' registros exportados.','success','Descarga lista')}));
  $$('[data-act]',host).forEach(b=>b.addEventListener('click',()=>{const tr=b.closest('tr');o.onAct&&o.onAct(b.dataset.act,rows[+tr.dataset.i])}));
 }
 render();return {render,state:st};
}
/* Iconos de acción: Ver Detalle, Editar, Inactivar/Activar/Anular */
const AI={ver:['mk-iconbtn--view','eye','Ver detalle'],edit:['mk-iconbtn--edit','pen','Editar'],off:['mk-iconbtn--delete','trash','Inactivar'],on:['mk-iconbtn--ok','check','Activar'],anular:['mk-iconbtn--delete','trash','Anular'],gen:['','doc','Generar'],clone:['','copy','Clonar']};
function actsHTML(list){return '<div class="mk-acts">'+list.map(a=>{const d=AI[a[0]];return '<button class="mk-iconbtn '+d[0]+'" data-act="'+a[0]+'"'+TIP(a[1]||d[2])+' aria-label="'+esc(a[1]||d[2])+'">'+ic(d[1])+'</button>'}).join('')+'</div>'}

/* =============== Estructura de página =============== */
function sectionHTML(meta,title,help,o){o=o||{};const backTo=meta&&meta.grp?meta.grp.label:null;return '<div class="mk-section"><div class="mk-headerpage"><div><h1>'+esc(title)+'</h1>'+(help?'<div class="mk-help">'+esc(help)+'</div>':'')+'</div><div style="display:flex;gap:10px;align-items:center">'+(backTo?'<button class="mk-iconbtn mk-iconbtn--dark" data-back'+TIP('Volver a '+backTo)+' aria-label="Volver a '+esc(backTo)+'">'+ic('back')+'</button>':'')+(o.actions||'')+'</div></div><div id="pg"></div></div>'}
function mountPage(view,meta,title,help,o){view.innerHTML=sectionHTML(meta,title,help,o);const b=$('[data-back]',view);if(b)b.addEventListener('click',()=>go(meta.grp.home));return $('#pg',view)}
const BTN_NEW=lbl=>'<button class="mk-btn" data-new>'+ic('plus')+esc(lbl||'Nuevo')+'</button>';

/* ---------- Página de listado con Crear / Ver / Editar / Inactivar ---------- */
function crudPage(cfg){
 return function(view,meta){
  const pg=mountPage(view,meta,cfg.title,cfg.help,{actions:cfg.noNew?'':BTN_NEW(cfg.newLabel)});
  if(cfg.apoya)pg.insertAdjacentHTML('beforebegin',apoyaHTML(cfg.apoya));
  if(cfg.mass){pg.insertAdjacentHTML('beforebegin','<div class="mk-tabs mk-mb" role="tablist" id="rtabs"><button class="mk-tab active" data-rt="0" role="tab">Registro Individual</button><button class="mk-tab" data-rt="1" role="tab">Carga Masiva</button></div>');const me=document.createElement('div');me.id='mass';me.hidden=true;me.innerHTML=massHTML(cfg.mass);pg.after(me);bindMass(me,cfg.mass,()=>repaint());$$('[data-rt]',view).forEach(b=>b.addEventListener('click',()=>{const m=b.dataset.rt==='1';$$('[data-rt]',view).forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-selected',x===b)});pg.hidden=m;me.hidden=!m;const nb=$('[data-new]',view);if(nb)nb.hidden=m}))}
  let table;
  const repaint=()=>table.render();
  const detail=r=>{const m=openModal({title:cfg.detailTitle?cfg.detailTitle(r):'Detalle',body:(cfg.badges?'<div style="margin-bottom:10px">'+cfg.badges(r)+'</div>':'')+'<div class="mk-formgrid">'+cfg.detail(r).map(x=>fdRow(x[0],x[1])).join('')+'</div>',foot:(cfg.acts(r).some(a=>a[0]==='edit')?'<button class="mk-btn mk-btn--outline" data-e>'+ic('pen')+'Editar</button>':'')+'<button class="mk-btn mk-btn--secondary" data-c>Cerrar</button>'});$('[data-c]',m.el).addEventListener('click',m.close);const e=$('[data-e]',m.el);if(e)e.addEventListener('click',()=>{m.close();form(r)})};
  const form=row=>{
   const f=cfg.form(row),m=openModal({brand:true,cls:'mk-modal--form',title:(row?'Editar ':(/^La /.test(cfg.entityArt||'')?'Nueva ':'Nuevo '))+cfg.entity,sticky:true,body:'<form novalidate>'+f.html+'</form>',foot:'<button class="mk-btn mk-btn--secondary" data-c>Cancelar</button><button class="mk-btn" data-s>'+ic('save')+'Guardar</button>'});
   const fm=$('form',m.el);f.bind&&f.bind(fm);bindClear(fm);let dirty=false;fm.addEventListener('input',()=>dirty=true);fm.addEventListener('change',()=>dirty=true);
   const cancel=()=>{if(dirty){mkConfirm({title:'¿Descartar cambios?',message:'Tienes cambios sin guardar. Si cierras ahora se perderán.',confirmText:'Descartar',danger:true,onConfirm:m.close})}else m.close()};
   $('[data-c]',m.el).addEventListener('click',cancel);$('[data-x]',m.el).addEventListener('click',e=>{e.stopImmediatePropagation();cancel()},true);
   const save=()=>{$$('.mk-help--error',fm).forEach(h=>h.hidden=true);$$('.mk-input--error',fm).forEach(x=>x.classList.remove('mk-input--error'));const res=f.read(fm);if(!res.ok){(res.errs||[]).forEach(e=>errOn(fm,e[0],e[1]));toast('Completa: '+(res.errs||[]).map(e=>e[2]||e[0]).join(', ')+'.','warning','Faltan datos');return}
    const rv2=openModal({title:'Revisa '+cfg.entityArt.toLowerCase(),z:80,sticky:true,sub:'Verifica la información antes de guardar.',body:'<div class="mk-formgrid">'+cfg.review(res.data).map(x=>fdRow(x[0],esc(x[1]))).join('')+'</div>',foot:'<button class="mk-btn mk-btn--secondary" data-b>Volver a editar</button><button class="mk-btn" data-ok>'+ic('check')+'Confirmar y guardar</button>'});
    $('[data-b]',rv2.el).addEventListener('click',rv2.close);$('[data-ok]',rv2.el).addEventListener('click',()=>{const btn=$('[data-ok]',rv2.el);btn.classList.add('is-loading');setTimeout(()=>{cfg.onSave(res.data,row);rv2.close();m.close();repaint();{const fem=/^La /.test(cfg.entityArt);toast(row?cfg.entityArt+(fem?' actualizada':' actualizado')+' correctamente.':cfg.entityArt+(fem?' creada':' creado')+' correctamente.','success',row?'Cambios guardados':(fem?'Registro creado':'Registro creado'))}},350)})};
   $('[data-s]',m.el).addEventListener('click',save);
  };
  const toggle=r=>{const t=cfg.toggle(r);mkConfirm({title:t.title,danger:t.danger,message:t.message+(t.danger&&cfg.apoya?'<div class="mk-help" style="margin-top:6px">Módulos conectados: '+cfg.apoya.map(a=>a[0]).join(', ')+'.</div>':''),confirmText:t.confirm,onConfirm:()=>{t.apply();repaint();toast(t.done,t.danger?'warning':'success')}})};
  const tbHost=document.createElement('div');pg.appendChild(tbHost);table=DataTable(tbHost,{cols:cfg.cols,rows:cfg.rows,filters:cfg.filters,dateRange:cfg.dateRange,opDate:cfg.opDate,acts:cfg.acts,estado:cfg.estado,kpis:cfg.kpis,pageSize:10,fileName:cfg.fileName,defaultSort:cfg.defaultSort,defaultDir:cfg.defaultDir,searchPh:cfg.searchPh,noun:cfg.noun,
   onAct:(a,r)=>{if(a==='ver')detail(r);else if(a==='edit')form(r);else if(a==='off'||a==='on'||a==='anular')toggle(r);else cfg.onAct&&cfg.onAct(a,r,repaint)}});
  const nb=$('[data-new]',view);if(nb)nb.addEventListener('click',()=>form(null));
  if(cfg.extra)cfg.extra(pg,()=>repaint());
 };
}
const ESTADO_ORD={R:['Registrada','info'],C:['Complementación','warning'],F:['Finalizada','success'],A:['Anulada','danger']};
const estOrd=r=>badge(ESTADO_ORD[r.estatus][0],ESTADO_ORD[r.estatus][1],true);
const actsOrd=r=>{const a=[['ver']];if(r.estatus==='R'||r.estatus==='C'){a.push(['edit']);a.push(['anular','Anular orden'])}return a};
const togOrd=(noun)=>r=>({title:'Anular '+noun,danger:true,message:'Vas a anular '+noun+' de <b>'+esc(r.port||r.cliente)+'</b> sobre <b>'+esc(r.instr)+'</b>. Esta acción no se puede deshacer.',confirm:'Anular',done:'Orden anulada correctamente.',apply:()=>{r.estatus='A'}});
const kpiOrd=rows=>[['Registradas',rows.filter(r=>r.estatus==='R').length,'b'],['En complementación',rows.filter(r=>r.estatus==='C').length,'y'],['Finalizadas',rows.filter(r=>r.estatus==='F').length,'g'],['Anuladas',rows.filter(r=>r.estatus==='A').length,'r']];
const filtOrd=[{id:'tipo',label:'Tipo',opts:()=>['COMPRA','VENTA'],get:r=>r.tipo},{id:'est',label:'Estado',opts:()=>Object.values(ESTADO_ORD).map(x=>x[0]),get:r=>ESTADO_ORD[r.estatus][0]}];
const side=t=>badge(t,t==='COMPRA'?'info':'danger');

/* ===== Carga masiva: lectura de CSV y Excel, validación y carga ===== */
const normH=s=>String(s==null?'':s).normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const findCI=(arr,v)=>arr.find(x=>normH(x)===normH(v));
const numP=v=>{let t=String(v==null?'':v).trim().replace(/\s/g,'');if(!t)return null;if(t.includes(',')&&!t.includes('.'))t=t.replace(',','.');else t=t.replace(/,/g,'');const n=parseFloat(t);return isNaN(n)?NaN:n};
const isoP=v=>{v=String(v==null?'':v).trim();if(!v)return null;let m=v.match(/^(\d{4})-(\d{2})-(\d{2})/);if(m)return m[1]+'-'+m[2]+'-'+m[3];m=v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);if(m)return m[3]+'-'+m[2].padStart(2,'0')+'-'+m[1].padStart(2,'0');if(/^\d{5}(\.\d+)?$/.test(v)){const d=new Date(Math.round((+v-25569)*864e5));return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+String(d.getUTCDate()).padStart(2,'0')}return undefined};
const _crcT=(()=>{const t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
const crc32=b=>{let c=0xFFFFFFFF;for(let i=0;i<b.length;i++)c=_crcT[(c^b[i])&255]^(c>>>8);return (c^0xFFFFFFFF)>>>0};
function zipStore(files){const enc=new TextEncoder(),parts=[],cd=[];let off=0;
 files.forEach(f=>{const nm=enc.encode(f.name),data=enc.encode(f.data),crc=crc32(data);
  const lh=new DataView(new ArrayBuffer(30));lh.setUint32(0,0x04034b50,true);lh.setUint16(4,20,true);lh.setUint16(6,0x0800,true);lh.setUint16(12,0x21,true);lh.setUint32(14,crc,true);lh.setUint32(18,data.length,true);lh.setUint32(22,data.length,true);lh.setUint16(26,nm.length,true);
  parts.push(new Uint8Array(lh.buffer),nm,data);
  const ch=new DataView(new ArrayBuffer(46));ch.setUint32(0,0x02014b50,true);ch.setUint16(4,20,true);ch.setUint16(6,20,true);ch.setUint16(8,0x0800,true);ch.setUint16(14,0x21,true);ch.setUint32(16,crc,true);ch.setUint32(20,data.length,true);ch.setUint32(24,data.length,true);ch.setUint16(28,nm.length,true);ch.setUint32(42,off,true);
  cd.push(new Uint8Array(ch.buffer),nm);off+=30+nm.length+data.length});
 const cdSize=cd.reduce((a,p)=>a+p.length,0),end=new DataView(new ArrayBuffer(22));end.setUint32(0,0x06054b50,true);end.setUint16(8,files.length,true);end.setUint16(10,files.length,true);end.setUint32(12,cdSize,true);end.setUint32(16,off,true);
 const all=parts.concat(cd,[new Uint8Array(end.buffer)]),out=new Uint8Array(all.reduce((a,p)=>a+p.length,0));let o=0;all.forEach(p=>{out.set(p,o);o+=p.length});return out}
/* ===== Exportes y libros de Excel (.xlsx real, con estilos) ===== */
const colName=i=>{let s='';i++;while(i>0){const r=(i-1)%26;s=String.fromCharCode(65+r)+s;i=Math.floor((i-1)/26)}return s};
const colL=colName;
const xe=v=>String(v==null?'':v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const XL_HEAD='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const XL_STYLES=XL_HEAD+'<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="165" formatCode="dd/mm/yyyy"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF6A1B9A"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="10" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
const xlSerial=ts=>{const d=new Date(ts);return Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/864e5+25569};
const cellPlain=c=>c&&typeof c==='object'?(c.d!=null?fmtD(c.d):(c.s===4?pct(c.n,2):f2(c.n))):String(c==null?'':c);
function sheetXml2(sh){
 const rows=sh.rows,nc=rows.reduce((a,r)=>Math.max(a,r.length),1);
 const widths=[];for(let c=0;c<nc;c++){let w=8;rows.slice(0,200).forEach(r=>{const t=r[c]==null?'':cellPlain(r[c]);w=Math.max(w,Math.min(54,String(t).length+3))});widths.push(w)}
 const cols='<cols>'+widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join('')+'</cols>';
 const cell=(v,ri,ci)=>{const ref=colName(ci)+(ri+1);
  if(v!==null&&typeof v==='object'){if(v.d!=null)return '<c r="'+ref+'" s="3"><v>'+xlSerial(v.d)+'</v></c>';if(isFinite(v.n))return '<c r="'+ref+'" s="'+(v.s||2)+'"><v>'+v.n+'</v></c>';v=''}
  return '<c r="'+ref+'" t="inlineStr"'+(sh.header&&ri===0?' s="1"':'')+'><is><t xml:space="preserve">'+xe(v)+'</t></is></c>'};
 const data=rows.map((row,ri)=>'<row r="'+(ri+1)+'">'+row.map((v,ci)=>cell(v,ri,ci)).join('')+'</row>').join('');
 const view=sh.header?'<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft"/></sheetView></sheetViews>':'<sheetViews><sheetView workbookViewId="0"/></sheetViews>';
 return XL_HEAD+'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'+view+'<sheetFormatPr defaultRowHeight="15"/>'+cols+'<sheetData>'+data+'</sheetData>'+(sh.filter&&rows.length>1?'<autoFilter ref="A1:'+colName(nc-1)+rows.length+'"/>':'')+(sh.dv||'')+'</worksheet>';
}
function buildBook(sheets){
 const n=sheets.length,REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
 const nm=s=>String(s).replace(/[\[\]:*?\/\\]/g,' ').slice(0,31)||'Hoja';
 return zipStore([
  {name:'[Content_Types].xml',data:XL_HEAD+'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'+sheets.map((s,i)=>'<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('')+'<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'},
  {name:'_rels/.rels',data:XL_HEAD+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+REL+'/officeDocument" Target="xl/workbook.xml"/></Relationships>'},
  {name:'xl/workbook.xml',data:XL_HEAD+'<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="'+REL+'"><sheets>'+sheets.map((s,i)=>'<sheet name="'+xe(nm(s.name))+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join('')+'</sheets></workbook>'},
  {name:'xl/_rels/workbook.xml.rels',data:XL_HEAD+'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((s,i)=>'<Relationship Id="rId'+(i+1)+'" Type="'+REL+'/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join('')+'<Relationship Id="rId'+(n+1)+'" Type="'+REL+'/styles" Target="styles.xml"/></Relationships>'},
  {name:'xl/styles.xml',data:XL_STYLES}
 ].concat(sheets.map((s,i)=>({name:'xl/worksheets/sheet'+(i+1)+'.xml',data:sheetXml2(s)}))));
}
const XLSX_MIME='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
function exportTable(base,fmt,headers,rows,sheet){
 if(fmt==='csv'){const q=v=>'"'+String(v).replace(/"/g,'""')+'"',tx=c=>cellPlain(c).replace(/^\+(?=\d)/,'');
  download(base+'.csv','﻿'+[headers.map(q).join(';')].concat(rows.map(r=>r.map(c=>q(tx(c))).join(';'))).join('\r\n'),'text/csv;charset=utf-8')}
 else download(base+'.xlsx',buildBook([{name:sheet||'Datos',rows:[headers].concat(rows),header:true,filter:true}]),XLSX_MIME);
}
const htmlTxt=v=>String(v==null?'':v).replace(/<[^>]*>/g,' ').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&').replace(/\s+/g,' ').trim();
function cellTxt(c,r){if(c.txt)return c.txt(r);if(c.fmt)return c.fmt(r[c.k]);if(c.html)return c.html(r);return r[c.k]}
function xvCell(c,r){
 if(c.num)return {n:c.num(r),s:2};
 const raw=c.k!==undefined?r[c.k]:undefined;
 if(!c.txt&&typeof raw==='number'&&isFinite(raw)){if(c.fmt===f0||c.fmt===f1||c.fmt===f2||c.fmt===f3||c.fmt===money)return {n:raw,s:2};if(c.fmt===dstr||c.fmt===fmtD)return {d:raw}}
 return htmlTxt(cellTxt(c,r));
}
function buildXlsx(m,rows){
 const head=m.cols.map(c=>c[0]),ej=rows||[m.ej()],lists=[];
 m.lists.forEach((fn,ci)=>{if(fn)lists.push({ci,name:head[ci],vals:fn()})});
 const dv=lists.length?'<dataValidations count="'+lists.length+'">'+lists.map((l,k)=>'<dataValidation type="list" allowBlank="1" showErrorMessage="1" sqref="'+colName(l.ci)+'2:'+colName(l.ci)+'1000"><formula1>Listas!$'+colName(k)+'$2:$'+colName(k)+'$'+(l.vals.length+1)+'</formula1></dataValidation>').join('')+'</dataValidations>':'';
 const maxL=lists.reduce((a,l)=>Math.max(a,l.vals.length),0),listRows=[lists.map(l=>l.name)];for(let i=0;i<maxL;i++)listRows.push(lists.map(l=>l.vals[i]==null?'':l.vals[i]));
 const inst=[['Campo','Obligatorio','Valores permitidos','Ejemplo']].concat(m.cols.map(c=>[c[0],c[1]?'Sí':'No',loc(c[2]),loc(c[3])]));
 return buildBook([{name:'Estructura',rows:[head].concat(ej),header:true,dv},{name:'Instrucciones',rows:inst,header:true},{name:'Listas',rows:listRows,header:true}]);
}
function demoCsv(m){const q=v=>'"'+String(v).replace(/"/g,'""')+'"';return '﻿'+[m.cols.map(c=>q(c[0])).join(';')].concat(m.demo().map(r=>r.map(q).join(';'))).join('\r\n')}

async function inflateRaw(u8){const ds=new DecompressionStream('deflate-raw');return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(ds)).arrayBuffer())}
async function unzip(buf){const u=new Uint8Array(buf),dv=new DataView(buf);let e=u.length-22;while(e>=0&&dv.getUint32(e,true)!==0x06054b50)e--;if(e<0)throw new Error('no es un archivo Excel válido');const n=dv.getUint16(e+10,true);let p=dv.getUint32(e+16,true);const out={},dec=new TextDecoder();
 for(let i=0;i<n;i++){const meth=dv.getUint16(p+10,true),cs=dv.getUint32(p+20,true),nl=dv.getUint16(p+28,true),el=dv.getUint16(p+30,true),cl=dv.getUint16(p+32,true),lo=dv.getUint32(p+42,true),name=dec.decode(u.subarray(p+46,p+46+nl)),lnl=dv.getUint16(lo+26,true),lel=dv.getUint16(lo+28,true),st=lo+30+lnl+lel,raw=u.subarray(st,st+cs);out[name]=meth===0?raw:await inflateRaw(raw);p+=46+nl+el+cl}return out}
async function readXlsx(file){const z=await unzip(await file.arrayBuffer()),dec=new TextDecoder(),X=n=>z[n]?new DOMParser().parseFromString(dec.decode(z[n]),'application/xml'):null;
 const wb=X('xl/workbook.xml'),rels=X('xl/_rels/workbook.xml.rels');if(!wb||!rels)throw new Error('no es un archivo Excel válido');
 const first=wb.getElementsByTagName('sheet')[0],rid=first.getAttribute('r:id')||first.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id'),rel=[...rels.getElementsByTagName('Relationship')].find(r=>r.getAttribute('Id')===rid);
 let target=rel.getAttribute('Target').replace(/^\//,'');if(!target.startsWith('xl/'))target='xl/'+target;
 const ss=X('xl/sharedStrings.xml'),shared=ss?[...ss.getElementsByTagName('si')].map(si=>[...si.getElementsByTagName('t')].map(t=>t.textContent).join('')):[],sh=X(target),rows=[];
 [...sh.getElementsByTagName('row')].forEach(r=>{const arr=[];[...r.getElementsByTagName('c')].forEach(c=>{const ref=c.getAttribute('r'),ci=ref.replace(/\d+/g,'').split('').reduce((a,ch)=>a*26+ch.charCodeAt(0)-64,0)-1,t=c.getAttribute('t');let v='';if(t==='s'){const ve=c.getElementsByTagName('v')[0];v=ve?shared[+ve.textContent]:''}else if(t==='inlineStr'){v=[...c.getElementsByTagName('t')].map(x=>x.textContent).join('')}else{const ve=c.getElementsByTagName('v')[0];v=ve?ve.textContent:''}arr[ci]=v});rows.push(Array.from(arr,x=>x==null?'':String(x).trim()))});
 return rows}
function parseCSV(t){t=t.replace(/^﻿/,'');const L=t.split(/\r?\n/).filter(x=>x.trim());if(!L.length)return[];const d=(L[0].match(/;/g)||[]).length>(L[0].match(/,/g)||[]).length?';':',';return L.map(l=>{const out=[];let cur='',q=false;for(let i=0;i<l.length;i++){const ch=l[i];if(q){if(ch==='"'&&l[i+1]==='"'){cur+='"';i++}else if(ch==='"')q=false;else cur+=ch}else if(ch==='"')q=true;else if(ch===d){out.push(cur);cur=''}else cur+=ch}out.push(cur);return out.map(x=>x.trim())})}
const VI_LIST=()=>Array.from(new Set(VI_ORDERS.map(o=>o.instr).concat(LOCL(['FALABELLA','SURA','GRUPOSURA','NUTRESA','ECOPETROL','CELSIA','CEMARGOS','BOGOTA','BVC','BSANTANDER']))));
const CALIFS=['AAA','AA+','AA','AA-','A','A-','BBB'];
const sv=x=>String(x==null?'':x);
const MASS={
 fixed:{id:'fixed',nombre:'Órdenes de Renta Fija',cols:[['Portafolio',1,'Nombre exacto del maestro de Portafolios','FIC RENTA FIJA'],['Tipo',1,'COMPRA o VENTA','COMPRA'],['Instrumento',1,'Nemotécnico del maestro de Instrumentos','TFIT11090233'],['Cantidad',1,'Número mayor a 0','1000000'],['Tasa de negociación',0,'Porcentaje, con punto decimal','10.50'],['Valor giro',0,'Valor en moneda del portafolio','1094250']],
  descE:'Plantilla de <b>selección</b>: listas desplegables por columna, hoja de instrucciones y listas de los maestros de portafolios e instrumentos.',descM:'Instructivo campo por campo, con valores permitidos y errores frecuentes en órdenes de renta fija.',
  lists:[()=>PNAMES.slice(),()=>['COMPRA','VENTA'],()=>INSTR_NAMES.slice(),null,null,null],
  ej:()=>[FUNDS[1],'COMPRA',INSTR_NAMES[3]||INSTR_NAMES[0],'1000000','10.50','1094250'],
  row:c=>{const e=[],port=findCI(PNAMES,sv(c[0])),tipo=sv(c[1]).trim().toUpperCase(),instr=findCI(INSTR_NAMES.concat(INSTRUMENTS.map(i=>i.mnem)),sv(c[2])),cant=numP(c[3]),tasa=numP(c[4]),val=numP(c[5]);
   if(!port)e.push('el portafolio "'+sv(c[0])+'" no existe');if(tipo!=='COMPRA'&&tipo!=='VENTA')e.push('el tipo debe ser COMPRA o VENTA');if(!instr)e.push('el instrumento "'+sv(c[2])+'" no existe en el maestro');if(!(cant>0))e.push('la cantidad debe ser un número mayor a 0');if(Number.isNaN(tasa)||Number.isNaN(val))e.push('la tasa y el valor giro deben ser números');
   return e.length?{e}:{d:{estatus:'R',port,tipo,instr,cant,tasa:(tasa||0)/100,valor:val||0,fecha:Date.now()}}},
  add:d=>FI_ORDERS.unshift(d)},
 variable:{id:'variable',nombre:'Órdenes de Renta Variable',cols:[['Portafolio',1,'Nombre exacto del maestro de Portafolios','FIC BALANCEADO 1'],['Tipo',1,'COMPRA o VENTA','COMPRA'],['Instrumento',1,'Nemotécnico de la acción','ECOPETROL'],['Modalidad',1,'MERCADO o LIMITE','LIMITE'],['Cantidad',1,'Número mayor a 0','10000'],['Precio límite',0,'Obligatorio si la modalidad es LIMITE','2500']],
  descE:'Plantilla de <b>selección</b>: listas desplegables por columna, hoja de instrucciones y listas de los maestros de portafolios y emisores.',descM:'Instructivo campo por campo, con valores permitidos y errores frecuentes en órdenes de renta variable.',
  lists:[()=>PNAMES.slice(),()=>['COMPRA','VENTA'],VI_LIST,()=>['MERCADO','LIMITE'],null,null],
  ej:()=>[FUNDS[5],'COMPRA',VI_LIST()[0],'LIMITE','10000','2500'],
  row:c=>{const e=[],port=findCI(PNAMES,sv(c[0])),tipo=sv(c[1]).trim().toUpperCase(),instr=findCI(VI_LIST(),sv(c[2])),mod=sv(c[3]).trim().toUpperCase(),cant=numP(c[4]),pl=numP(c[5]);
   if(!port)e.push('el portafolio "'+sv(c[0])+'" no existe');if(tipo!=='COMPRA'&&tipo!=='VENTA')e.push('el tipo debe ser COMPRA o VENTA');if(!instr)e.push('el instrumento "'+sv(c[2])+'" no existe');if(mod!=='MERCADO'&&mod!=='LIMITE')e.push('la modalidad debe ser MERCADO o LIMITE');if(!(cant>0))e.push('la cantidad debe ser un número mayor a 0');if(Number.isNaN(pl))e.push('el precio límite debe ser un número');else if(mod==='LIMITE'&&!(pl>0))e.push('con modalidad LIMITE el precio límite es obligatorio');
   return e.length?{e}:{d:{estatus:'R',port,tipo,instr,orden:mod,cant,pl:mod==='LIMITE'?pl:0,valor:mod==='LIMITE'?cant*pl:0,fecha:Date.now()}}},
  add:d=>VI_ORDERS.unshift(d)},
 instr:{id:'instr',nombre:'Instrumentos',cols:[['Nemotécnico',1,'Código único del instrumento','TFIT11090233'],['Tipo',1,'Tipo de instrumento del catálogo','TASA FIJA'],['ISIN',0,'Código internacional de 12 caracteres','CO000000000X'],['Moneda',1,'Moneda del catálogo','COP'],['Tasa facial',0,'Porcentaje, con punto decimal','7.25'],['Periodicidad',0,'Código de periodicidad de pago','SV'],['Fecha emisión',1,'Formato AAAA-MM-DD','2024-01-15'],['Fecha vencimiento',1,'Posterior a la emisión, AAAA-MM-DD','2030-01-15'],['Emisor',0,'Nombre del catálogo de emisores','MINISTERIO DE HACIENDA (TES)'],['Calificación',0,'Escala del catálogo de calificaciones','AAA']],
  descE:'Plantilla de <b>selección</b>: listas desplegables por columna, hoja de instrucciones y listas de los catálogos de tipos, monedas, emisores y calificaciones.',descM:'Instructivo campo por campo, con valores permitidos y errores frecuentes en la carga de instrumentos.',
  lists:[null,()=>TIPOS(),null,()=>MONEDAS(),null,null,null,null,()=>ISSUERS.slice(),()=>CALIFS.slice()],
  ej:()=>['CARGA'+String(Date.now()).slice(-6),TIPOS()[3],'XX0000000000',MONEDAS()[0],'7.25','SV','2024-01-15','2030-01-15',ISSUERS[0],'AAA'],
  row:c=>{const e=[],mn=sv(c[0]).trim(),tipo=findCI(TIPOS(),sv(c[1])),mon=findCI(MONEDAS(),sv(c[3])),tasa=numP(c[4]),emi=isoP(c[6]),ven=isoP(c[7]);
   if(!mn)e.push('el nemotécnico es obligatorio');else if(INSTRUMENTS.some(i=>normH(i.mnem)===normH(mn)))e.push('el nemotécnico "'+mn+'" ya existe');if(!tipo)e.push('el tipo "'+sv(c[1])+'" no está en el catálogo');if(!mon)e.push('la moneda "'+sv(c[3])+'" no está en el catálogo');if(Number.isNaN(tasa))e.push('la tasa facial debe ser un número');if(!emi)e.push('la fecha de emisión es obligatoria (AAAA-MM-DD)');if(!ven)e.push('la fecha de vencimiento es obligatoria (AAAA-MM-DD)');if(emi&&ven&&ven<=emi)e.push('el vencimiento debe ser posterior a la emisión');
   return e.length?{e}:{d:{mnem:mn,tipo,isin:sv(c[2]).trim(),moneda:mon,tasa:tasa==null?'':tasa+'%',period:sv(c[5]).trim(),emi:fromIso(emi),ven:fromIso(ven),emisor:sv(c[8]).trim(),calif:sv(c[9]).trim(),activo:true}}},
  add:d=>INSTRUMENTS.unshift(d)},
 bench:{id:'bench',pre:'Importación de',nombre:'Composición de Benchmarks',cols:[['Portafolio',1,'Nombre exacto del maestro de Portafolios','FIC RENTA FIJA'],['Benchmark',1,'Nombre del benchmark compuesto','Benchmark FIC Renta Fija'],['Componente',1,'Código del maestro de Índices de referencia','IBR 3M'],['Peso',1,'Porcentaje; los pesos de un benchmark suman 100','60'],['Vigente desde',1,'Formato AAAA-MM-DD','2025-01-02']],
  descE:'Plantilla de <b>selección</b>: listas desplegables por columna, hoja de instrucciones y listas de los maestros de portafolios e índices de referencia.',descM:'Instructivo campo por campo, con valores permitidos y errores frecuentes al importar la composición de benchmarks.',
  lists:[()=>PNAMES.slice(),null,()=>BENCH_COMPS.slice(),null,null],
  ej:()=>[FUNDS[2],'Benchmark '+FUNDS[2],BENCH_COMPS[0],'100','2026-01-02'],
  row:c=>{const e=[],port=findCI(PNAMES,sv(c[0])),b=sv(c[1]).trim(),comp=findCI(BENCH_COMPS,sv(c[2])),peso=numP(c[3]),d=isoP(c[4]);
   if(!port)e.push('el portafolio "'+sv(c[0])+'" no existe');if(!b)e.push('el nombre del benchmark es obligatorio');if(!comp)e.push('el componente "'+sv(c[2])+'" no existe en los índices de referencia');if(!(peso>0&&peso<=100))e.push('el peso debe estar entre 0 y 100');if(!d)e.push('la fecha de vigencia es obligatoria (AAAA-MM-DD)');
   return e.length?{e}:{d:{port,bench:b,comp,peso:peso/100,desde:fromIso(d),activo:true}}},
  add:d=>BENCH_DEF.unshift(d)}
};
function massHTML(m){
 const dl=(k,t)=>'<button class="mk-iconbtn mk-iconbtn--view" type="button" data-dl="'+k+'"'+TIP(t)+' aria-label="'+t+'">'+ic('download')+'</button>';
 const th=(t,tip)=>'<th><span class="mk-th-info">'+t+info(tip)+'</span></th>';
 return '<div class="mk-massgrid"><fieldset class="mk-fieldset"><legend>Documentos</legend><p class="mk-help mk-mb">Descarga aquí la estructura de la plantilla y el manual antes de preparar el archivo.</p><div class="mk-tablewrap"><table class="mk-table"><thead><tr>'+th('Documento','Nombre del documento de apoyo para la carga.')+th('Descripción','Qué contiene el documento.')+th('Archivo','Descarga el documento.')+'</tr></thead><tbody><tr><td><b>Estructura de '+esc(m.pre||'Cargue Masivo de')+' '+esc(m.nombre)+'</b> <span class="mk-badge mk-badge--success" style="padding:2px 10px;font-size:11px">Excel</span></td><td>'+m.descE+'</td><td>'+dl('estructura','Descargar la estructura (Excel)')+'</td></tr><tr><td><b>'+(m.pre?'Manual de '+esc(m.pre):'Manual Cargue Masivo de')+' '+esc(m.nombre)+'</b></td><td>'+m.descM+'</td><td>'+dl('manual','Descargar el manual')+'</td></tr><tr><td><b>Ejemplo con datos de demostración</b> <span class="mk-badge mk-badge--success" style="padding:2px 10px;font-size:11px">Excel / CSV</span></td><td>Archivo listo para cargar con registros de prueba: al procesarlo todas las filas son válidas.</td><td><div class="mk-acts">'+dl('ejemplo','Descargar ejemplo con datos (Excel)')+dl('ejemplocsv','Descargar ejemplo con datos (CSV)')+'</div></td></tr></tbody></table></div></fieldset>'
 +'<fieldset class="mk-fieldset"><legend>Importación Masiva</legend><div class="mk-field"><label class="mk-label"><span>Archivo</span><span class="req">*</span>'+info('Archivo .xlsx o .csv con la estructura descargada. Máximo 5.000 filas.')+'</label></div><div class="mk-massrow"><div class="mk-fileupload" data-up tabindex="0" role="button" aria-label="Seleccionar archivo">'+ic('upload','lg')+'<div style="margin-top:6px"><strong>Seleccionar archivo</strong> o arrastrarlo a esta zona</div><div class="mk-help" style="margin-top:4px">Formatos .xlsx y .csv · hasta 5.000 filas</div><input type="file" accept=".xlsx,.csv" hidden></div><div class="mk-massside"><input class="mk-input" data-fname readonly placeholder="Ningún archivo seleccionado"><button class="mk-btn" type="button" data-proc disabled>Procesar</button></div></div><div data-result class="mk-mt"></div></fieldset></div>';
}
function bindMass(root,m,onLoad){
 const base=m.nombre.replace(/\s+/g,'_'),pre=m.pre?'Importacion':'Cargue_Masivo',tit=(m.pre?'de '+m.pre:'Cargue Masivo de')+' '+m.nombre;
 $$('[data-dl]',root).forEach(b=>b.addEventListener('click',()=>{
  if(b.dataset.dl==='estructura'){download('Estructura_'+pre+'_'+base+'.xlsx',buildXlsx(m),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');toast('Estructura de '+m.nombre+' descargada (Excel con listas desplegables).','success','Descarga lista')}
  else if(b.dataset.dl==='ejemplo'){download('Ejemplo_'+pre+'_'+base+'.xlsx',buildXlsx(m,m.demo()),XLSX_MIME);toast('Ejemplo con datos de '+m.nombre+' descargado (Excel).','success','Descarga lista')}
  else if(b.dataset.dl==='ejemplocsv'){download('Ejemplo_'+pre+'_'+base+'.csv',demoCsv(m),'text/csv;charset=utf-8');toast('Ejemplo con datos de '+m.nombre+' descargado (CSV).','success','Descarga lista')}
  else{const rows=m.cols.map(c=>'<tr><td>'+esc(c[0])+'</td><td>'+(c[1]?'Sí':'No')+'</td><td>'+esc(loc(c[2]))+'</td><td>'+esc(loc(c[3]))+'</td></tr>').join('');download('Manual_'+pre+'_'+base+'.html','<!doctype html><meta charset="utf-8"><title>Manual '+esc(tit)+'</title><body style="font-family:Segoe UI,Arial;max-width:900px;margin:30px auto;color:#1F2937"><h1 style="color:#6A1B9A">Manual '+esc(tit)+'</h1><p>Descarga la estructura (Excel), diligénciala y cárgala en la pestaña de carga masiva. Formatos .xlsx o .csv, hasta 5.000 filas. La primera fila son los encabezados, en el mismo orden y con el mismo nombre. La hoja <b>Listas</b> del Excel trae los valores permitidos de cada maestro y las columnas con lista tienen desplegable.</p><table border="1" cellpadding="8" style="border-collapse:collapse;width:100%"><tr style="background:#6A1B9A;color:#fff"><th>Campo</th><th>Obligatorio</th><th>Valores permitidos</th><th>Ejemplo</th></tr>'+rows+'</table><h2 style="color:#6A1B9A">Cómo se procesa</h2><ul><li>Se validan todas las filas. Las filas válidas se cargan; las que tienen errores se informan con su número de fila y no se cargan.</li><li>Los registros cargados quedan en estado Registrada (órdenes) o Activo (maestros).</li></ul><h2 style="color:#6A1B9A">Errores frecuentes</h2><ul><li>Cambiar el orden o el nombre de las columnas.</li><li>Usar un valor que no exista en el maestro correspondiente.</li><li>Dejar vacío un campo obligatorio.</li><li>Usar coma decimal en .csv con separador coma; usa punto decimal.</li><li>Repetir un código que ya existe (por ejemplo, un nemotécnico).</li></ul></body>','text/html;charset=utf-8');toast('Manual '+tit+' descargado.','success','Descarga lista')}
 }));
 const z=$('[data-up]',root),inp=$('input[type=file]',z),nm=$('[data-fname]',root),pb=$('[data-proc]',root),res=$('[data-result]',root);let file=null;
 const pick=f=>{res.innerHTML='';if(!f)return;if(!/\.(xlsx|csv)$/i.test(f.name)){file=null;nm.value='';pb.disabled=true;res.innerHTML=alertB('danger','Formato no permitido','Solo se aceptan archivos .xlsx o .csv.',true);toast('Formato no permitido. Usa .xlsx o .csv.','danger','Archivo inválido');return}file=f;nm.value=f.name;pb.disabled=false};
 z.addEventListener('click',()=>inp.click());z.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();inp.click()}});inp.addEventListener('change',()=>pick(inp.files[0]));
 ['dragover','dragenter'].forEach(ev=>z.addEventListener(ev,e=>{e.preventDefault();z.classList.add('is-over')}));['dragleave','drop'].forEach(ev=>z.addEventListener(ev,e=>{e.preventDefault();z.classList.remove('is-over')}));z.addEventListener('drop',e=>pick(e.dataTransfer.files[0]));
 const fail=(msg)=>{res.innerHTML=alertB('danger','No se pudo procesar el archivo',esc(msg)+' Revisa la estructura y vuelve a intentarlo.',true);toast(msg,'danger','Archivo con errores')};
 pb.addEventListener('click',async()=>{if(!file)return;pb.classList.add('is-loading');
  let rows;try{rows=/\.csv$/i.test(file.name)?parseCSV(await file.text()):await readXlsx(file)}catch(e){pb.classList.remove('is-loading');return fail('No se pudo leer el archivo ('+(e&&e.message?e.message:'formato no válido')+').')}
  rows=rows.filter(r=>r.some(x=>String(x).trim()));
  await new Promise(r=>setTimeout(r,500));pb.classList.remove('is-loading');
  if(!rows.length)return fail('El archivo está vacío.');
  const head=rows[0].map(normH),want=m.cols.map(c=>normH(c[0]));
  if(head.length<want.length||want.some((w,i)=>head[i]!==w))return fail('Los encabezados no coinciden con la estructura de '+m.nombre+'. Se esperaba: '+m.cols.map(c=>c[0]).join(', ')+'.');
  const data=rows.slice(1);if(!data.length)return fail('El archivo no tiene filas de datos.');if(data.length>5000)return fail('El archivo supera las 5.000 filas permitidas.');
  const ok=[],errs=[];data.forEach((c,i)=>{const r=m.row(c);if(r.e)errs.push('Fila '+(i+2)+': '+r.e.join('; '));else ok.push(r.d)});
  ok.slice().reverse().forEach(d=>m.add(d));onLoad&&onLoad(ok.length);
  const list=errs.length?'<ul style="margin:6px 0 0;padding-left:18px">'+errs.slice(0,6).map(x=>'<li>'+esc(x)+'</li>').join('')+(errs.length>6?'<li>… y '+(errs.length-6)+' más</li>':'')+'</ul>':'';
  if(ok.length){res.innerHTML=alertB(errs.length?'warning':'success',errs.length?'Archivo procesado con observaciones':'Archivo procesado','<b>'+ok.length+'</b> registros cargados · <b>'+errs.length+'</b> con errores'+(errs.length?' (las filas con error no se cargaron)':'')+'.'+list+(ok.length?'<div style="margin-top:6px">Ya puedes verlos en la tabla de '+(m.pre?'la pantalla':'registro')+'.</div>':''),true);toast(ok.length+' registros cargados'+(errs.length?', '+errs.length+' con errores':'')+'.',errs.length?'warning':'success','Carga masiva')}
  else{res.innerHTML=alertB('danger','Ningún registro válido','<b>0</b> registros cargados · <b>'+errs.length+'</b> con errores (ninguna fila se cargó).'+list,true);toast('Ningún registro válido en el archivo.','danger','Carga masiva')}
  file=null;nm.value='';inp.value='';pb.disabled=true});
}
const APO={
 port:[['Renta fija','#/orders/fixed-income'],['Renta variable','#/orders/variable-income'],['Evaluación de límites','#/limit-control/limit-evaluation'],['Performance attribution','#/performance-attribution/summary']],
 instr:[['Renta fija','#/orders/fixed-income'],['Renta variable','#/orders/variable-income'],['Flujos futuros','#/dashboard/future-flows'],['Visor de portafolio','#/dashboard/graphics']],
 index:[['Benchmarks','#/parametrizacion/benchmarks'],['Resumen de desempeño','#/performance-attribution/summary'],['Atribución de retorno','#/performance-attribution/brinson']],
 bench:[['Resumen de desempeño','#/performance-attribution/summary'],['Atribución de retorno','#/performance-attribution/brinson'],['Reportes','#/performance-attribution/reports']],
 limits:[['Evaluación de límites','#/limit-control/limit-evaluation']],
 flow:[['Renta fija','#/orders/fixed-income'],['Renta variable','#/orders/variable-income']],
 cat:[
  [['Visor de portafolio','#/dashboard/graphics'],['Configuración de límites','#/parametrizacion/limits']],
  [['Visor de portafolio','#/dashboard/graphics'],['Configuración de límites','#/parametrizacion/limits']],
  [['Renta fija','#/orders/fixed-income'],['Flujos futuros','#/dashboard/future-flows'],['Visor de portafolio','#/dashboard/graphics']],
  [['Configuración de límites','#/parametrizacion/limits'],['Evaluación de límites','#/limit-control/limit-evaluation']]
 ]
};
const apoyaHTML=a=>'<div class="mk-apoya"><span'+TIP('Pantallas conectadas con este maestro: las que lo usan y las que se afectan si cambia.')+'>Módulos conectados:</span>'+a.map(x=>'<a class="mk-chip" data-go="'+x[1]+'" href="'+x[1]+'">'+esc(x[0])+'</a>').join('')+'</div>';
/* --- Renta fija --- */
PAGES_INIT();
function PAGES_INIT(){}
const PAGES={};
PAGES.fixed=crudPage({title:'Renta fija',help:'Opera y administra inversiones en instrumentos de deuda.',mass:MASS.fixed,dateRange:{k:'fecha',label:'fecha de creación'},entity:'orden de renta fija',entityArt:'La orden',fileName:'renta-fija',defaultSort:'Creado',defaultDir:-1,searchPh:'Portafolio o instrumento...',noun:'órdenes',
 filters:[{id:'port',label:'Portafolio',opts:()=>PNAMES.slice(0,9),get:r=>r.port}].concat(filtOrd),kpis:kpiOrd,
 cols:[{h:'Portafolio',k:'port'},{h:'Tipo',k:'tipo',html:r=>side(r.tipo),txt:r=>r.tipo},{h:'Instrumento',k:'instr'},{h:'Cantidad',k:'cant',fmt:f2},{h:'Tasa',k:'tasa',fmt:v=>pc2(v*100)},{h:'Valor',k:'valor',fmt:money},{h:'Creado',k:'fecha',fmt:dstr,sortable:true}],
 rows:()=>FI_ORDERS,acts:actsOrd,estado:estOrd,toggle:togOrd('la orden'),
 detail:r=>[['Portafolio',esc(r.port)],['Tipo',r.tipo],['Instrumento',esc(r.instr)],['Cantidad',f2(r.cant)],['Tasa de negociación',pc2(r.tasa*100)],['Valor giro',money(r.valor)],['Creada',dstr(r.fecha)],['Estado',ESTADO_ORD[r.estatus][0]]],badges:r=>side(r.tipo)+' '+estOrd(r),detailTitle:r=>'Orden · '+r.instr,
 form:row=>({html:'<div class="mk-formgrid">'+radiosF('tipo','Tipo de orden',['COMPRA','VENTA'],row?row.tipo:'COMPRA',{req:true})+selF('port','Portafolio',PNAMES,row&&row.port,{req:true})+acF('instr','Instrumento','Escribe para buscar...',row&&row.instr,{req:true})+inpF('quantity','Cantidad',row?row.cant.toFixed(2):'0.00',{req:true})+inpF('rate','Tasa de negociación',row?(row.tasa*100).toFixed(2)+'%':'0.00%')+inpF('value','Valor giro',row?'$'+row.valor.toFixed(2):'$0.00')+'</div>',
  bind:f=>{bindAC(f,'instr',INSTR_NAMES.concat(INSTRUMENTS.slice(0,8).map(i=>i.mnem)));bindMask(f,'quantity',mask.qty);bindMask(f,'rate',mask.rate);bindMask(f,'value',mask.money)},
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[];if(!g('port'))errs.push(['port','Selecciona un portafolio','Portafolio']);if(!g('instr'))errs.push(['instr','Indica el instrumento','Instrumento']);if(!okNum(g('quantity')))errs.push(['quantity','La cantidad debe ser mayor a 0','Cantidad']);if(errs.length)return {ok:false,errs};return {ok:true,data:{estatus:row?row.estatus:'R',port:g('port'),tipo:rv(f,'tipo'),instr:g('instr'),cant:okNum(g('quantity')),tasa:okNum(g('rate'))/100,valor:okNum(g('value')),fecha:row?row.fecha:Date.now()}}}}),
 review:d=>[['Tipo',d.tipo],['Portafolio',d.port],['Instrumento',d.instr],['Cantidad',f2(d.cant)],['Tasa',pc2(d.tasa*100)],['Valor giro',money(d.valor)]],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else FI_ORDERS.unshift(o)}
});
/* --- Renta variable --- */
PAGES.variable=crudPage({title:'Renta variable',help:'Opera y administra inversiones en acciones.',mass:MASS.variable,dateRange:{k:'fecha',label:'fecha de creación'},entity:'orden de renta variable',entityArt:'La orden',fileName:'renta-variable',defaultSort:'Creado',defaultDir:-1,searchPh:'Portafolio o instrumento...',noun:'órdenes',
 filters:[{id:'port',label:'Portafolio',opts:()=>PNAMES.slice(0,9),get:r=>r.port},{id:'ord',label:'Tipo orden',opts:()=>['MERCADO','LIMITE'],get:r=>r.orden}].concat(filtOrd),kpis:kpiOrd,
 cols:[{h:'Portafolio',k:'port'},{h:'Tipo',k:'tipo',html:r=>side(r.tipo),txt:r=>r.tipo},{h:'Instrumento',k:'instr'},{h:'Tipo orden',k:'orden',html:r=>badge(r.orden,r.orden==='LIMITE'?'warning':'neutral'),txt:r=>r.orden},{h:'Cantidad',k:'cant',fmt:f2},{h:'Precio límite',k:'pl',fmt:f2},{h:'Valor',k:'valor',fmt:money},{h:'Creado',k:'fecha',fmt:dstr,sortable:true}],
 rows:()=>VI_ORDERS,acts:actsOrd,estado:estOrd,toggle:togOrd('la orden'),
 detail:r=>[['Portafolio',esc(r.port)],['Tipo',r.tipo],['Instrumento',esc(r.instr)],['Tipo de orden',r.orden],['Cantidad',f2(r.cant)],['Precio límite',r.orden==='LIMITE'?f2(r.pl):'—'],['Valor',money(r.valor)],['Creada',dstr(r.fecha)]],badges:r=>side(r.tipo)+' '+estOrd(r),detailTitle:r=>'Orden · '+r.instr,
 form:row=>({html:'<div class="mk-formgrid">'+radiosF('tipo','Tipo de orden',['COMPRA','VENTA'],row?row.tipo:'COMPRA',{req:true})+radiosF('ord','Modalidad',['MERCADO','LIMITE'],row?row.orden:'MERCADO',{req:true,tip:'Mercado: se ejecuta al precio vigente. Límite: solo al precio indicado o mejor.'})+selF('port','Portafolio',PNAMES,row&&row.port,{req:true})+acF('instr','Instrumento','Escribe para buscar...',row&&row.instr,{req:true})+inpF('quantity','Cantidad',row?row.cant.toFixed(2):'0.00',{req:true})+'<div id="plw">'+(row&&row.orden==='LIMITE'?inpF('limit','Precio límite',row.pl.toFixed(2),{req:true}):'')+'</div></div>',
  bind:f=>{bindAC(f,'instr',VI_LIST());bindMask(f,'quantity',mask.qty);const up=()=>{$('#plw',f).innerHTML=rv(f,'ord')==='LIMITE'?($('[name=limit]',f)?$('#plw',f).innerHTML:inpF('limit','Precio límite','0.00',{req:true})):'';bindMask(f,'limit',mask.qty)};$$('[name=ord]',f).forEach(r=>r.addEventListener('change',up));bindMask(f,'limit',mask.qty)},
  read:f=>{const g=n=>($('[name="'+n+'"]',f)||{value:''}).value.trim(),errs=[],lim=rv(f,'ord')==='LIMITE';if(!g('port'))errs.push(['port','Selecciona un portafolio','Portafolio']);if(!g('instr'))errs.push(['instr','Indica el instrumento','Instrumento']);if(!okNum(g('quantity')))errs.push(['quantity','La cantidad debe ser mayor a 0','Cantidad']);if(lim&&!okNum(g('limit')))errs.push(['limit','Ingresa el precio límite','Precio límite']);if(errs.length)return {ok:false,errs};const q=okNum(g('quantity')),pl=lim?okNum(g('limit')):0;return {ok:true,data:{estatus:row?row.estatus:'R',port:g('port'),tipo:rv(f,'tipo'),instr:g('instr'),orden:lim?'LIMITE':'MERCADO',cant:q,pl,valor:q*pl,fecha:row?row.fecha:Date.now()}}}}),
 review:d=>[['Tipo',d.tipo],['Portafolio',d.port],['Instrumento',d.instr],['Modalidad',d.orden],['Cantidad',f2(d.cant)],['Precio límite',d.orden==='LIMITE'?f2(d.pl):'—']],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else VI_ORDERS.unshift(o)}
});
/* --- Instrumentos --- */
INSTRUMENTS.forEach((r,i)=>{if(r.activo===undefined)r.activo=(i%9!==4)});
PAGES.instruments=crudPage({title:'Instrumentos',help:'Consulta, registra y administra los instrumentos financieros disponibles para negociación.',apoya:APO.instr,entity:'instrumento',entityArt:'El instrumento',fileName:'instrumentos',defaultSort:'Nemotécnico',searchPh:'Nemotécnico, ISIN o emisor...',noun:'instrumentos',
 filters:[{id:'t',label:'Tipo',opts:()=>TIPOS(),get:r=>r.tipo},{id:'m',label:'Moneda',opts:()=>MONEDAS(),get:r=>r.moneda},{id:'e',label:'Estado',opts:()=>['Activo','Inactivo'],get:r=>r.activo?'Activo':'Inactivo'}],
 kpis:rows=>[['Instrumentos',rows.length,'p'],['Activos',rows.filter(r=>r.activo).length,'g'],['Inactivos',rows.filter(r=>!r.activo).length,'r'],['Vencen en 12 meses',rows.filter(r=>r.ven>Date.now()&&r.ven<Date.now()+365*864e5).length,'y']],
 cols:[{h:'Nemotécnico',k:'mnem',sortable:true},{h:'Tipo',k:'tipo'},{h:'ISIN',k:'isin',tip:'Código internacional de identificación de valores'},{h:'Moneda',k:'moneda'},{h:'Tasa facial',k:'tasa'},{h:'Periodicidad',k:'period'},{h:'Fecha emisión',k:'emi',fmt:fmtD},{h:'Fecha vencimiento',k:'ven',fmt:fmtD},{h:'Emisor',k:'emisor'},{h:'Calificación',k:'calif'}],
 rows:()=>INSTRUMENTS,estado:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral',true),
 acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar instrumento',danger:true,message:'Vas a inactivar <b>'+esc(r.mnem)+'</b>. No podrá seleccionarse en nuevas órdenes; las órdenes vigentes no se modifican.',confirm:'Inactivar',done:'Instrumento inactivado.',apply:()=>{r.activo=false}}:{title:'Activar instrumento',message:'¿Deseas activar <b>'+esc(r.mnem)+'</b> para negociación?',confirm:'Activar',done:'Instrumento activado.',apply:()=>{r.activo=true}},
 detail:r=>[['Nemotécnico',esc(r.mnem)],['Tipo',r.tipo],['ISIN',esc(r.isin)],['Moneda',r.moneda],['Tasa facial',r.tasa],['Periodicidad',r.period],['Fecha emisión',fmtD(r.emi)],['Fecha vencimiento',fmtD(r.ven)],['Emisor',esc(r.emisor)],['Calificación',r.calif]],detailTitle:r=>r.mnem,badges:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral'),
 extra:(pg,rp)=>{const x=document.createElement('div');x.className='mk-accordion collapsed mk-mt';x.innerHTML='<div class="mk-accordion__head"><span class="mk-accordion__ico">'+ic('upload')+'</span><span><span class="mk-accordion__t">Carga masiva de instrumentos</span><span class="mk-accordion__d">Descarga la estructura y el manual, y carga el archivo</span></span><span class="mk-accordion__chev">&#9662;</span></div><div class="mk-accordion__body">'+massHTML(MASS.instr)+'</div>';pg.appendChild(x);bindAcc(x);bindMass(x,MASS.instr,rp)},
 form:row=>({html:'<div class="mk-formgrid">'+selF('tipo','Tipo de instrumento',TIPOS(),row&&row.tipo,{req:true})+inpF('mnemonic','Nemotécnico',row&&row.mnem,{req:true})+inpF('isin','ISIN',row&&row.isin)+selF('currency','Moneda',MONEDAS(),row&&row.moneda,{req:true})+inpF('rate','Tasa facial',row&&row.tasa)+inpF('freq','Periodicidad',row&&row.period)+dateF('emi','Fecha emisión',row&&row.emi,{req:true})+dateF('ven','Fecha vencimiento',row&&row.ven,{req:true})+inpF('issuer','Emisor',row&&row.emisor)+inpF('rating','Calificación',row&&row.calif)+'</div>',
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[];if(!g('tipo'))errs.push(['tipo','Selecciona el tipo','Tipo']);if(!g('mnemonic'))errs.push(['mnemonic','Indica el nemotécnico','Nemotécnico']);if(!g('currency'))errs.push(['currency','Selecciona la moneda','Moneda']);const e=fromIso(g('emi')),v=fromIso(g('ven'));if(!e)errs.push(['emi','Indica la fecha de emisión','Emisión']);if(!v)errs.push(['ven','Indica la fecha de vencimiento','Vencimiento']);if(e&&v&&v<=e)errs.push(['ven','El vencimiento debe ser posterior a la emisión','Vencimiento']);if(errs.length)return {ok:false,errs};return {ok:true,data:{mnem:g('mnemonic'),tipo:g('tipo'),isin:g('isin'),moneda:g('currency'),tasa:g('rate'),period:g('freq'),emi:e,ven:v,emisor:g('issuer'),calif:g('rating'),activo:row?row.activo:true}}}}),
 review:d=>[['Nemotécnico',d.mnem],['Tipo',d.tipo],['Moneda',d.moneda],['Emisión',fmtD(d.emi)],['Vencimiento',fmtD(d.ven)],['Emisor',d.emisor]],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else INSTRUMENTS.unshift(o)}
});
/* --- Control de límites --- */
LIMITS.forEach((r,i)=>{if(r.activo===undefined)r.activo=(i!==11)});
function limitsPage(title,help){return crudPage({title:title,help:help,apoya:APO.limits,entity:'límite',entityArt:'El límite',fileName:'limites',defaultSort:'Tipo de límite',searchPh:'Tipo, sublímite o portafolio...',noun:'límites',
 filters:[{id:'t',label:'Tipo de límite',opts:()=>Object.keys(SUBLIMITS),get:r=>r.tipo},{id:'e',label:'Evaluación',opts:()=>['MAX','MIN'],get:r=>r.eval},{id:'p',label:'Portafolio',opts:()=>PNAMES.slice(0,9),get:r=>r.port},{id:'s',label:'Estado',opts:()=>['Activo','Inactivo'],get:r=>r.activo?'Activo':'Inactivo'}],
 kpis:rows=>[['Límites',rows.length,'p'],['Activos',rows.filter(r=>r.activo).length,'g'],['Topes (MAX)',rows.filter(r=>r.eval==='MAX').length,'r'],['Pisos (MIN)',rows.filter(r=>r.eval==='MIN').length,'b']],
 cols:[{h:'Tipo de límite',k:'tipo',sortable:true},{h:'Evaluación',k:'eval',html:r=>badge(r.eval,r.eval==='MAX'?'danger':'info'),txt:r=>r.eval,tip:'MAX: tope que no se puede superar · MIN: piso mínimo a mantener'},{h:'Porcentaje',k:'pct',fmt:v=>pc2(v*100)},{h:'Sublímite',k:'sub'},{h:'Denominador',k:'denom'},{h:'Portafolio',k:'port'},{h:'Creado',k:'fecha',fmt:dstr}],
 rows:()=>LIMITS,estado:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral',true),
 acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar límite',danger:true,message:'Vas a inactivar el límite <b>'+esc(r.tipo)+' · '+esc(r.sub)+'</b> de <b>'+esc(r.port)+'</b>. Dejará de evaluarse hasta que lo actives de nuevo.',confirm:'Inactivar',done:'Límite inactivado.',apply:()=>{r.activo=false}}:{title:'Activar límite',message:'¿Deseas activar el límite <b>'+esc(r.tipo)+' · '+esc(r.sub)+'</b>?',confirm:'Activar',done:'Límite activado.',apply:()=>{r.activo=true}},
 detail:r=>[['Tipo de límite',r.tipo],['Valor límite',esc(r.sub)],['Evaluación',r.eval==='MAX'?'MAX (tope)':'MIN (piso)'],['Porcentaje',pc2(r.pct*100)],['Denominador',r.denom],['Portafolio',esc(r.port)],['Creado',dstr(r.fecha)]],detailTitle:r=>'Límite · '+r.tipo,badges:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral'),
 form:row=>({html:'<div class="mk-formgrid">'+selF('tipo','Tipo de límite',Object.keys(SUBLIMITS),row&&row.tipo,{req:true})+selF('sub','Valor límite',row?SUBLIMITS[row.tipo]:[],row&&row.sub,{req:true})+radiosF('eval','Evaluación límite',['MAX','MIN'],row?row.eval:'MAX',{req:true,tip:'MAX: el portafolio no puede superar el porcentaje. MIN: debe mantener al menos ese porcentaje.'})+inpF('pct','Porcentaje',row?(row.pct*100).toString():'',{req:true,ph:'Ej: 30'})+selF('den','Denominador',DENOMS,row&&row.denom,{req:true})+selF('port','Portafolio',PNAMES,row&&row.port,{req:true})+'</div>',
  bind:f=>{$('[name=tipo]',f).addEventListener('change',e=>{const s=$('[name=sub]',f);s.innerHTML='<option value="">Seleccionar</option>'+(SUBLIMITS[e.target.value]||[]).map(x=>'<option>'+esc(x)+'</option>').join('')})},
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[],p=okNum(g('pct'));[['tipo','Tipo de límite'],['sub','Valor límite'],['den','Denominador'],['port','Portafolio']].forEach(x=>{if(!g(x[0]))errs.push([x[0],'Selecciona una opción',x[1]])});if(!p||p>100)errs.push(['pct','Ingresa un porcentaje entre 0 y 100','Porcentaje']);if(errs.length)return {ok:false,errs};return {ok:true,data:{tipo:g('tipo'),sub:g('sub'),eval:rv(f,'eval'),pct:p/100,denom:g('den'),port:g('port'),fecha:row?row.fecha:Date.now(),activo:row?row.activo:true}}}}),
 review:d=>[['Tipo',d.tipo],['Valor límite',d.sub],['Evaluación',d.eval],['Porcentaje',pc2(d.pct*100)],['Denominador',d.denom],['Portafolio',d.port]],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else LIMITS.unshift(o)}
})}
PAGES.limitcfg=limitsPage('Configuración de límites','Define los límites por emisor, calificación, moneda, plazo y otros criterios.');
function evalRows(st){const fac=dfac((st&&st.op)||OPDATE);return LIMITS.filter(l=>l.activo).map(l=>{const r=rng(hash(l.port+l.tipo+l.sub+l.eval)),demo=(l.port===PNAMES[0]&&l.tipo==='EMISOR'&&l.eval==='MAX'&&Math.abs(l.pct-0.2)<1e-9),demo2=(l.port===PNAMES[0]&&l.tipo==='CONTRAPARTE'&&l.eval==='MAX'&&Math.abs(l.pct-0.25)<1e-9);let actual,uso,estado;
 if(l.eval==='MAX'){uso=(demo?0.92:demo2?0.94:(hash(l.sub+l.port)%11===0?1.06:0.35+r()*0.5))*fac;actual=l.pct*uso;estado=uso>=1?'Incumple':uso>=0.9?'Alerta':'Cumple'}
 else{uso=((hash(l.sub+l.port)%7===0)?0.85:1.08+r()*0.4)*fac;actual=l.pct*uso;estado=uso<1?'Incumple':'Cumple'}
 return {port:l.port,tipo:l.tipo,sub:l.sub,eval:l.eval,pct:l.pct,actual,uso,estado}})}
const EST_EV={Cumple:'success',Alerta:'warning',Incumple:'danger'};
PAGES.limiteval=crudPage({title:'Evaluación de límites',help:'Seguimiento del cumplimiento de los límites definidos en Parametrización.',noNew:true,fileName:'evaluacion-limites',defaultSort:'Utilización',defaultDir:-1,searchPh:'Portafolio, tipo o sublímite...',noun:'límites',
 filters:[{id:'p',label:'Portafolio',opts:()=>PNAMES.slice(0,9),get:r=>r.port},{id:'e',label:'Evaluación',opts:()=>['MAX','MIN'],get:r=>r.eval},{id:'s',label:'Estado',opts:()=>['Cumple','Alerta','Incumple'],get:r=>r.estado}],
 kpis:rows=>[['Límites evaluados',rows.length,'p'],['Cumplen',rows.filter(r=>r.estado==='Cumple').length,'g'],['En alerta',rows.filter(r=>r.estado==='Alerta').length,'y'],['Incumplen',rows.filter(r=>r.estado==='Incumple').length,'r']],
 cols:[{h:'Portafolio',k:'port'},{h:'Tipo de límite',k:'tipo'},{h:'Sublímite',k:'sub'},{h:'Evaluación',k:'eval',html:r=>badge(r.eval,r.eval==='MAX'?'danger':'info'),txt:r=>r.eval,tip:'MAX: tope que no se puede superar · MIN: piso mínimo a mantener'},{h:'Límite',k:'pct',fmt:v=>pc2(v*100)},{h:'Posición actual',k:'actual',fmt:v=>pc2(v*100)},{h:'Utilización',k:'uso',sortable:true,tip:'Posición actual dividida por el límite. En alerta desde 90%; incumple al superar el 100% de un tope.',html:r=>'<div style="min-width:110px">'+pc2(r.uso*100)+'<div class="mk-util"><div class="mk-util__b'+(r.estado==='Incumple'?' hi':'')+'" style="width:'+Math.min(100,r.uso*100)+'%"></div></div></div>',txt:r=>pc2(r.uso*100)}],
 rows:evalRows,opDate:true,estado:r=>badge(r.estado,EST_EV[r.estado],true),acts:()=>[['ver']],
 detail:r=>[['Portafolio',esc(r.port)],['Tipo de límite',r.tipo],['Sublímite',esc(r.sub)],['Evaluación',r.eval==='MAX'?'MAX (tope)':'MIN (piso)'],['Límite',pc2(r.pct*100)],['Posición actual',pc2(r.actual*100)],['Utilización',pc2(r.uso*100)],['Estado',r.estado]],detailTitle:r=>'Límite · '+r.tipo,badges:r=>badge(r.estado,EST_EV[r.estado]),
 form:()=>({html:'',read:()=>({ok:false})}),review:()=>[],onSave:()=>{},entity:'',entityArt:'',toggle:()=>({})
});

/* =============== MERCADO MONETARIO: datos, cargas masivas y pantallas =============== */
const MM_OPS_BASE=['CDT','SIMULTÁNEA','INTERBANCARIO','OVERNIGHT','TES CORTO'];
const MM_OPS=()=>LOCL(MM_OPS_BASE);
const MM_SENT=['INVERSIÓN','CAPTACIÓN'];
const CP_TIPOS=['Banco','Comisionista','Entidad pública'];
const MM_CP=[
 ['BANCOLOMBIA S.A.','Banco','AAA',7200000000],['BANCO DAVIVIENDA','Banco','AAA',8000000000],['BANCO DE BOGOTÁ','Banco','AAA',6000000000],['FINDETER','Entidad pública','AAA',3000000000],['MINISTERIO DE HACIENDA (TES)','Entidad pública','AAA',10000000000],['CORFICOLOMBIANA','Comisionista','AA+',2000000000],['BANCO COOMEVA','Banco','A',1000000000,0]
].map(a=>({name:a[0],tipo:a[1],calif:a[2],cupo:a[3],activo:a[4]!==0}));
const MM_ORDERS=[
 ['F','FIC LIQUIDEZ','CDT','INVERSIÓN','BANCOLOMBIA S.A.',3200000000,10.85,90,[2026,8,28]],
 ['F','FIC LIQUIDEZ','SIMULTÁNEA','INVERSIÓN','BANCOLOMBIA S.A.',2000000000,10.40,7,[2026,8,29]],
 ['R','FIC LIQUIDEZ','OVERNIGHT','INVERSIÓN','BANCO DAVIVIENDA',520000000,10.15,1,[2026,8,30]],
 ['F','FIC MONETARIO','CDT','INVERSIÓN','BANCO DE BOGOTÁ',450000000,10.95,120,[2026,8,22]],
 ['C','FIC MONETARIO','SIMULTÁNEA','INVERSIÓN','BANCOLOMBIA S.A.',400000000,10.40,7,[2026,8,29]],
 ['F','FIC MONETARIO','INTERBANCARIO','INVERSIÓN','BANCO DE BOGOTÁ',300000000,10.30,3,[2026,8,29]],
 ['F','FIC LIQUIDEZ','TES CORTO','INVERSIÓN','MINISTERIO DE HACIENDA (TES)',2300000000,10.55,180,[2026,8,15]],
 ['A','FIC MONETARIO','CDT','INVERSIÓN','BANCO DAVIVIENDA',500000000,10.70,60,[2026,8,18]],
 ['F','FIC LIQUIDEZ','CDT','INVERSIÓN','FINDETER',1000000000,11.05,180,[2026,8,10]],
 ['F','FIC RENTA FIJA','OVERNIGHT','INVERSIÓN','BANCO DAVIVIENDA',800000000,10.12,1,[2026,8,26]],
 ['F','FIC LIQUIDEZ','SIMULTÁNEA','CAPTACIÓN','BANCO DE BOGOTÁ',600000000,10.20,5,[2026,8,24]],
 ['F','FIC LIQUIDEZ','INTERBANCARIO','CAPTACIÓN','BANCO DAVIVIENDA',450000000,10.25,2,[2026,8,23]],
 ['F','FIC MONETARIO','CDT','INVERSIÓN','BANCOLOMBIA S.A.',600000000,10.85,90,[2026,8,9]],
 ['F','FIC MONETARIO','OVERNIGHT','INVERSIÓN','BANCO DAVIVIENDA',500000000,10.15,1,[2026,8,30]],
 ['F','FIC LIQUIDEZ','CDT','INVERSIÓN','BANCO DE BOGOTÁ',1800000000,10.95,120,[2026,7,25]],
 ['F','FIC LIQUIDEZ','CDT','INVERSIÓN','BANCO DAVIVIENDA',2200000000,10.70,60,[2026,7,20]],
 ['F','FIC MONETARIO','TES CORTO','INVERSIÓN','MINISTERIO DE HACIENDA (TES)',350000000,10.55,180,[2026,7,12]],
 ['F','FIC RENTA FIJA','CDT','INVERSIÓN','BANCO DE BOGOTÁ',1200000000,10.90,90,[2026,7,5]]
].map(a=>({estatus:a[0],port:a[1],op:a[2],sentido:a[3],cp:a[4],nominal:a[5],tasa:a[6]/100,plazo:a[7],fecha:mkDate(a[8][0],a[8][1],a[8][2]).getTime()})).sort((a,b)=>b.fecha-a.fecha);
const MM_POS=[
 ['FIC LIQUIDEZ','CDT','BANCOLOMBIA S.A.',3200000000,10.85,90,61],['FIC LIQUIDEZ','SIMULTÁNEA','BANCOLOMBIA S.A.',2000000000,10.40,7,3],['FIC LIQUIDEZ','OVERNIGHT','BANCOLOMBIA S.A.',520000000,10.15,1,1],
 ['FIC LIQUIDEZ','CDT','BANCO DAVIVIENDA',2200000000,10.70,60,21],['FIC LIQUIDEZ','SIMULTÁNEA','BANCO DAVIVIENDA',1500000000,10.35,7,4],
 ['FIC LIQUIDEZ','CDT','BANCO DE BOGOTÁ',1800000000,10.95,120,88],['FIC LIQUIDEZ','INTERBANCARIO','BANCO DE BOGOTÁ',900000000,10.30,3,1],
 ['FIC LIQUIDEZ','CDT','FINDETER',1000000000,11.05,180,131],['FIC LIQUIDEZ','TES CORTO','MINISTERIO DE HACIENDA (TES)',2300000000,10.55,180,97],
 ['FIC MONETARIO','CDT','BANCOLOMBIA S.A.',600000000,10.85,90,12],['FIC MONETARIO','CDT','BANCO DAVIVIENDA',500000000,10.70,60,28],['FIC MONETARIO','CDT','BANCO DE BOGOTÁ',450000000,10.95,120,65],
 ['FIC MONETARIO','SIMULTÁNEA','BANCOLOMBIA S.A.',400000000,10.40,7,2],['FIC MONETARIO','INTERBANCARIO','BANCO DE BOGOTÁ',300000000,10.30,3,1],['FIC MONETARIO','OVERNIGHT','BANCO DAVIVIENDA',500000000,10.15,1,1],
 ['FIC MONETARIO','TES CORTO','MINISTERIO DE HACIENDA (TES)',350000000,10.55,180,75],['FIC MONETARIO','CDT','FINDETER',172749058,11.05,90,40],
 ['FIC RENTA FIJA','OVERNIGHT','BANCO DAVIVIENDA',800000000,10.12,1,1],['FIC RENTA FIJA','CDT','BANCO DE BOGOTÁ',1200000000,10.90,90,50]
].map(a=>({port:a[0],op:a[1],cp:a[2],nominal:a[3],tasa:a[4]/100,plazo:a[5],rest:a[6]}));
const MM_RATES=[
 ['IBR OVERNIGHT','Indicador Bancario de Referencia a 1 día',10.12],['IBR 1M','Indicador Bancario de Referencia a 1 mes',10.25],['IBR 3M','Indicador Bancario de Referencia a 3 meses',10.41],['DTF 90D','Depósito a Término Fijo a 90 días',10.68],['TASA DE REPO BANREP','Tasa de política monetaria del Banco de la República',10.25]
].map((a,i)=>({code:a[0],desc:a[1],valor:a[2],desde:mkDate(2026,8,29).getTime(),fuente:'Banco de la República',activo:true}));
const cpNames=()=>MM_CP.filter(c=>c.activo).map(c=>c.name);
const cpUsed=n=>MM_POS.filter(p=>p.cp===n).reduce((a,p)=>a+p.nominal,0);
const cpAvail=n=>{const c=MM_CP.find(x=>x.name===n);return c?c.cupo-cpUsed(n):0};
const cpUtil=c=>c.cupo?cpUsed(c.name)/c.cupo:0;
/* Límites propios del mercado monetario */
SUBLIMITS['CONTRAPARTE']=['BANCOLOMBIA S.A.','BANCO DAVIVIENDA','BANCO DE BOGOTÁ','FINDETER'];
SUBLIMITS['INSTRUMENTO MONETARIO']=['CDT','SIMULTÁNEA','INTERBANCARIO','OVERNIGHT','TES CORTO'];
[['CONTRAPARTE','MAX',0.25,'BANCOLOMBIA S.A.','TOTAL ACTIVO','FIC LIQUIDEZ',[2026,7,3]],['CONTRAPARTE','MAX',0.30,'BANCO DAVIVIENDA','TOTAL ACTIVO','FIC MONETARIO',[2026,7,3]],['INSTRUMENTO MONETARIO','MIN',0.02,'OVERNIGHT','TOTAL ACTIVO','FIC LIQUIDEZ',[2026,7,10]],['INSTRUMENTO MONETARIO','MAX',0.60,'CDT','TOTAL ACTIVO','FIC MONETARIO',[2026,7,10]],['INSTRUMENTO MONETARIO','MAX',0.30,'SIMULTÁNEA','TOTAL ACTIVO','FIC LIQUIDEZ',[2026,7,10]],['CALIFICACIÓN','MIN',0.90,'AA+','TOTAL ACTIVO','FIC MONETARIO',[2026,7,17]]].forEach(a=>LIMITS.push({tipo:a[0],eval:a[1],pct:a[2],sub:a[3],denom:a[4],port:a[5],fecha:mkDate(a[6][0],a[6][1],a[6][2]).getTime(),activo:true}));
Object.assign(APO,{
 mm:[['Posición monetaria','#/dashboard/money-market'],['Libro de órdenes','#/orders/reports'],['Evaluación de límites','#/limit-control/limit-evaluation'],['Atribución mercado monetario','#/performance-attribution/money-market']],
 cp:[['Mercado monetario','#/orders/money-market'],['Posición monetaria','#/dashboard/money-market'],['Evaluación de límites','#/limit-control/limit-evaluation']],
 rates:[['Posición monetaria','#/dashboard/money-market'],['Atribución mercado monetario','#/performance-attribution/money-market'],['Benchmarks','#/parametrizacion/benchmarks']]
});
APO.flow.push(['Mercado monetario','#/orders/money-market']);
APO.port.push(['Mercado monetario','#/orders/money-market']);
APO.cat.push([['Mercado monetario','#/orders/money-market'],['Posición monetaria','#/dashboard/money-market']]);
const cupoTxt=n=>{const c=MM_CP.find(x=>x.name===n);return c?'Cupo de '+n+': '+money(c.cupo)+' · utilizado '+money(cpUsed(n))+' · <b>disponible '+money(Math.max(0,cpAvail(n)))+'</b>':''};

MASS.mm={id:'mm',nombre:'Órdenes de Mercado Monetario',cols:[['Portafolio',1,'Nombre exacto del maestro de Portafolios','FIC LIQUIDEZ'],['Sentido',1,'INVERSIÓN o CAPTACIÓN','INVERSIÓN'],['Operación',1,'Tipo de operación monetaria del catálogo','CDT'],['Contraparte',1,'Contraparte activa del maestro de Contrapartes y cupos','BANCO DE BOGOTÁ'],['Valor nominal',1,'Número mayor a 0, en moneda del portafolio','500000000'],['Tasa E.A.',1,'Porcentaje efectivo anual, con punto decimal','10.90'],['Plazo (días)',1,'Número entero de días mayor o igual a 1','90']],
 descE:'Plantilla de <b>selección</b>: listas desplegables por columna, hoja de instrucciones y listas de portafolios, operaciones y contrapartes activas.',descM:'Instructivo campo por campo, con valores permitidos, control de cupo por contraparte y errores frecuentes en operaciones monetarias.',
 lists:[()=>FUNDS.slice(),()=>MM_SENT.slice(),()=>MM_OPS(),()=>cpNames(),null,null,null],
 ej:()=>[FUNDS[0],MM_SENT[0],MM_OPS()[0],cpNames()[2],'500000000','10.90','90'],
 demo:()=>{const o=MM_OPS(),c=cpNames();return [[FUNDS[0],MM_SENT[0],o[0],c[2],'500000000','10.90','90'],[FUNDS[0],MM_SENT[0],o[3],c[1],'400000000','10.12','1'],[FUNDS[8],MM_SENT[0],o[1],c[1],'300000000','10.35','7'],[FUNDS[8],MM_SENT[0],o[2],c[2],'250000000','10.28','3'],[FUNDS[1],MM_SENT[0],o[4],c[4],'600000000','10.58','120'],[FUNDS[0],MM_SENT[1],o[1],c[3],'200000000','10.22','5']]},
 row:c=>{const e=[],port=findCI(FUNDS,sv(c[0])),sent=findCI(MM_SENT,sv(c[1])),op=findCI(MM_OPS(),sv(c[2])),cp=findCI(cpNames(),sv(c[3])),nom=numP(c[4]),tasa=numP(c[5]),pl=numP(c[6]);
  if(!port)e.push('el portafolio "'+sv(c[0])+'" no existe');if(!sent)e.push('el sentido debe ser INVERSIÓN o CAPTACIÓN');if(!op)e.push('la operación "'+sv(c[2])+'" no está en el catálogo');if(!cp)e.push('la contraparte "'+sv(c[3])+'" no existe o está inactiva');if(!(nom>0))e.push('el valor nominal debe ser mayor a 0');if(!(tasa>0&&tasa<=100))e.push('la tasa debe estar entre 0 y 100');if(!(pl>=1&&pl===Math.floor(pl)))e.push('el plazo debe ser un número entero de días');
  if(cp&&sent===MM_SENT[0]&&nom>0&&nom>cpAvail(cp))e.push('supera el cupo disponible de '+cp+' ('+money(Math.max(0,cpAvail(cp)))+')');
  return e.length?{e}:{d:{estatus:'R',port,op,sentido:sent,cp,nominal:nom,tasa:tasa/100,plazo:pl,fecha:Date.now()}}},
 add:d=>MM_ORDERS.unshift(d)};
MASS.cp={id:'cp',nombre:'Contrapartes y Cupos',cols:[['Contraparte',1,'Nombre de la entidad (único)','BANCO POPULAR S.A.'],['Tipo',1,'Banco, Comisionista o Entidad pública','Banco'],['Calificación',1,'Escala del catálogo de calificaciones','AAA'],['Cupo autorizado',1,'Valor máximo en moneda local','2000000000']],
 descE:'Plantilla de <b>selección</b>: listas desplegables por columna, hoja de instrucciones y listas de tipos y calificaciones.',descM:'Instructivo campo por campo, con valores permitidos y errores frecuentes al cargar contrapartes.',
 lists:[null,()=>LOCL(CP_TIPOS),()=>CALIFS.slice(),null],
 ej:()=>[loc('BANCO POPULAR S.A.'),LOCL(CP_TIPOS)[0],'AAA','2000000000'],
 demo:()=>{const t=LOCL(CP_TIPOS);return [[loc('BANCO POPULAR S.A.'),t[0],'AAA','2000000000'],[loc('BANCO AV VILLAS'),t[0],'AA+','1500000000'],[loc('SCOTIABANK COLPATRIA'),t[0],'AAA','3000000000'],[loc('CORFICOLOMBIANA')+' II',t[1],'AA','1000000000']]},
 row:c=>{const e=[],n=sv(c[0]).trim(),tipo=findCI(LOCL(CP_TIPOS),sv(c[1])),cal=findCI(CALIFS,sv(c[2])),cupo=numP(c[3]);
  if(!n)e.push('el nombre es obligatorio');else if(MM_CP.some(x=>normH(x.name)===normH(n)))e.push('la contraparte "'+n+'" ya existe');if(!tipo)e.push('el tipo "'+sv(c[1])+'" no es válido');if(!cal)e.push('la calificación "'+sv(c[2])+'" no está en el catálogo');if(!(cupo>0))e.push('el cupo debe ser un número mayor a 0');
  return e.length?{e}:{d:{name:n,tipo,calif:cal,cupo,activo:true}}},
 add:d=>MM_CP.unshift(d)};
/* Ejemplos con datos de demostración (todas las filas son válidas) */
MASS.fixed.demo=()=>{const I=INSTR_NAMES;return [[FUNDS[1],'COMPRA',I[3],'2000000','10.25','2050000'],[FUNDS[1],'COMPRA',I[4],'1500000','10.40','1560000'],[FUNDS[0],'COMPRA',I[5],'3000000','10.10','3030000'],[FUNDS[7],'COMPRA',I[3],'5000000','11.05','5250000'],[FUNDS[1],'VENTA',I[4],'800000','10.30','824000'],[FUNDS[4],'COMPRA',I[5],'2500000','10.55','2590000']]};
MASS.variable.demo=()=>{const V=VI_LIST();return [[FUNDS[5],'COMPRA',V[0],'LIMITE','10000','2500'],[FUNDS[5],'COMPRA',V[1],'MERCADO','8000',''],[FUNDS[6],'COMPRA',V[2],'LIMITE','15000','3100'],[FUNDS[5],'VENTA',V[0],'MERCADO','5000',''],[FUNDS[6],'COMPRA',V[3],'LIMITE','12000','1850'],[FUNDS[5],'COMPRA',V[4],'MERCADO','6000','']]};
MASS.instr.demo=()=>{const T=TIPOS(),M=MONEDAS(),I=ISSUERS;return [[loc('TFIT2027A'),T[3],'XX0000000001',M[0],'7.25','SV','2024-01-15','2027-06-15',I[0],'AAA'],[loc('TFIT2029B'),T[3],'XX0000000002',M[0],'8.10','SV','2024-03-10','2029-03-10',I[1],'AAA'],[loc('CDT2026C'),T[1],'XX0000000003',M[0],'10.85','AV','2026-06-01','2026-12-01',I[2],'AA+'],[loc('TFIT2031D'),T[3],'XX0000000004',M[0],'9.40','SV','2025-02-20','2031-02-20',I[3],'AA'],[loc('BONO2030E'),T[0],'XX0000000005',M[0],'6.75','MV','2025-08-05','2030-08-05',I[4],'AAA']]};
MASS.bench.demo=()=>{const B=BENCH_COMPS;return [[FUNDS[8],'Benchmark Monetario Demo',B[0],'70','2026-09-01'],[FUNDS[8],'Benchmark Monetario Demo',B[2],'30','2026-09-01'],[FUNDS[0],'Benchmark Liquidez Demo',B[1],'60','2026-09-01'],[FUNDS[0],'Benchmark Liquidez Demo',B[2],'40','2026-09-01']]};

/* ---------- Órdenes › Mercado monetario ---------- */
const togMM=r=>({title:'Anular operación',danger:true,message:'Vas a anular la operación de <b>'+esc(r.op)+'</b> de <b>'+esc(r.port)+'</b> con <b>'+esc(r.cp)+'</b> por <b>'+money(r.nominal)+'</b>. Esta acción no se puede deshacer.',confirm:'Anular',done:'Operación anulada correctamente.',apply:()=>{r.estatus='A'}});
const sentB=s=>badge(s,s===MM_SENT[0]?'info':'warning');
const venMM=r=>r.fecha+r.plazo*864e5;
PAGES.mm=crudPage({title:'Mercado monetario',help:'Registra y administra las operaciones de corto plazo: depósitos a término, repos, interbancarios, overnight y títulos de deuda pública de corto plazo.',mass:MASS.mm,apoya:APO.mm,dateRange:{k:'fecha',label:'fecha de creación'},entity:'operación monetaria',entityArt:'La operación',fileName:'mercado-monetario',defaultSort:'Creado',defaultDir:-1,searchPh:'Portafolio, operación o contraparte...',noun:'operaciones',
 filters:[{id:'port',label:'Portafolio',opts:()=>FUNDS.slice(),get:r=>r.port},{id:'op',label:'Operación',opts:()=>MM_OPS(),get:r=>r.op},{id:'sent',label:'Sentido',opts:()=>MM_SENT,get:r=>r.sentido},filtOrd[1]],kpis:kpiOrd,
 cols:[{h:'Portafolio',k:'port'},{h:'Operación',k:'op',html:r=>badge(r.op,'neutral'),txt:r=>r.op},{h:'Sentido',k:'sentido',html:r=>sentB(r.sentido),txt:r=>r.sentido},{h:'Contraparte',k:'cp'},{h:'Valor nominal',k:'nominal',fmt:f0},{h:'Tasa E.A.',k:'tasa',fmt:v=>pc2(v*100)},{h:'Plazo (días)',k:'plazo'},{h:'Vencimiento',k:'fecha',html:r=>fmtD(venMM(r)),txt:r=>fmtD(venMM(r)),sv:venMM,sortable:true},{h:'Creado',k:'fecha',fmt:dstr,sortable:true}],
 rows:()=>MM_ORDERS,acts:actsOrd,estado:estOrd,toggle:togMM,
 detail:r=>[['Portafolio',esc(r.port)],['Operación',esc(r.op)],['Sentido',r.sentido],['Contraparte',esc(r.cp)],['Valor nominal',money(r.nominal)],['Tasa E.A.',pc2(r.tasa*100)],['Plazo',r.plazo+' días'],['Vencimiento',fmtD(venMM(r))],['Creada',dstr(r.fecha)],['Estado',ESTADO_ORD[r.estatus][0]]],badges:r=>sentB(r.sentido)+' '+estOrd(r),detailTitle:r=>'Operación · '+r.op,
 form:row=>({html:'<div class="mk-formgrid">'+radiosF('sent','Sentido',MM_SENT,row?row.sentido:MM_SENT[0],{req:true,tip:'Inversión: el portafolio coloca recursos. Captación: el portafolio toma recursos.'})+selF('op','Operación',MM_OPS(),row&&row.op,{req:true})+selF('port','Portafolio',FUNDS,row&&row.port,{req:true})+selF('cp','Contraparte',cpNames(),row&&row.cp,{req:true,tip:'Solo contrapartes activas del maestro de Contrapartes y cupos.'})+inpF('nominal','Valor nominal',row?row.nominal.toFixed(2):'0.00',{req:true})+inpF('rate','Tasa E.A.',row?(row.tasa*100).toFixed(2)+'%':'0.00%',{req:true})+inpF('plazo','Plazo (días)',row?String(row.plazo):'',{req:true,ph:'Ej: 30'})+'</div><div class="mk-help mk-mt" id="cpinfo">Selecciona una contraparte para ver su cupo disponible.</div>',
  bind:f=>{bindMask(f,'nominal',mask.qty);bindMask(f,'rate',mask.rate);const up=()=>{const n=$('[name=cp]',f).value;$('#cpinfo',f).innerHTML=n?cupoTxt(n):'Selecciona una contraparte para ver su cupo disponible.'};$('[name=cp]',f).addEventListener('change',up);up()},
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[],nom=okNum(g('nominal')),tasa=okNum(g('rate')),pl=parseInt(g('plazo'),10),sent=rv(f,'sent');if(!g('op'))errs.push(['op','Selecciona la operación','Operación']);if(!g('port'))errs.push(['port','Selecciona un portafolio','Portafolio']);if(!g('cp'))errs.push(['cp','Selecciona la contraparte','Contraparte']);if(!(nom>0))errs.push(['nominal','El valor debe ser mayor a 0','Valor nominal']);if(!(tasa>0&&tasa<=100))errs.push(['rate','Ingresa una tasa entre 0 y 100','Tasa']);if(!(pl>=1))errs.push(['plazo','El plazo debe ser de 1 día o más','Plazo']);
   if(g('cp')&&sent===MM_SENT[0]&&nom>0){const av=cpAvail(g('cp')),prev=(row&&row.cp===g('cp')&&row.sentido===MM_SENT[0]&&row.estatus!=='A')?0:0;if(nom>av+prev)errs.push(['cp','Supera el cupo disponible ('+money(Math.max(0,av))+')','Cupo de contraparte'])}
   if(errs.length)return {ok:false,errs};return {ok:true,data:{estatus:row?row.estatus:'R',port:g('port'),op:g('op'),sentido:sent,cp:g('cp'),nominal:nom,tasa:tasa/100,plazo:pl,fecha:row?row.fecha:Date.now()}}}}),
 review:d=>[['Sentido',d.sentido],['Operación',d.op],['Portafolio',d.port],['Contraparte',d.cp],['Valor nominal',money(d.nominal)],['Tasa E.A.',pc2(d.tasa*100)],['Plazo',d.plazo+' días']],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else MM_ORDERS.unshift(o)}
});

/* ---------- Órdenes › Reportes (Libro de órdenes) ---------- */
const ordNum=(p,o)=>p+'-'+String(1000+hash(p+o.port+(o.instr||o.op)+o.fecha+o.cant)%9000);
const bookRows=()=>FI_ORDERS.map(o=>({mercado:'Renta fija',num:ordNum('RF',o),fecha:o.fecha,port:o.port,tipo:o.tipo,instr:o.instr,cp:'—',cant:o.cant,tasa:o.tasa,plazo:null,valor:o.valor,estatus:o.estatus}))
 .concat(VI_ORDERS.map(o=>({mercado:'Renta variable',num:ordNum('RV',o),fecha:o.fecha,port:o.port,tipo:o.tipo,instr:o.instr,cp:'—',cant:o.cant,tasa:null,plazo:null,valor:o.valor,estatus:o.estatus})))
 .concat(MM_ORDERS.map(o=>({mercado:'Mercado monetario',num:ordNum('MM',{port:o.port,op:o.op,fecha:o.fecha,cant:o.nominal}),fecha:o.fecha,port:o.port,tipo:o.sentido,instr:o.op,cp:o.cp,cant:o.nominal,tasa:o.tasa,plazo:o.plazo,valor:o.nominal,estatus:o.estatus}))).sort((a,b)=>b.fecha-a.fecha);
const MERC=['Renta fija','Renta variable','Mercado monetario'];
const OREPS=[
 ['book','Libro de órdenes','Renta fija, renta variable y mercado monetario en un solo informe, con su estado.','Operativos',r=>true]
];
const BOOK_COLS=[{h:'N° orden',k:'num',sortable:true},{h:'Mercado',k:'mercado',html:r=>badge(r.mercado,r.mercado===MERC[0]?'success':r.mercado===MERC[1]?'warning':'info'),txt:r=>r.mercado},{h:'Portafolio',k:'port'},{h:'Tipo',k:'tipo',html:r=>r.tipo==='COMPRA'||r.tipo==='VENTA'?side(r.tipo):sentB(r.tipo),txt:r=>r.tipo},{h:'Instrumento / operación',k:'instr'},{h:'Contraparte',k:'cp'},{h:'Cantidad / nominal',k:'cant',fmt:f2},{h:'Tasa',k:'tasa',fmt:v=>v==null?'—':pc2(v*100)},{h:'Plazo (días)',k:'plazo',fmt:v=>v==null?'—':String(v)},{h:'Valor',k:'valor',fmt:money},{h:'Creado',k:'fecha',fmt:dstr,sortable:true}];
PAGES.oreports=function(view,meta){
 const pg=mountPage(view,meta,'Informes','Catálogo de informes de órdenes por categoría'),bc=$('#mkBreadcrumb'),bc0=bc.innerHTML,h1=$('h1',view),help=$('.mk-help',view.querySelector('.mk-headerpage'));
 const setBack=fn=>{const b=$('[data-back]',view),nb=b.cloneNode(true);b.replaceWith(nb);nb.addEventListener('click',fn)};
 const cats=['Operativos','Seguimiento'],st={q:'',cat:''};
 function catalog(){
  bc.innerHTML=bc0;h1.textContent='Informes';help.textContent='Catálogo de informes de órdenes por categoría';setBack(()=>go(meta.grp.home));
  pg.innerHTML='<fieldset class="mk-fieldset"><legend>Filtros</legend><div class="mk-tplfilters mk-filters">'+fld('Buscar reporte','<input class="mk-input" name="q" placeholder="Buscar reporte específico..." value="'+esc(st.q)+'">',{tip:'Escribe parte del nombre o de la descripción del informe.',cls:'mk-field--search'})+fld('Categoría','<div class="mk-combobox"><select class="mk-select" name="cat"><option value="">Todas las categorías</option>'+cats.map(c=>'<option'+(st.cat===c?' selected':'')+'>'+c+'</option>').join('')+'</select></div>',{tip:'Agrupa los informes según su uso: operativos o de seguimiento.'})+'<button class="mk-btn" data-s>Buscar</button><button class="mk-btn mk-btn--secondary" data-l>Limpiar filtros</button></div></fieldset><div class="mk-help mk-mb" id="cnt"></div><div id="grp"></div>';
  const draw=()=>{const q=st.q.toLowerCase(),list=OREPS.filter(r=>(!st.cat||r[3]===st.cat)&&(!q||(r[1]+' '+r[2]).toLowerCase().includes(q)));
   $('#cnt',pg).innerHTML='Mostrando <b>'+list.length+'</b> informes encontrados en '+(st.cat?'la categoría <b>'+st.cat+'</b>':'todas las categorías')+' · país en operación <b>'+S.pais+'</b>';
   $('#grp',pg).innerHTML=list.length?'<div class="mk-repgroup"><span class="mk-repgroup__ico">'+ic('orders')+'</span><div><b>Órdenes</b><div style="font-size:12px;opacity:.9">'+list.length+' reportes</div></div></div><div class="mk-repbody">'+cats.map(c=>{const l=list.filter(r=>r[3]===c);return l.length?'<div class="mk-replbl">'+c+' · '+l.length+' reporte'+(l.length>1?'s':'')+'</div><div class="mk-repgrid">'+l.map(r=>'<button type="button" class="mk-repcard" data-r="'+r[0]+'"><span class="mk-repcard__t">'+esc(r[1])+'</span><span class="mk-repcard__chev">›</span><span class="mk-repcard__d">'+esc(r[2])+'</span></button>').join('')+'</div>':''}).join('')+'</div>':'<div class="mk-card"><div class="mk-empty">Ningún informe coincide con la búsqueda.</div></div>';
   $$('[data-r]',pg).forEach(b=>b.addEventListener('click',()=>report(b.dataset.r)))};
  const apply=()=>{st.q=$('[name=q]',pg).value.trim();st.cat=$('[name=cat]',pg).value;draw()};
  $('[data-s]',pg).addEventListener('click',apply);$('[name=q]',pg).addEventListener('keydown',e=>{if(e.key==='Enter')apply()});
  $('[data-l]',pg).addEventListener('click',()=>{st.q='';st.cat='';catalog()});draw();
 }
 function report(id){
  const rp=OREPS.find(x=>x[0]===id),f={port:'',mercado:'',est:'',tipo:'',d1:isoD(Math.min.apply(null,bookRows().map(r=>r.fecha))),d2:isoD(Math.max(fromIso(OPDATE),Math.max.apply(null,bookRows().map(r=>r.fecha)))),adv:false};
  bc.innerHTML=bc0.replace('<span class="current">Reportes</span>','<a class="crumb" data-go="#/orders/reports">Reportes</a><span class="sep">›</span><span class="current">Informe - '+esc(rp[1])+'</span>');
  h1.textContent='Informe - '+rp[1];help.textContent=rp[2];setBack(catalog);
  const optsHTML=(first,arr,v)=>'<option value="">'+first+'</option>'+arr.map(x=>'<option'+(v===x?' selected':'')+'>'+esc(x)+'</option>').join('');
  pg.innerHTML='<fieldset class="mk-fieldset"><legend>Filtros del informe</legend><div class="mk-tplfilters mk-filters">'
   +fld('Portafolio','<div class="mk-combobox"><select class="mk-select" name="port">'+optsHTML('Todos los portafolios',PNAMES.slice(0,9),f.port)+'</select></div>',{req:true,name:'port',tip:'Con Todos los portafolios el informe entrega las órdenes de todos los portafolios.'})
   +(id==='book'?fld('Mercado','<div class="mk-combobox"><select class="mk-select" name="mercado">'+optsHTML('Todos los mercados',MERC,f.mercado)+'</select></div>',{name:'mercado',tip:'Renta fija, renta variable o mercado monetario.'}):'')
   +rangeFields(f.d1,f.d2,'el informe')
   +'</div>'
   +'<div class="mk-repstrip" style="justify-content:flex-end"><span style="display:flex;gap:10px"><button type="button" class="mk-btn mk-btn--secondary" data-sug>Rango sugerido</button><button type="button" class="mk-btn" data-gen>Generar informe</button></span></div></fieldset><div id="out"></div>';
  bindClear(pg);
  $('[data-sug]',pg).addEventListener('click',()=>{const e=new Date(f.d2+'T12:00:00'),b=new Date(e.getTime()-30*864e5);$('[name=d2]',pg).value=f.d2;$('[name=d1]',pg).value=isoD(b.getTime());toast('Se aplicó el rango sugerido: los últimos 30 días.','info','Rango sugerido')});
  $('[data-gen]',pg).addEventListener('click',()=>{
   const g=n=>{const e=$('[name='+n+']',pg);return e?e.value:''},d1=g('d1'),d2=g('d2');
   if(!d1||!d2){errOn(pg,d1?'d2':'d1','Indica la fecha');toast('Indica la fecha inicial y la final.','warning','Faltan datos');return}
   if(d1>d2){errOn(pg,'d1','La fecha inicial no puede ser posterior a la final');toast('La fecha inicial no puede ser posterior a la final.','warning','Rango inválido');return}
   const a=new Date(d1+'T00:00:00').getTime(),b=new Date(d2+'T23:59:59').getTime();
   const rows=bookRows().filter(rp[4]).filter(r=>(!g('port')||r.port===g('port'))&&(!g('mercado')||r.mercado===g('mercado'))&&r.fecha>=a&&r.fecha<=b);
   const out=$('#out',pg);out.innerHTML='<div class="mk-loading"><div class="mk-spinner"></div></div>';
   setTimeout(()=>{out.innerHTML='<div class="mk-section-title" style="margin:14px 0 8px;font-weight:600;color:var(--mk-primary)">Resultado del informe · '+fmtD(fromIso(d1))+' – '+fmtD(fromIso(d2))+'</div><div id="rt"></div>';
    DataTable($('#rt',out),{cols:BOOK_COLS,rows:()=>rows,acts:()=>[['ver']],estado:estOrd,kpis:rs=>[['Órdenes',rs.length,'p'],['Renta fija',rs.filter(r=>r.mercado===MERC[0]).length,'b'],['Renta variable',rs.filter(r=>r.mercado===MERC[1]).length,'y'],['Mercado monetario',rs.filter(r=>r.mercado===MERC[2]).length,'g'],['Finalizadas',rs.filter(r=>r.estatus==='F').length,'']],fileName:'informe-'+id,defaultSort:'Creado',defaultDir:-1,searchPh:'N° de orden, portafolio, instrumento o contraparte...',noun:'órdenes',
     onAct:(act,r)=>{const m=openModal({title:'Orden · '+r.num,body:'<div style="margin-bottom:10px">'+estOrd(r)+'</div><div class="mk-formgrid">'+[['N° de orden',r.num],['Mercado',r.mercado],['Portafolio',esc(r.port)],['Tipo',r.tipo],['Instrumento / operación',esc(r.instr)],['Contraparte',esc(r.cp)],['Cantidad / nominal',f2(r.cant)],['Tasa',r.tasa==null?'—':pc2(r.tasa*100)],['Plazo',r.plazo==null?'—':r.plazo+' días'],['Valor',money(r.valor)],['Creada',dstr(r.fecha)]].map(x=>fdRow(x[0],x[1])).join('')+'</div>',foot:'<button class="mk-btn mk-btn--secondary" data-c>Cerrar</button>'});$('[data-c]',m.el).addEventListener('click',m.close)}});
    toast(rows.length+' órdenes en el informe.','success','Informe generado')},350)});
 }
 catalog();
};

/* ---------- Dashboard › Mercado monetario (posición, vencimientos y devengo) ---------- */
function mmCalc(port,dt){const fac=dfac(dt),base=fromIso(dt),day=parseInt(dt.slice(8,10),10)||1;
 const rows=MM_POS.filter(p=>p.port===port).map(p=>{const nominal=p.nominal*fac,dev=nominal*(Math.pow(1+p.tasa,1/365)-1);return Object.assign({},p,{nominal,venc:base+p.rest*864e5,devDia:dev,devMes:dev*day})});
 const tot=rows.reduce((a,p)=>a+p.nominal,0)||1,sum=f=>rows.reduce((a,p)=>a+f(p),0);
 return {rows,tot,wam:sum(p=>p.nominal*p.rest)/tot,tasa:sum(p=>p.nominal*p.tasa)/tot,v7:sum(p=>p.rest<=7?p.nominal:0),n7:rows.filter(p=>p.rest<=7).length,liq1:sum(p=>p.rest<=1?p.nominal:0),dev:sum(p=>p.devDia)}}
const MM_BUCKETS=[['1 día',0,1],['2 a 7 días',2,7],['8 a 30 días',8,30],['31 a 90 días',31,90],['Más de 90 días',91,1e9]];
function columnSVG(items){const W=1100,Hh=230,m={l:16,r:16,t:28,b:44},iw=W-m.l-m.r,ih=Hh-m.t-m.b,n=items.length,bw=iw/n*0.5;let mx=0;items.forEach(i=>{mx=Math.max(mx,i.v)});mx=mx||1;
 let g='<line x1="'+m.l+'" x2="'+(W-m.r)+'" y1="'+(Hh-m.b)+'" y2="'+(Hh-m.b)+'" stroke="currentColor" opacity=".4"/>';
 items.forEach((it,i)=>{const x=m.l+iw/n*i+(iw/n-bw)/2,h=ih*it.v/mx,y=Hh-m.b-h;g+='<rect x="'+x+'" y="'+y+'" width="'+bw+'" height="'+Math.max(h,1)+'" rx="3" fill="#6A1B9A"><title>'+esc(it.l)+': '+f0(it.v)+'</title></rect><text x="'+(x+bw/2)+'" y="'+(y-7)+'" text-anchor="middle" class="chart-txt" style="font-weight:600">'+f0(it.v/1e6)+' M</text><text x="'+(x+bw/2)+'" y="'+(Hh-m.b+20)+'" text-anchor="middle" class="chart-txt">'+esc(it.l)+'</text>'});
 return '<svg viewBox="0 0 '+W+' '+Hh+'" width="100%" style="display:block;max-height:240px" role="img" aria-label="Escalera de vencimientos">'+g+'</svg>'}
PAGES.mmpos=function(view,meta){
 const pg=mountPage(view,meta,'Mercado monetario','Posición, vencimientos y devengo de las operaciones monetarias por portafolio.');
 const ports=()=>Array.from(new Set(MM_POS.map(p=>p.port)));
 const st={port:FUNDS[0],op:OPDATE,done:true,tab:0};
 const draw=()=>{
  pg.innerHTML=queryBar(opField(st.op)+selF('port','Portafolio',ports(),st.port,{req:true}))+'<div id="res"></div>';
  $('[name=port]',pg).addEventListener('change',e=>st.port=e.target.value);bindClear(pg);bindOp(pg,st,()=>{if(st.done)result()});
  $('[data-clear]',pg).addEventListener('click',()=>{st.port='';st.done=false;st.op=OPDATE;draw()});
  $('[data-consult]',pg).addEventListener('click',()=>{if(!st.port){errOn(pg,'port','Selecciona un portafolio para consultar');toast('Selecciona un portafolio.','warning','Falta un dato');return}st.done=true;result()});
  if(st.done)result();else $('#res',pg).innerHTML='<div class="mk-card"><div class="mk-emptybig"><div class="mk-emptybig__ico">'+ic('coins','xl')+'</div><div class="mk-emptybig__t">Aún no hay resultados</div><div class="mk-emptybig__d">Elige un portafolio y pulsa Consultar.</div></div></div>';
 };
 function result(){
  const c=mmCalc(st.port,st.op),r=$('#res',pg),det=x=>{const m=openModal({title:'Detalle de la operación',body:'<div class="mk-formgrid">'+fdRow('Operación',esc(x.op))+fdRow('Contraparte',esc(x.cp))+fdRow('Valor nominal',money(x.nominal))+fdRow('Tasa E.A.',pct(x.tasa,2))+fdRow('Plazo',x.plazo+' días')+fdRow('Días al vencimiento',x.rest)+fdRow('Vencimiento',fmtD(x.venc))+fdRow('Devengo del día',money(x.devDia))+'</div>',foot:'<button class="mk-btn mk-btn--secondary" data-c>Cerrar</button>'});$('[data-c]',m.el).addEventListener('click',m.close)};
  r.innerHTML='<div class="mk-kpis">'+kpiBox('Saldo monetario',f0(c.tot),'p','Suma de las operaciones vigentes del portafolio')+kpiBox('Plazo promedio ponderado',f1(c.wam)+' días','b','Días al vencimiento ponderados por valor. Tope de política: 90 días.')+kpiBox('Tasa promedio E.A.','<span class="pos">'+pct(c.tasa,2)+'</span>','g','Tasa efectiva anual ponderada por valor')+kpiBox('Vence en 7 días',f0(c.v7)+' · '+c.n7+' op.','y','Recursos que se liberan en la próxima semana')+kpiBox('Liquidez a 1 día',pct(c.liq1/c.tot,1),'','Porción del saldo que vence al día siguiente')+'</div><div id="tabs"></div>';
  tabsUI($('#tabs',r),['Posición vigente','Escalera de vencimientos','Devengo y rentabilidad'],st,(i,p)=>{
   if(i===0){p.innerHTML='<div id="t"></div>';DataTable($('#t',p),{cols:[{h:'Operación',k:'op',html:x=>badge(x.op,'neutral'),txt:x=>x.op,sortable:true},{h:'Contraparte',k:'cp',sortable:true},{h:'Valor nominal',k:'nominal',fmt:f0,sortable:true},{h:'Tasa E.A.',k:'tasa',fmt:v=>pct(v,2),sortable:true},{h:'Plazo (días)',k:'plazo'},{h:'Días al vencimiento',k:'rest',sortable:true},{h:'Vencimiento',k:'venc',fmt:fmtD,sortable:true},{h:'Devengo del día',k:'devDia',fmt:f0}],rows:()=>c.rows,acts:()=>[['ver']],onAct:(a,x)=>det(x),searchPh:'Operación o contraparte...',fileName:'posicion-monetaria',defaultSort:'Días al vencimiento',noun:'operaciones',totals:rows=>['Total','',f0(rows.reduce((a,x)=>a+x.nominal,0)),pct(c.tasa,2),'',f1(c.wam),'',f0(rows.reduce((a,x)=>a+x.devDia,0))]})}
   else if(i===1){const items=MM_BUCKETS.map(b=>({l:b[0],v:c.rows.filter(x=>x.rest>=b[1]&&x.rest<=b[2]).reduce((a,x)=>a+x.nominal,0),n:c.rows.filter(x=>x.rest>=b[1]&&x.rest<=b[2]).length}));
    p.innerHTML='<div class="mk-card mk-mb"><h3 style="margin:0 0 6px;font-size:14px">Vencimientos por rango (valor en millones)</h3>'+columnSVG(items)+'</div><div id="b"></div>';
    DataTable($('#b',p),{cols:[{h:'Rango de vencimiento',k:'l'},{h:'Valor',k:'v',fmt:f0},{h:'% del saldo',k:'pc',fmt:v=>pct(v,1)},{h:'Operaciones',k:'n'}],rows:()=>items.map(x=>Object.assign({pc:x.v/c.tot},x)),noPage:true,noFilters:true,noFoot:true,fileName:'escalera-vencimientos',totals:rows=>['Total',f0(c.tot),'100,0 %',String(c.rows.length)]})}
   else{p.innerHTML='<div class="mk-kpis"><div class="mk-kpi mk-kpi--g"><div class="mk-kpi__l">Devengo del día</div><div class="mk-kpi__v">'+f0(c.dev)+'</div></div><div class="mk-kpi mk-kpi--b"><div class="mk-kpi__l">Rentabilidad diaria</div><div class="mk-kpi__v">'+pct(Math.pow(1+c.tasa,1/365)-1,4)+'</div></div><div class="mk-kpi mk-kpi--p"><div class="mk-kpi__l">Rentabilidad E.A.</div><div class="mk-kpi__v">'+pct(c.tasa,2)+'</div></div></div><div id="d"></div>';
    DataTable($('#d',p),{cols:[{h:'Operación',k:'op',html:x=>badge(x.op,'neutral'),txt:x=>x.op},{h:'Contraparte',k:'cp'},{h:'Valor nominal',k:'nominal',fmt:f0},{h:'Tasa E.A.',k:'tasa',fmt:v=>pct(v,2)},{h:'Devengo del día',k:'devDia',fmt:f0,tip:'Valor × ((1 + tasa E.A.)^(1/365) − 1)'},{h:'Devengo acumulado del mes',k:'devMes',fmt:f0},{h:'% del saldo',k:'pc',fmt:v=>pct(v,1)}],rows:()=>c.rows.map(x=>Object.assign({pc:x.nominal/c.tot},x)),searchPh:'Operación o contraparte...',fileName:'devengo-monetario',noun:'operaciones',totals:rows=>['Total','',f0(rows.reduce((a,x)=>a+x.nominal,0)),pct(c.tasa,2),f0(rows.reduce((a,x)=>a+x.devDia,0)),f0(rows.reduce((a,x)=>a+x.devMes,0)),'100,0 %']})}
  });
 }
 draw();
};

/* ---------- Parametrización › Contrapartes y cupos / Tasas de referencia ---------- */
const cpBar=r=>{const u=cpUtil(r);return '<div style="min-width:110px">'+pc2(u*100)+'<div class="mk-util"><div class="mk-util__b'+(u>=1?' hi':'')+'" style="width:'+Math.min(100,u*100)+'%"></div></div></div>'};
PAGES.pcp=crudPage({title:'Contrapartes y cupos',help:'Entidades con las que se opera en mercado monetario y el cupo autorizado para cada una.',apoya:APO.cp,entity:'contraparte',entityArt:'La contraparte',fileName:'contrapartes-cupos',defaultSort:'Contraparte',searchPh:'Nombre de la contraparte...',noun:'contrapartes',
 filters:[{id:'t',label:'Tipo',opts:()=>LOCL(CP_TIPOS),get:r=>r.tipo},{id:'e',label:'Estado',opts:()=>['Activo','Inactivo'],get:r=>r.activo?'Activo':'Inactivo'}],
 kpis:rows=>[['Contrapartes',rows.length,'p'],['Activas',rows.filter(r=>r.activo).length,'g'],['Cupo total activo',f0(rows.filter(r=>r.activo).reduce((a,r)=>a+r.cupo,0)),'b'],['Cupo en alerta (90 % o más)',rows.filter(r=>r.activo&&cpUtil(r)>=0.9).length,'y']],
 cols:[{h:'Contraparte',k:'name',sortable:true},{h:'Tipo',k:'tipo'},{h:'Calificación',k:'calif'},{h:'Cupo autorizado',k:'cupo',fmt:f0,sortable:true},{h:'Utilizado',sv:r=>cpUsed(r.name),num:r=>cpUsed(r.name),html:r=>f0(cpUsed(r.name)),txt:r=>f0(cpUsed(r.name))},{h:'Disponible',sv:r=>r.cupo-cpUsed(r.name),num:r=>r.cupo-cpUsed(r.name),html:r=>f0(r.cupo-cpUsed(r.name)),txt:r=>f0(r.cupo-cpUsed(r.name))},{h:'Utilización',sv:cpUtil,html:cpBar,txt:r=>pc2(cpUtil(r)*100),tip:'Operaciones vigentes dividido por el cupo autorizado. En alerta desde 90 %.'}],
 rows:()=>MM_CP,estado:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral',true),acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar contraparte',danger:true,message:'Vas a inactivar <b>'+esc(r.name)+'</b>. No podrá elegirse en nuevas operaciones'+(cpUsed(r.name)?'; las posiciones vigentes por <b>'+money(cpUsed(r.name))+'</b> no se modifican':'')+'.',confirm:'Inactivar',done:'Contraparte inactivada.',apply:()=>{r.activo=false}}:{title:'Activar contraparte',message:'¿Deseas activar <b>'+esc(r.name)+'</b> para operar?',confirm:'Activar',done:'Contraparte activada.',apply:()=>{r.activo=true}},
 detail:r=>[['Contraparte',esc(r.name)],['Tipo',r.tipo],['Calificación',r.calif],['Cupo autorizado',money(r.cupo)],['Utilizado',money(cpUsed(r.name))],['Disponible',money(r.cupo-cpUsed(r.name))],['Utilización',pc2(cpUtil(r)*100)]],detailTitle:r=>r.name,badges:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral'),
 extra:(pg,rp)=>{const x=document.createElement('div');x.className='mk-accordion collapsed mk-mt';x.innerHTML='<div class="mk-accordion__head"><span class="mk-accordion__ico">'+ic('upload')+'</span><span><span class="mk-accordion__t">Carga masiva de contrapartes</span><span class="mk-accordion__d">Descarga la estructura y el manual, y carga el archivo</span></span><span class="mk-accordion__chev">&#9662;</span></div><div class="mk-accordion__body">'+massHTML(MASS.cp)+'</div>';pg.appendChild(x);bindAcc(x);bindMass(x,MASS.cp,rp)},
 form:row=>({html:'<div class="mk-formgrid">'+inpF('name','Contraparte',row&&row.name,{req:true,cls:'span2'})+selF('tipo','Tipo',LOCL(CP_TIPOS),row&&row.tipo,{req:true})+selF('calif','Calificación',CALIFS,row&&row.calif,{req:true})+inpF('cupo','Cupo autorizado',row?String(row.cupo):'',{req:true,ph:'Ej: 5000000000'})+'</div>',
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[],cupo=okNum(g('cupo'));if(!g('name'))errs.push(['name','Indica el nombre','Contraparte']);else if(MM_CP.some(x=>x!==row&&normH(x.name)===normH(g('name'))))errs.push(['name','Ya existe una contraparte con ese nombre','Contraparte']);if(!g('tipo'))errs.push(['tipo','Selecciona el tipo','Tipo']);if(!g('calif'))errs.push(['calif','Selecciona la calificación','Calificación']);if(!(cupo>0))errs.push(['cupo','El cupo debe ser mayor a 0','Cupo']);if(errs.length)return {ok:false,errs};return {ok:true,data:{name:g('name'),tipo:g('tipo'),calif:g('calif'),cupo,activo:row?row.activo:true}}}}),
 review:d=>[['Contraparte',d.name],['Tipo',d.tipo],['Calificación',d.calif],['Cupo autorizado',money(d.cupo)]],
 onSave:(o,row)=>{if(row){if(row.name!==o.name){MM_POS.forEach(p=>{if(p.cp===row.name)p.cp=o.name});MM_ORDERS.forEach(p=>{if(p.cp===row.name)p.cp=o.name})}Object.assign(row,o)}else MM_CP.unshift(o)}
});
PAGES.prates=crudPage({title:'Tasas de referencia',help:'Tasas de mercado que se usan para valorar, comparar y explicar el desempeño monetario.',apoya:APO.rates,entity:'tasa de referencia',entityArt:'La tasa',fileName:'tasas-referencia',defaultSort:'Tasa',searchPh:'Código, descripción o fuente...',noun:'tasas',
 filters:[{id:'e',label:'Estado',opts:()=>['Activo','Inactivo'],get:r=>r.activo?'Activo':'Inactivo'}],
 kpis:rows=>[['Tasas',rows.length,'p'],['Activas',rows.filter(r=>r.activo).length,'g'],['Tasa más alta (E.A.)',pct((rows.length?Math.max.apply(null,rows.map(r=>r.valor)):0)/100,2),'b']],
 cols:[{h:'Tasa',k:'code',sortable:true},{h:'Descripción',k:'desc'},{h:'Valor (E.A.)',k:'valor',fmt:v=>pct(v/100,2)},{h:'Vigente desde',k:'desde',fmt:fmtD},{h:'Fuente',k:'fuente'}],
 rows:()=>MM_RATES,estado:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral',true),acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar tasa',danger:true,message:'Vas a inactivar <b>'+esc(r.code)+'</b>. Dejará de usarse para comparar y valorar operaciones monetarias.',confirm:'Inactivar',done:'Tasa inactivada.',apply:()=>{r.activo=false}}:{title:'Activar tasa',message:'¿Deseas activar <b>'+esc(r.code)+'</b>?',confirm:'Activar',done:'Tasa activada.',apply:()=>{r.activo=true}},
 detail:r=>[['Tasa',esc(r.code)],['Descripción',esc(r.desc)],['Valor (E.A.)',pct(r.valor/100,2)],['Vigente desde',fmtD(r.desde)],['Fuente',esc(r.fuente)]],detailTitle:r=>r.code,badges:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral'),
 form:row=>({html:'<div class="mk-formgrid">'+inpF('code','Tasa',row&&row.code,{req:true})+inpF('valor','Valor (% E.A.)',row?String(row.valor):'',{req:true,ph:'Ej: 10.25'})+inpF('desc','Descripción',row&&row.desc,{req:true,cls:'span2'})+dateF('desde','Vigente desde',row?row.desde:OPDATE_TS(),{req:true})+inpF('fuente','Fuente',row&&row.fuente)+'</div>',
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[],v=okNum(g('valor'));if(!g('code'))errs.push(['code','Indica el código','Tasa']);if(!g('desc'))errs.push(['desc','Indica la descripción','Descripción']);if(!(v>0&&v<=100))errs.push(['valor','Ingresa un valor entre 0 y 100','Valor']);const d=fromIso(g('desde'));if(!d)errs.push(['desde','Indica la fecha','Vigencia']);if(errs.length)return {ok:false,errs};return {ok:true,data:{code:g('code'),desc:g('desc'),valor:v,desde:d,fuente:g('fuente'),activo:row?row.activo:true}}}}),
 review:d=>[['Tasa',d.code],['Descripción',d.desc],['Valor (E.A.)',pct(d.valor/100,2)],['Vigente desde',fmtD(d.desde)],['Fuente',d.fuente||'—']],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else MM_RATES.unshift(o)}
});
function OPDATE_TS(){return fromIso(OPDATE)}

/* --- Carga de archivos --- */
function fileUp(id){return '<div class="mk-fileupload" data-up="'+id+'" tabindex="0" role="button"><strong>Arrastra los archivos aquí</strong> o haz clic para seleccionarlos<div class="mk-help">CSV o XLSX</div><input type="file" multiple hidden></div><div data-files="'+id+'" class="mk-mt"></div>'}
function bindFile(root){$$('[data-up]',root).forEach(z=>{const inp=$('input',z),list=$('[data-files="'+z.dataset.up+'"]',root);const show=fs=>{if(!fs.length)return;list.innerHTML=[].slice.call(fs).map(f=>'<div class="mk-tagsoft">'+esc(f.name)+' · '+Math.max(1,Math.round(f.size/1024))+' KB</div>').join('');toast(fs.length+' archivo(s) listo(s) para procesar.','success','Archivo cargado')};z.addEventListener('click',()=>inp.click());z.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();inp.click()}});inp.addEventListener('change',()=>show(inp.files));['dragover','dragenter'].forEach(ev=>z.addEventListener(ev,e=>{e.preventDefault();z.classList.add('is-over')}));['dragleave','drop'].forEach(ev=>z.addEventListener(ev,e=>{e.preventDefault();z.classList.remove('is-over')}));z.addEventListener('drop',e=>show(e.dataTransfer.files))})}
function bindAcc(a){$('.mk-accordion__head',a).addEventListener('click',()=>a.classList.toggle('collapsed'))}

/* =============== Páginas de consulta (Consultar / Limpiar) =============== */
function queryBar(fieldsHTML,canClear){return '<div class="mk-tplfilters mk-filters">'+fieldsHTML+'<button class="mk-btn" data-consult>'+ic('search')+'Consultar</button><button class="mk-btn mk-btn--secondary" data-clear>Limpiar</button></div>'}
function multiSel(id,label,opts,sel,max){return '<div class="mk-field" data-ms="'+id+'"><label class="mk-label"><span>'+label+'</span>'+info('Elige hasta '+max+' métricas para graficar.')+'</label><div class="mk-multiselect"><button type="button" class="mk-msbtn"><span>'+(sel.length?sel.map(k=>opts.find(o=>o[0]===k)[1]).join(', '):'Seleccionar...')+'</span>'+ic('chevron')+'</button><div class="mk-mspanel">'+opts.map(o=>{const on=sel.includes(o[0]);return '<label class="mk-msopt"><input type="checkbox" value="'+o[0]+'"'+(on?' checked':'')+(!on&&sel.length>=max?' disabled':'')+'><span><span class="mk-msopt__n">'+o[1]+'</span></span></label>'}).join('')+'</div></div></div>'}
const GRAPHS=[['macro','Macroactivo'],['sub','Subactivo'],['moneda','Moneda'],['plazo','Plazo'],['clase','Clase de inversión'],['calif','Calificación'],['emisor','Emisor']];
PAGES.graphics=function(view,meta){
 const pg=mountPage(view,meta,'Visor de portafolio','Consulta gráficas interactivas por portafolio.');
 const st={port:FUNDS[1],sel:['calif','emisor','moneda'],done:true,op:OPDATE};
 const draw=()=>{
  pg.innerHTML=queryBar(opField(st.op)+fld('Portafolio',  '<div class="mk-combobox"><select class="mk-select" name="port"><option value="">Seleccionar</option>'+PNAMES.map(n=>'<option'+(n===st.port?' selected':'')+'>'+esc(n)+'</option>').join('')+'</select></div>',{req:true,name:'port'})+multiSel('g','Gráficos',GRAPHS,st.sel,3))+'<div id="res"></div>';
  const sel=$('[name=port]',pg);sel.addEventListener('change',()=>{st.port=sel.value;clearErr(sel)});bindOp(pg,st,()=>{if(st.done)result()});
  const ms=$('[data-ms] .mk-multiselect',pg);$('.mk-msbtn',ms).addEventListener('click',e=>{e.stopPropagation();ms.classList.toggle('open')});$('.mk-mspanel',ms).addEventListener('click',e=>e.stopPropagation());
  $$('input',ms).forEach(c=>c.addEventListener('change',()=>{st.sel=$$('input:checked',ms).map(x=>x.value);const open=true;draw();$('.mk-multiselect',pg).classList.add('open')}));
  $('[data-clear]',pg).addEventListener('click',()=>{st.port='';st.sel=[];st.done=false;st.op=OPDATE;draw()});
  $('[data-consult]',pg).addEventListener('click',()=>{if(!st.port){errOn(pg,'port','Selecciona un portafolio para consultar');toast('Selecciona un portafolio.','warning','Falta un dato');return}st.done=true;const r=$('#res',pg);r.innerHTML='<div class="mk-loading"><div class="mk-spinner"></div></div>';setTimeout(result,350)});
  if(st.done)result();else $('#res',pg).innerHTML='<div class="mk-card"><div class="mk-emptybig"><div class="mk-emptybig__ico">'+ic('pie','xl')+'</div><div class="mk-emptybig__t">Aún no hay resultados</div><div class="mk-emptybig__d">Selecciona un portafolio y pulsa Consultar.</div></div></div>';
 };
 function result(){
  const fac=dfac(st.op),data=holdingsFor(st.port).map(h=>Object.assign({},h,{val:h.val*fac})),r=$('#res',pg);
  r.innerHTML='<div class="mk-grid cols-3 mk-mb" id="gc"></div><div id="gt"></div>';
  $('#gc',r).innerHTML=[0,1,2].map(i=>{const k=st.sel[i];if(!k)return '<div class="mk-card" style="border-style:dashed;display:flex;align-items:center;justify-content:center;min-height:200px;box-shadow:none"><span class="mk-help">Selecciona la '+['1ª','2ª','3ª'][i]+' métrica</span></div>';const name=GRAPHS.find(g=>g[0]===k)[1],agg={};data.forEach(h=>{agg[h[k]]=(agg[h[k]]||0)+h.val});const d=Object.keys(agg).map(n=>({name:n,value:agg[n]}));return '<div class="mk-card"><h3 style="margin:0 0 6px;font-size:14px">'+name+'</h3>'+pieSVG(d)+'<div class="mk-accordion collapsed mk-mt"><div class="mk-accordion__head"><span class="mk-accordion__t">Leyendas</span><span class="mk-accordion__chev">&#9662;</span></div><div class="mk-accordion__body" style="max-height:160px;overflow:auto">'+d.map((x,j)=>'<div style="display:flex;gap:8px;margin-bottom:8px"><span style="width:11px;height:11px;border-radius:50%;background:'+PALETTE[j%PALETTE.length]+';margin-top:4px;flex:none"></span><div><div>'+esc(x.name)+'</div><div class="mk-help">'+f0(x.value)+'</div></div></div>').join('')+'</div></div></div>'}).join('');
  $$('.mk-accordion',r).forEach(bindAcc);
  DataTable($('#gt',r),{cols:[{h:'Macroactivo',k:'macro',sortable:true},{h:'Subactivo',k:'sub',sortable:true},{h:'Moneda',k:'moneda',sortable:true},{h:'Plazo',k:'plazo',sortable:true},{h:'Clase de inversión',k:'clase',sortable:true},{h:'Calificación',k:'calif',sortable:true},{h:'Emisor',k:'emisor',sortable:true},{h:'Valoración moneda local',k:'val',fmt:f2,sortable:true}],rows:()=>data,noPage:true,fileName:'visor-portafolio',searchPh:'Filtrar posiciones...',defaultSort:'Macroactivo'});
  const tb=$('#gt',r);const bar=document.createElement('div');bar.className='mk-tplfilters mk-filters';bar.innerHTML='<div class="mk-field mk-field--search"><label class="mk-label">Buscar</label><input class="mk-input" placeholder="Filtrar posiciones..."></div>';
 }
 draw();
};
PAGES.flows=function(view,meta){
 const pg=mountPage(view,meta,'Flujos futuros','Revisa los flujos proyectados por instrumento.');
 const st={port:FUNDS[1],year:'2026',done:true,op:OPDATE};
 const draw=()=>{
  pg.innerHTML=queryBar(opField(st.op)+selF('port','Portafolio',FUNDS,st.port,{req:true})+selF('year','Año',['2026','2027','2028','2029','2030'],st.year,{req:true}))+'<div id="res"></div>';
  $('[name=port]',pg).addEventListener('change',e=>st.port=e.target.value);$('[name=year]',pg).addEventListener('change',e=>st.year=e.target.value);bindClear(pg);bindOp(pg,st,()=>{if(st.done)result()});
  $('[data-clear]',pg).addEventListener('click',()=>{st.port='';st.year='';st.done=false;st.op=OPDATE;draw()});
  $('[data-consult]',pg).addEventListener('click',()=>{const errs=[];if(!st.port){errOn(pg,'port');errs.push('Portafolio')}if(!st.year){errOn(pg,'year');errs.push('Año')}if(errs.length){toast('Completa: '+errs.join(', ')+'.','warning','Faltan datos');return}st.done=true;result()});
  if(st.done)result();else $('#res',pg).innerHTML='<div class="mk-card"><div class="mk-emptybig"><div class="mk-emptybig__ico">'+ic('flows','xl')+'</div><div class="mk-emptybig__t">Aún no hay resultados</div><div class="mk-emptybig__d">Elige portafolio y año, y pulsa Consultar.</div></div></div>';
 };
 function result(){const f=dfac(st.op),rows=flowsFor(st.port,st.year).map(r=>Object.assign({},r,{desc:r.desc*f,ibr:r.ibr*f,ipc:r.ipc*f,tf:r.tf*f,uvr:r.uvr*f,uf:r.uf*f,total:r.total*f,acum:r.acum*f}));DataTable($('#res',pg),{cols:[{h:'Mes',k:'mes'},{h:'Año',k:'anio'},{h:'DESCUENTO',k:'desc',fmt:f2},{h:loc('IBR'),k:'ibr',fmt:f2},{h:'IPC',k:'ipc',fmt:f2},{h:'TASA FIJA',k:'tf',fmt:f2},{h:loc('UVR'),k:'uvr',fmt:f2},{h:loc('DTF'),k:'uf',fmt:f2},{h:'Total Mes',k:'total',fmt:f2},{h:'Acumulado',k:'acum',fmt:f2,tip:'Suma de los flujos desde enero'}],rows:()=>rows,noPage:true,noFilters:true,fileName:'flujos-futuros',noun:'meses'})}
 draw();
};
PAGES.sens=crudPage({title:'Medidas de sensibilidad',help:'Analiza duración, convexidad y DV01.',noNew:true,fileName:'medidas-sensibilidad',searchPh:'Portafolio...',noun:'portafolios',defaultSort:'Portafolio',
 cols:[{h:'Portafolio',k:'port',sortable:true},{h:'Valoración moneda local',k:'val',fmt:f2},{h:'Duración',k:'dur',fmt:f3,tip:'Plazo promedio ponderado de los flujos, en años'},{h:'Duración modificada',k:'mdur',fmt:f3,tip:'Sensibilidad del precio a un cambio de 1% en la tasa'},{h:'Convexidad',k:'conv',fmt:f3,tip:'Curvatura de la relación precio-tasa'},{h:'DV01',k:'dv01',fmt:f3,tip:'Cambio en valor por +1 punto básico de tasa'}],
 rows:st=>{const f=dfac((st&&st.op)||OPDATE);return SENS.map(r=>Object.assign({},r,{val:r.val*f}))},opDate:true,acts:()=>[['ver']],filters:[{id:'p',label:'Portafolio',opts:()=>PNAMES.slice(0,9),get:r=>r.port}],kpis:rows=>[['Portafolios',rows.length,'p'],['Duración promedio',f2(rows.reduce((a,r)=>a+r.dur,0)/(rows.length||1)),'b'],['DV01 total',f0(rows.reduce((a,r)=>a+r.dv01,0)),'g']],
 detail:r=>[['Portafolio',esc(r.port)],['Valoración moneda local',f2(r.val)],['Duración',f3(r.dur)+' años'],['Duración modificada',f3(r.mdur)],['Convexidad',f3(r.conv)],['DV01',f3(r.dv01)]],detailTitle:r=>r.port,
 form:()=>({html:'',read:()=>({ok:false})}),review:()=>[],onSave:()=>{},entity:'',entityArt:''
});

/* =============== PERFORMANCE ATTRIBUTION =============== */
const MES_TXT=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
function paPage(title,help,build,opts){
 opts=opts||{};
 return function(view,meta){
  const pg=mountPage(view,meta,title,help);
  const def=()=>({port:opts.port||FUNDS[1],d1:'2026-01-01',d2:'2026-09-30',per:'YTD',mes:'2026-09',lvl:'Macroactivo',tab:opts.tab||0});
  let st=def(),done=true;
  const draw=()=>{
   pg.innerHTML=queryBar(selF('port','Portafolio',FUNDS,st.port,{req:true})+rangeFields(st.d1,st.d2,'el período de análisis')+(opts.level?radiosF('lvl','Nivel de análisis',Object.keys(LEVELS),st.lvl):''))+'<div id="res"></div>';
   $('[name=port]',pg).addEventListener('change',e=>{st.port=e.target.value;clearErr(e.target)});$$('[name=d1],[name=d2]',pg).forEach(i=>i.addEventListener('change',()=>{st[i.name]=i.value;clearErr(i)}));
   
   $$('[name=lvl]',pg).forEach(r=>r.addEventListener('change',()=>st.lvl=r.value));
   $('[data-clear]',pg).addEventListener('click',()=>{st=def();st.port='';done=false;draw()});
   $('[data-consult]',pg).addEventListener('click',()=>{if(!st.port){errOn(pg,'port','Selecciona un portafolio para consultar');toast('Selecciona un portafolio.','warning','Falta un dato');return}if(!st.d1||!st.d2){errOn(pg,st.d1?'d2':'d1','Indica la fecha');toast('Indica la fecha inicial y la final.','warning','Faltan datos');return}if(st.d1>st.d2){errOn(pg,'d1','La fecha inicial no puede ser posterior a la final');toast('La fecha inicial no puede ser posterior a la final.','warning','Rango inválido');return}done=true;const r=$('#res',pg);r.innerHTML='<div class="mk-loading"><div class="mk-spinner"></div></div>';setTimeout(out,300)});
   if(done)out();else $('#res',pg).innerHTML='<div class="mk-card"><div class="mk-emptybig"><div class="mk-emptybig__ico">'+ic('pa','xl')+'</div><div class="mk-emptybig__t">Aún no hay resultados</div><div class="mk-emptybig__d">Elige un portafolio y pulsa Consultar.</div></div></div>';
  };
  const out=()=>{st.per=perKey(st.d1,st.d2);st.mes=st.d2.slice(0,7);build($('#res',pg),st,()=>out())};
  draw();
 };
}
function tabsUI(root,tabs,st,render){root.innerHTML='<div class="mk-tabs" role="tablist">'+tabs.map((t,i)=>'<button class="mk-tab'+(i===st.tab?' active':'')+'" data-t="'+i+'" role="tab">'+t+'</button>').join('')+'</div><div class="mk-tabpanel" id="tp"></div>';const show=()=>render(st.tab,$('#tp',root));$$('[data-t]',root).forEach(b=>b.addEventListener('click',()=>{st.tab=+b.dataset.t;$$('[data-t]',root).forEach(x=>x.classList.toggle('active',x===b));show()}));show()}
const endOf=mes=>{const[y,m]=mes.split('-');return new Date(+y,+m,0)};

PAGES.pasummary=paPage('Resumen de desempeño','Rentabilidad, riesgo y comparación contra el benchmark del portafolio.',(r,st)=>{
 const s=perfStats(st.port,st.per,endOf(st.mes)),bn=(BENCH_DEF.filter(b=>b.port===st.port)[0]||{bench:'Benchmark compuesto'}).bench;
 r.innerHTML='<div class="mk-kpis">'+kpiBox('Rentabilidad portafolio','<span class="'+sgnCls(s.rp)+'">'+pcs(s.rp)+'</span>','p')+kpiBox('Rentabilidad benchmark','<span class="'+sgnCls(s.rb)+'">'+pcs(s.rb)+'</span>','b')+kpiBox('Exceso (alpha)','<span class="'+sgnCls(s.ex)+'">'+bps(s.ex)+'</span>','g','Diferencia entre la rentabilidad del portafolio y la de su benchmark')+kpiBox('Tracking error',pct(s.te,2),'','Qué tanto se aleja el portafolio de su benchmark')+kpiBox('Information ratio',f2(s.ir),'y','Exceso de retorno por cada unidad de riesgo activo')+kpiBox('Volatilidad',pct(s.vol,2),'','Variabilidad de los retornos del portafolio')+kpiBox('Sharpe',f2(s.sharpe),'','Retorno sobre la tasa libre de riesgo por unidad de volatilidad')+kpiBox('Máx. drawdown','<span class="neg">'+pct(s.dd,2)+'</span>','r','Mayor caída acumulada desde un máximo')+'</div>'+'<div class="mk-mt" id="tabs"></div>';
 tabsUI($('#tabs',r),['Evolución','Horizontes'],st,(i,p)=>{if(i===0)p.innerHTML='<div class="mk-card">'+lineSVG(s.series,[{k:'p',n:st.port,c:'#6A1B9A'},{k:'b',n:bn,c:'#64748B'}])+'</div>';else{p.innerHTML='<div id="h"></div>';DataTable($('#h',p),{cols:[{h:'Horizonte',k:'h'},{h:'Portafolio',k:'rp',html:x=>valC(x.rp,pcs(x.rp)),txt:x=>pct(x.rp,2)},{h:'Benchmark',k:'rb',html:x=>valC(x.rb,pcs(x.rb)),txt:x=>pct(x.rb,2)},{h:'Exceso (pb)',k:'ex',html:x=>valC(x.ex,bps(x.ex)),txt:x=>bps(x.ex)}],rows:()=>horizons(st.port),noPage:true,noFilters:true,fileName:'rentabilidad-horizontes'})}});
},{month:true});

PAGES.pabrinson=paPage('Atribución de retorno (Brinson-Fachler)','Explica el exceso de retorno con asignación, selección e interacción.',(r,st)=>{
 const b=brinson(st.port,st.per,st.lvl),sum=k=>b.rows.reduce((a,x)=>a+x[k],0);
 r.innerHTML='<div class="mk-kpis">'+kpiBox('Retorno portafolio',pcs(b.RP),'p')+kpiBox('Retorno benchmark',pcs(b.RB),'b')+kpiBox('Exceso de retorno',valC(b.exc,bps(b.exc)),'g')+kpiBox('Asignación',valC(sum('alloc'),bps(sum('alloc'))),'','Efecto de pesar cada categoría distinto al benchmark')+kpiBox('Selección',valC(sum('sel'),bps(sum('sel'))),'','Efecto de elegir activos que rinden más o menos que el benchmark de la categoría')+kpiBox('Interacción',valC(sum('inter'),bps(sum('inter'))),'','Efecto conjunto de asignación y selección')+'</div><div id="tabs"></div>';
 tabsUI($('#tabs',r),['Efectos','Detalle'],st,(i,p)=>{if(i===0)p.innerHTML='<div class="mk-card"><h3 style="margin:0 0 8px;font-size:14px">Efectos por '+st.lvl.toLowerCase()+'</h3>'+hbarSVG(b.rows,['alloc','sel','inter'],['#6A1B9A','#15803D','#D97706'],['Asignación','Selección','Interacción'])+'</div>';else{const ef=v=>valC(v,bps(v)),col=(h,k,f,tip)=>({h,k,html:x=>f(x[k]),txt:x=>f(x[k]).replace(/<[^>]+>/g,''),tip});p.innerHTML='<div id="d"></div><p class="mk-help mk-mt">Asignación = (Wp − Wb)·(Rb,i − Rb) · Selección = Wb·(Rp,i − Rb,i) · Interacción = (Wp − Wb)·(Rp,i − Rb,i).</p>';DataTable($('#d',p),{cols:[{h:'Categoría',k:'cat'},col('Peso portafolio','wp',v=>pct(v,2)),col('Peso benchmark','wb',v=>pct(v,2)),col('Retorno portafolio','rp',v=>pct(v,2)),col('Retorno benchmark','rb',v=>pct(v,2)),col('Asignación','alloc',ef,'Efecto de sobre/subponderar la categoría'),col('Selección','sel',ef,'Efecto de elegir mejores o peores activos'),col('Interacción','inter',ef),col('Efecto total','tot',ef)],rows:()=>b.rows,noPage:true,noFilters:true,fileName:'atribucion-brinson',totals:rows=>['Total',pct(rows.reduce((a,x)=>a+x.wp,0),2),pct(rows.reduce((a,x)=>a+x.wb,0),2),pct(b.RP,2),pct(b.RB,2),ef(sum('alloc')),ef(sum('sel')),ef(sum('inter')),ef(sum('tot'))]})}});
},{level:true,port:FUNDS[5]});

PAGES.pacontrib=paPage('Contribución por activo','Qué posiciones suman o restan al retorno del portafolio.',(r,st)=>{
 const c=contributions(st.port,st.per),so=c.rows.slice().sort((a,b)=>b.c-a.c),top=so.slice(0,5),bot=so.slice(-5).reverse();
 const bars=(arr,pos)=>hbarSVG(arr.map(x=>({cat:x.instr.length>26?x.instr.slice(0,25)+'…':x.instr,c:x.c})),['c'],[pos?'#15803D':'#DC2626'],[pos?'Contribución positiva':'Contribución negativa']);
 r.innerHTML='<div class="mk-kpis">'+kpiBox('Retorno total',pcs(c.T),'p')+kpiBox('Posiciones',c.rows.length,'b')+kpiBox('Mayor contribuyente','<span class="pos">'+bps(top[0].c)+'</span>','g','Contribución = peso promedio × retorno de la posición')+kpiBox('Mayor detractor',valC(bot[0].c,bps(bot[0].c)),'r')+'</div><div class="mk-cols2 mk-mb"><div class="mk-card"><h3 style="margin:0 0 6px;font-size:14px">Top 5 contribuyentes</h3>'+bars(top,true)+'</div><div class="mk-card"><h3 style="margin:0 0 6px;font-size:14px">Top 5 detractores</h3>'+bars(bot,false)+'</div></div><div id="t"></div>';
 const det=x=>{const m=openModal({title:'Detalle de la posición',body:'<div class="mk-formgrid">'+fdRow('Posición',esc(x.instr))+fdRow('Emisor',esc(x.emisor))+fdRow('Macroactivo',x.macro)+fdRow('Peso promedio',pct(x.w,2))+fdRow('Retorno',pcs(x.ret))+fdRow('Contribución',bps(x.c))+fdRow('% del retorno total',pct(x.share,1))+'</div>',foot:'<button class="mk-btn mk-btn--secondary" data-c>Cerrar</button>'});$('[data-c]',m.el).addEventListener('click',m.close)};
 DataTable($('#t',r),{cols:[{h:'Posición',k:'instr',sortable:true},{h:'Emisor',k:'emisor'},{h:'Macroactivo',k:'macro',html:x=>badge(x.macro,x.macro==='RENTA FIJA'?'success':'warning'),txt:x=>x.macro},{h:'Peso promedio',k:'w',fmt:v=>pct(v,2),sortable:true},{h:'Retorno',k:'ret',html:x=>valC(x.ret,pcs(x.ret)),txt:x=>pct(x.ret,2),sortable:true},{h:'Contribución',k:'c',html:x=>valC(x.c,bps(x.c)),txt:x=>bps(x.c),sortable:true,tip:'Peso × retorno, en puntos básicos'},{h:'% del retorno total',k:'share',fmt:v=>pct(v,1),sortable:true}],rows:()=>c.rows,acts:()=>[['ver']],onAct:(a,x)=>det(x),searchPh:'Posición o emisor...',pageSize:10,fileName:'contribucion-activos',defaultSort:'Contribución',defaultDir:-1,noun:'posiciones'});
},{port:FUNDS[0]});

PAGES.pafixed=paPage('Atribución de renta fija','Descompone el exceso de retorno de la cartera de renta fija.',(r,st)=>{
 const a=fiAttr(st.port,st.per),ef=v=>valC(v,bps(v));
 r.innerHTML='<div class="mk-kpis">'+kpiBox('Retorno renta fija',pcs(a.rp),'p')+kpiBox('Retorno benchmark',pcs(a.rb),'b')+kpiBox('Exceso de retorno',ef(a.exc),'g')+kpiBox('Duración (años)',f2(a.dur[0])+' vs '+f2(a.dur[1]),'','Portafolio frente a su benchmark')+'</div><div class="mk-cols2" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr)"><div class="mk-card"><h3 style="margin:0 0 6px;font-size:14px">Descomposición del exceso de retorno</h3>'+waterfallSVG(a.comps,a.exc,'Exceso total')+'</div><div><div class="mk-card mk-mb"><h3 style="margin:0 0 8px;font-size:14px">Efectos por factor</h3><div id="f"></div></div><div class="mk-card"><h3 style="margin:0 0 8px;font-size:14px">Posicionamiento vs. benchmark</h3><div id="p"></div></div></div></div>';
 DataTable($('#f',r),{cols:[{h:'Factor',k:'n'},{h:'Efecto',k:'v',html:x=>ef(x.v),txt:x=>bps(x.v)}],rows:()=>a.comps,noPage:true,noFilters:true,noTools:true,noFoot:true,totals:()=>['Exceso total',ef(a.exc)]});
 DataTable($('#p',r),{cols:[{h:'Métrica',k:'m'},{h:'Portafolio',k:'p'},{h:'Benchmark',k:'b'},{h:'Diferencia',k:'d'}],rows:()=>[{m:'Duración modificada (años)',p:f2(a.dur[0]),b:f2(a.dur[1]),d:(a.dur[0]-a.dur[1]>=0?'+':'')+f2(a.dur[0]-a.dur[1])},{m:'Spread promedio (pb)',p:f1(a.spr[0]),b:f1(a.spr[1]),d:(a.spr[0]-a.spr[1]>=0?'+':'')+f1(a.spr[0]-a.spr[1])},{m:'Yield to maturity',p:pct(a.ytm[0],2),b:pct(a.ytm[1],2),d:(a.ytm[0]-a.ytm[1]>=0?'+':'')+pct(a.ytm[0]-a.ytm[1],2)}],noPage:true,noFilters:true,noTools:true,noFoot:true});
});

/* --- Atribución de mercado monetario (devengo, plazo, contraparte, liquidez) --- */
function mmAttr(port,per){
 const r=rng(hash(port+'mm'+per)),k=PERIODS[per].k;
 const comps=[['Devengo (carry)',0.0019+r()*0.0006],['Efecto plazo (WAM)',(r()-0.4)*0.0008],['Efecto spread de contraparte',(r()-0.3)*0.0009],['Efecto liquidez (overnight)',-(r()*0.0004)],['Costos y comisiones',-(0.0003+r()*0.0002)],['Residual',(r()-0.5)*0.0001]].map(c=>({n:c[0],v:c[1]*k}));
 const exc=comps.reduce((a,c)=>a+c.v,0),pos=MM_POS.filter(p=>p.port===port),tot=pos.reduce((a,p)=>a+p.nominal,0);
 const wam=tot?pos.reduce((a,p)=>a+p.nominal*p.rest,0)/tot:28+r()*30,liq=tot?pos.filter(p=>p.rest<=1).reduce((a,p)=>a+p.nominal,0)/tot:0.06+r()*0.05;
 const byCp={};pos.forEach(p=>{byCp[p.cp]=(byCp[p.cp]||0)+p.nominal});const conc=tot?Math.max.apply(null,Object.keys(byCp).map(x=>byCp[x]))/tot:0.2+r()*0.1;
 return {comps,exc,rb:0.0058*k,rp:0.0058*k+exc,wam:[wam,32+r()*10],tasa:[0.1045+r()*0.004,0.1030+r()*0.003],liq:[liq,0.1],conc:[conc,0.25]};
}
PAGES.pamm=paPage('Atribución mercado monetario','Explica el exceso de retorno de las operaciones monetarias: devengo, plazo, contraparte y liquidez.',(r,st)=>{
 const a=mmAttr(st.port,st.per),ef=v=>valC(v,bps(v)),d=(x,y,f)=>(x-y>=0?'+':'')+f(x-y);
 r.innerHTML='<div class="mk-kpis">'+kpiBox('Retorno monetario',pcs(a.rp),'p')+kpiBox('Retorno benchmark',pcs(a.rb),'b')+kpiBox('Exceso de retorno',ef(a.exc),'g')+kpiBox('Plazo promedio (días)',f1(a.wam[0])+' vs '+f1(a.wam[1]),'','Portafolio frente a su benchmark')+'</div><div class="mk-cols2" style="grid-template-columns:minmax(0,1.5fr) minmax(0,1fr)"><div class="mk-card"><h3 style="margin:0 0 6px;font-size:14px">Descomposición del exceso de retorno</h3>'+waterfallSVG(a.comps,a.exc,'Exceso total')+'</div><div><div class="mk-card mk-mb"><h3 style="margin:0 0 8px;font-size:14px">Efectos por factor</h3><div id="f"></div></div><div class="mk-card"><h3 style="margin:0 0 8px;font-size:14px">Posicionamiento vs. benchmark</h3><div id="p"></div></div></div></div>';
 DataTable($('#f',r),{cols:[{h:'Factor',k:'n'},{h:'Efecto',k:'v',html:x=>ef(x.v),txt:x=>bps(x.v)}],rows:()=>a.comps,noPage:true,noFilters:true,noTools:true,noFoot:true,totals:()=>['Exceso total',ef(a.exc)]});
 DataTable($('#p',r),{cols:[{h:'Métrica',k:'m'},{h:'Portafolio',k:'p'},{h:'Benchmark',k:'b'},{h:'Diferencia',k:'d'}],rows:()=>[{m:'Plazo promedio ponderado (días)',p:f1(a.wam[0]),b:f1(a.wam[1]),d:d(a.wam[0],a.wam[1],f1)},{m:'Tasa promedio E.A.',p:pct(a.tasa[0],2),b:pct(a.tasa[1],2),d:d(a.tasa[0],a.tasa[1],v=>pct(v,2))},{m:'Liquidez a 1 día',p:pct(a.liq[0],1),b:pct(a.liq[1],1),d:d(a.liq[0],a.liq[1],v=>pct(v,1))},{m:'Mayor concentración por contraparte',p:pct(a.conc[0],1),b:pct(a.conc[1],1),d:d(a.conc[0],a.conc[1],v=>pct(v,1))}],noPage:true,noFilters:true,noTools:true,noFoot:true});
},{port:FUNDS[0]});

/* --- Datos de los reportes de desempeño descargables --- */
function reportData(name,st){
 const funds=st.port==='Todos'?FUNDS:[st.port],per=perKey(st.d1,st.d2),end=new Date(st.d2+'T12:00:00'),P=v=>({n:v,s:4}),N=v=>({n:v,s:2}),pb=v=>N(v*10000);
 let heads,rows=[];
 if(/Brinson/.test(name)){heads=['Portafolio','Categoría','Peso portafolio','Peso benchmark','Asignación (pb)','Selección (pb)','Interacción (pb)','Total (pb)'];funds.forEach(p=>brinson(p,per,'Macroactivo').rows.forEach(x=>rows.push([p,x.cat,P(x.wp),P(x.wb),pb(x.alloc),pb(x.sel),pb(x.inter),pb(x.tot)])))}
 else if(/comité/.test(name)){heads=['Portafolio','Rentabilidad','Benchmark','Exceso (pb)','Volatilidad','Tracking error','Information ratio','Sharpe','Máx. drawdown'];funds.forEach(p=>{const s=perfStats(p,per,end);rows.push([p,P(s.rp),P(s.rb),pb(s.ex),P(s.vol),P(s.te),N(s.ir),N(s.sharpe),P(s.dd)])})}
 else if(/participaci/.test(name)){heads=['Portafolio','Tipo de participación','Comisión E.A.','Rentabilidad neta del período','Valor de la unidad'];const T=[['Tipo A (institucional)',0.012],['Tipo B (persona natural)',0.0185],['Tipo C (corporativo)',0.015]];funds.forEach(p=>{const s=perfStats(p,per,end);T.forEach(t=>{const net=s.rp-t[1]*PERIODS[per].k;rows.push([p,t[0],P(t[1]),P(net),N(10000*(1+net))])})})}
 else if(/renta fija/.test(name)){const a0=fiAttr(funds[0],per);heads=['Portafolio'].concat(a0.comps.map(c=>c.n+' (pb)'),['Exceso total (pb)']);funds.forEach(p=>{const a=fiAttr(p,per);rows.push([p].concat(a.comps.map(c=>pb(c.v)),[pb(a.exc)]))})}
 else if(/clientes/.test(name)){heads=['Mandato','Valor del portafolio','Rentabilidad','Benchmark','Exceso (pb)'];(st.port==='Todos'?FUNDS.filter(x=>/DELEGADO/.test(x)):[st.port]).forEach(p=>{const s=perfStats(p,per,end),sv0=SENS.find(x=>x.port===p);rows.push([p,N(sv0?sv0.val:1e10+hash(p)%1e9),P(s.rp),P(s.rb),pb(s.ex)])})}
 else{heads=['Portafolio','Rentabilidad','Benchmark','Exceso (pb)'];funds.forEach(p=>{const s=perfStats(p,per,end);rows.push([p,P(s.rp),P(s.rb),pb(s.ex)])})}
 return {heads,rows};
}

/* --- Benchmarks (Crear / Ver / Editar / Inactivar) --- */
BENCH_DEF.forEach((b,i)=>{if(b.activo===undefined)b.activo=(i!==6)});
PAGES.pabench=crudPage({title:'Benchmarks',help:'Composición del benchmark de cada portafolio.',apoya:APO.bench,entity:'componente de benchmark',entityArt:'El componente',fileName:'benchmarks',defaultSort:'Portafolio',searchPh:'Portafolio, benchmark o índice...',noun:'componentes',
 filters:[{id:'p',label:'Portafolio',opts:()=>FUNDS,get:r=>r.port},{id:'e',label:'Estado',opts:()=>['Vigente','Inactivo'],get:r=>r.activo?'Vigente':'Inactivo'}],
 kpis:rows=>[['Componentes',rows.length,'p'],['Vigentes',rows.filter(r=>r.activo).length,'g'],['Portafolios con benchmark',new Set(rows.map(r=>r.port)).size,'b']],
 cols:[{h:'Portafolio',k:'port',sortable:true},{h:'Benchmark',k:'bench'},{h:'Componente (índice)',k:'comp'},{h:'Peso',k:'peso',fmt:v=>pct(v,0)},{h:'Vigente desde',k:'desde',fmt:fmtD}],
 rows:()=>BENCH_DEF,estado:r=>badge(r.activo?'Vigente':'Inactivo',r.activo?'success':'neutral',true),acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar componente',danger:true,message:'Vas a inactivar <b>'+esc(r.comp)+'</b> del benchmark <b>'+esc(r.bench)+'</b>. Dejará de usarse en el cálculo del desempeño.',confirm:'Inactivar',done:'Componente inactivado.',apply:()=>{r.activo=false}}:{title:'Activar componente',message:'¿Deseas activar <b>'+esc(r.comp)+'</b> en el benchmark <b>'+esc(r.bench)+'</b>?',confirm:'Activar',done:'Componente activado.',apply:()=>{r.activo=true}},
 detail:r=>[['Portafolio',esc(r.port)],['Benchmark',esc(r.bench)],['Componente',esc(r.comp)],['Peso',pct(r.peso,0)],['Vigente desde',fmtD(r.desde)]],detailTitle:r=>r.bench,badges:r=>badge(r.activo?'Vigente':'Inactivo',r.activo?'success':'neutral'),
 extra:(pg,rp)=>{const x=document.createElement('div');x.className='mk-accordion collapsed mk-mt';x.innerHTML='<div class="mk-accordion__head"><span class="mk-accordion__ico">'+ic('upload')+'</span><span><span class="mk-accordion__t">Importar composición de benchmarks</span><span class="mk-accordion__d">Descarga la estructura y el manual, y carga el archivo</span></span><span class="mk-accordion__chev">&#9662;</span></div><div class="mk-accordion__body">'+massHTML(MASS.bench)+'</div>';pg.appendChild(x);bindAcc(x);bindMass(x,MASS.bench,rp)},
 form:row=>({html:'<div class="mk-formgrid">'+selF('port','Portafolio',FUNDS,row&&row.port,{req:true})+inpF('bench','Nombre del benchmark',row&&row.bench,{req:true})+selF('comp','Componente (índice)',BENCH_COMPS,row&&row.comp,{req:true})+inpF('peso','Peso (%)',row?row.peso*100:'',{req:true,ph:'Ej: 40',tip:'Los pesos de un mismo benchmark deben sumar 100%.'})+dateF('desde','Vigente desde',row&&row.desde,{req:true})+'</div>',
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[],pw=okNum(g('peso'));if(!g('port'))errs.push(['port','Selecciona un portafolio','Portafolio']);if(!g('bench'))errs.push(['bench','Indica el nombre','Benchmark']);if(!g('comp'))errs.push(['comp','Selecciona el índice','Componente']);if(!pw||pw>100)errs.push(['peso','Ingresa un peso entre 0 y 100','Peso']);const d=fromIso(g('desde'));if(!d)errs.push(['desde','Indica la fecha de vigencia','Vigencia']);if(errs.length)return {ok:false,errs};return {ok:true,data:{port:g('port'),bench:g('bench'),comp:g('comp'),peso:pw/100,desde:d,activo:row?row.activo:true}}}}),
 review:d=>[['Portafolio',d.port],['Benchmark',d.bench],['Componente',d.comp],['Peso',pct(d.peso,0)],['Vigente desde',fmtD(d.desde)]],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else BENCH_DEF.unshift(o)}
});

/* --- Reportes --- */
PAGES.pareports=crudPage({title:'Reportes de desempeño',help:'Genera y descarga los informes de desempeño.',noNew:true,dateRange:{k:'ult',label:'fecha de generación'},fileName:'reportes-performance',searchPh:'Nombre del reporte...',noun:'reportes',defaultSort:'Reporte',
 filters:[{id:'per',label:'Periodicidad',opts:()=>['Mensual','Trimestral'],get:r=>r.per}],
 cols:[{h:'Reporte',k:'n',sortable:true},{h:'Periodicidad',k:'per'},{h:'Último generado',k:'ult',fmt:dstr}],
 rows:()=>REPORTS,acts:()=>[['ver'],['gen','Generar reporte']],estado:r=>badge(r.est,r.est==='Generado'?'success':r.est==='Pendiente'?'warning':'info',true),
 kpis:rows=>[['Reportes',rows.length,'p'],['Generados',rows.filter(r=>r.est==='Generado').length,'g'],['Pendientes',rows.filter(r=>r.est==='Pendiente').length,'y'],['En revisión',rows.filter(r=>r.est==='En revisión').length,'b']],
 detail:r=>[['Reporte',esc(r.n)],['Periodicidad',r.per],['Último generado',dstr(r.ult)],['Estado',r.est]],detailTitle:r=>r.n,
 onAct:(a,r)=>{if(a==='gen')wizard(r.n)},
 form:()=>({html:'',read:()=>({ok:false})}),review:()=>[],onSave:()=>{},entity:'',entityArt:'',toggle:()=>({})
});
function wizard(name){
 const st={step:0,port:'Todos',d1:'2026-01-01',d2:'2026-09-30',fmt:'Excel',p:0},steps=[['Parámetros','Portafolio y periodo'],['Revisión','Confirma los datos'],['Generación','Preparando el archivo']];
 const m=openModal({title:'Generar reporte',cls:'mk-modal--wizard',sticky:true,sub:esc(name),body:'',foot:''});
 const wiz=()=>'<div class="mk-wizsteps">'+steps.map((s,i)=>(i?'<div class="mk-wizline'+(i<=st.step?' done':'')+'"></div>':'')+'<div class="mk-wizstep'+(i===st.step?' on':i<st.step?' done':'')+'"><div class="mk-wizstep__n">'+(i<st.step?'✓':i+1)+'</div><div class="mk-wizstep__t">'+s[0]+'</div><div class="mk-wizstep__d">'+s[1]+'</div></div>').join('')+'</div>';
 const render=()=>{let b='',ft='';
  if(st.step===0){b=wiz()+'<div class="mk-wizpanel"><div class="mk-formgrid">'+selF('w-port','Portafolio',['Todos'].concat(FUNDS),st.port,{req:true})+rangeFields(st.d1,st.d2,'el período del reporte','w-')+radiosF('w-fmt','Formato',['Excel','CSV'],st.fmt)+'</div></div>';ft='<div class="mk-wizfoot" style="width:100%;padding:0"><button class="mk-btn mk-btn--secondary" data-c>Cancelar</button><button class="mk-btn" data-n>Siguiente</button></div>'}
  else if(st.step===1){b=wiz()+'<div class="mk-wizpanel"><div class="mk-formgrid">'+fdRow('Reporte',esc(name))+fdRow('Portafolio',esc(st.port))+fdRow('Periodo',fmtD(fromIso(st.d1))+' – '+fmtD(fromIso(st.d2)))+fdRow('Formato',st.fmt)+'</div></div><div class="mk-mt">'+alertB('info','','Revisa los parámetros. El archivo se descargará en tu equipo.')+'</div>';ft='<div class="mk-wizfoot" style="width:100%;padding:0"><button class="mk-btn mk-btn--secondary" data-b>Atrás</button><button class="mk-btn" data-n>Generar</button></div>'}
  else{b=wiz()+'<div class="mk-wizpanel"><div class="mk-progress"><div class="mk-progress__bar" style="width:'+st.p+'%"></div></div><p class="mk-help mk-mt">'+(st.p<100?'Generando el reporte… '+st.p+'%':'Reporte listo para descargar.')+'</p></div>';ft=st.p<100?'<button class="mk-btn" disabled>Generando…</button>':'<button class="mk-btn mk-btn--secondary" data-c>Cerrar</button><button class="mk-btn" data-d>'+ic('download')+'Descargar</button>'}
  m.body.innerHTML=b;m.foot.innerHTML=ft;
  $$('[name="w-port"]',m.el).forEach(s=>s.addEventListener('change',()=>st.port=s.value));$$('[name="w-d1"],[name="w-d2"]',m.el).forEach(s=>s.addEventListener('change',()=>{st[s.name==='w-d1'?'d1':'d2']=s.value}));$$('[name="w-fmt"]',m.el).forEach(s=>s.addEventListener('change',()=>st.fmt=s.value));
 };
 m.el.addEventListener('click',e=>{
  if(e.target.closest('[data-c]')){m.close();return}
  if(e.target.closest('[data-b]')){st.step--;render();return}
  if(e.target.closest('[data-n]')){if(st.step===0&&!st.port){toast('Selecciona un portafolio.','warning');return}if(st.step===0&&(!st.d1||!st.d2||st.d1>st.d2)){toast('Revisa el rango: la fecha inicial debe ser igual o anterior a la final.','warning','Rango de fechas');return}st.step++;if(st.step===2){st.p=0;render();const t=setInterval(()=>{st.p=Math.min(100,st.p+20);if(!m.el.isConnected){clearInterval(t);return}render();if(st.p>=100)clearInterval(t)},350)}else render();return}
  if(e.target.closest('[data-d]')){const ds=reportData(name,st),base=name.replace(/[^\w]+/g,'-').toLowerCase()+'-'+new Date().toISOString().slice(0,10);exportTable(base,st.fmt==='Excel'?'xlsx':'csv',ds.heads,ds.rows,'Reporte');toast(esc(name),'success','Reporte descargado');m.close()}
 });
 render();
}


/* =============== PARAMETRIZACIÓN =============== */
const PORTS=PORTFOLIOS.map((p,i)=>({name:p.name,tipo:(i>=9?'Cliente':(i>=2&&i<=4)?'Mandato delegado':'FIC'),moneda:'COP',inicio:mkDate(2019+(i%5),(i*3)%12,1+(i*2)%25).getTime(),activo:i!==12}));
const isFund=r=>r.tipo==='FIC'||r.tipo==='Fondo mutuo'||r.tipo==='Fondo abierto';
function benchOf(n){const b=BENCH_DEF.find(x=>x.port===n);return b?b.bench:'—'}
PAGES.pport=crudPage({title:'Portafolios',help:'Fondos, mandatos y clientes sobre los que se opera.',apoya:APO.port,entity:'portafolio',entityArt:'El portafolio',fileName:'portafolios',defaultSort:'Portafolio',searchPh:'Nombre del portafolio...',noun:'portafolios',
 filters:[{id:'t',label:'Tipo',opts:()=>LOCL(['FIC','Mandato delegado','Cliente']),get:r=>r.tipo},{id:'e',label:'Estado',opts:()=>['Activo','Inactivo'],get:r=>r.activo?'Activo':'Inactivo'}],
 kpis:rows=>[['Portafolios',rows.length,'p'],[loc('FIC'),rows.filter(isFund).length,'b'],['Mandatos delegados',rows.filter(r=>r.tipo==='Mandato delegado').length,'y'],['Clientes',rows.filter(r=>r.tipo==='Cliente').length,'g']],
 cols:[{h:'Portafolio',k:'name',sortable:true},{h:'Tipo',k:'tipo',html:r=>badge(r.tipo,isFund(r)?'info':r.tipo==='Cliente'?'success':'warning'),txt:r=>r.tipo},{h:'Moneda base',k:'moneda'},{h:'Fecha de inicio',k:'inicio',fmt:fmtD},{h:'Benchmark',html:r=>esc(benchOf(r.name)),txt:r=>benchOf(r.name)}],
 rows:()=>PORTS,estado:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral',true),acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar portafolio',danger:true,message:'Vas a inactivar <b>'+esc(r.name)+'</b>. No podrá seleccionarse en nuevas órdenes; las posiciones y órdenes vigentes no se modifican.',confirm:'Inactivar',done:'Portafolio inactivado.',apply:()=>{r.activo=false}}:{title:'Activar portafolio',message:'¿Deseas activar <b>'+esc(r.name)+'</b> para operar?',confirm:'Activar',done:'Portafolio activado.',apply:()=>{r.activo=true}},
 detail:r=>[['Portafolio',esc(r.name)],['Tipo',r.tipo],['Moneda base',r.moneda],['Fecha de inicio',fmtD(r.inicio)],['Benchmark',esc(benchOf(r.name))]],detailTitle:r=>r.name,badges:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral'),
 form:row=>({html:'<div class="mk-formgrid">'+inpF('name','Nombre del portafolio',row&&row.name,{req:true})+selF('tipo','Tipo',LOCL(['FIC','Mandato delegado','Cliente']),row&&row.tipo,{req:true})+selF('moneda','Moneda base',['COP','USD'],row?row.moneda:'COP',{req:true})+dateF('inicio','Fecha de inicio',row&&row.inicio,{req:true})+'</div>',
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[];if(!g('name'))errs.push(['name','Indica el nombre','Nombre']);if(!g('tipo'))errs.push(['tipo','Selecciona el tipo','Tipo']);if(!g('moneda'))errs.push(['moneda','Selecciona la moneda','Moneda']);const d=fromIso(g('inicio'));if(!d)errs.push(['inicio','Indica la fecha de inicio','Fecha de inicio']);if(errs.length)return {ok:false,errs};return {ok:true,data:{name:g('name'),tipo:g('tipo'),moneda:g('moneda'),inicio:d,activo:row?row.activo:true}}}}),
 review:d=>[['Portafolio',d.name],['Tipo',d.tipo],['Moneda base',d.moneda],['Fecha de inicio',fmtD(d.inicio)]],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else{PORTS.unshift(o);if(!PNAMES.includes(o.name))PNAMES.push(o.name)}}
});
const INDICES=[['IBR 1M','Indicador Bancario de Referencia a 1 mes','Tasa','Banco de la República'],['IBR 3M','Indicador Bancario de Referencia a 3 meses','Tasa','Banco de la República'],['DTF 90D','Depósito a Término Fijo a 90 días','Tasa','Banco de la República'],['Índice TES Corto','Índice de TES de corto plazo','Renta fija','Bolsa de Valores de Colombia'],['Índice TES Largo','Índice de TES de largo plazo','Renta fija','Bolsa de Valores de Colombia'],['Índice Corporativos AAA','Bonos corporativos con calificación AAA','Renta fija','Bolsa de Valores de Colombia'],['COLCAP','Índice de capitalización bursátil','Renta variable','Bolsa de Valores de Colombia'],['MSCI ACWI','Acciones globales, mercados desarrollados y emergentes','Renta variable','MSCI'],['Bloomberg Global Aggregate','Renta fija global grado de inversión','Renta fija','Bloomberg'],['IPC + 3%','Inflación más 3 puntos porcentuales','Tasa','DANE']].map((a,i)=>({code:a[0],nombre:a[1],tipo:a[2],fuente:a[3],activo:i!==8}));
PAGES.pindex=crudPage({title:'Índices de referencia',help:'Índices que componen los benchmarks de los portafolios.',apoya:APO.index,entity:'índice',entityArt:'El índice',fileName:'indices',defaultSort:'Código',searchPh:'Código, nombre o fuente...',noun:'índices',
 filters:[{id:'t',label:'Tipo',opts:()=>['Tasa','Renta fija','Renta variable'],get:r=>r.tipo},{id:'e',label:'Estado',opts:()=>['Activo','Inactivo'],get:r=>r.activo?'Activo':'Inactivo'}],
 kpis:rows=>[['Índices',rows.length,'p'],['Activos',rows.filter(r=>r.activo).length,'g'],['De tasa',rows.filter(r=>r.tipo==='Tasa').length,'b'],['De mercado',rows.filter(r=>r.tipo!=='Tasa').length,'y']],
 cols:[{h:'Código',k:'code',sortable:true},{h:'Nombre',k:'nombre'},{h:'Tipo',k:'tipo'},{h:'Fuente',k:'fuente'}],
 rows:()=>INDICES,estado:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral',true),acts:r=>[['ver'],['edit'],r.activo?['off']:['on']],
 toggle:r=>r.activo?{title:'Inactivar índice',danger:true,message:'Vas a inactivar <b>'+esc(r.code)+'</b>. No podrá elegirse en nuevos benchmarks; los benchmarks que ya lo usan no cambian.',confirm:'Inactivar',done:'Índice inactivado.',apply:()=>{r.activo=false}}:{title:'Activar índice',message:'¿Deseas activar <b>'+esc(r.code)+'</b>?',confirm:'Activar',done:'Índice activado.',apply:()=>{r.activo=true}},
 detail:r=>[['Código',esc(r.code)],['Nombre',esc(r.nombre)],['Tipo',r.tipo],['Fuente',esc(r.fuente)]],detailTitle:r=>r.code,badges:r=>badge(r.activo?'Activo':'Inactivo',r.activo?'success':'neutral'),
 form:row=>({html:'<div class="mk-formgrid">'+inpF('code','Código',row&&row.code,{req:true})+selF('tipo','Tipo',['Tasa','Renta fija','Renta variable'],row&&row.tipo,{req:true})+inpF('nombre','Nombre',row&&row.nombre,{req:true,cls:'span2'})+inpF('fuente','Fuente',row&&row.fuente)+'</div>',
  read:f=>{const g=n=>$('[name="'+n+'"]',f).value.trim(),errs=[];if(!g('code'))errs.push(['code','Indica el código','Código']);if(!g('nombre'))errs.push(['nombre','Indica el nombre','Nombre']);if(!g('tipo'))errs.push(['tipo','Selecciona el tipo','Tipo']);if(errs.length)return {ok:false,errs};return {ok:true,data:{code:g('code'),nombre:g('nombre'),tipo:g('tipo'),fuente:g('fuente'),activo:row?row.activo:true}}}}),
 review:d=>[['Código',d.code],['Nombre',d.nombre],['Tipo',d.tipo],['Fuente',d.fuente||'—']],
 onSave:(o,row)=>{if(row)Object.assign(row,o);else{INDICES.unshift(o);if(!BENCH_COMPS.includes(o.code))BENCH_COMPS.push(o.code)}}
});
PAGES.pcat=function(view,meta){
 const pg=mountPage(view,meta,'Catálogos','Emisores, calificaciones, monedas y tipos de límite.');
 const st={tab:0};
 const CATS=[
  ['Emisores',[{h:'Emisor',k:'n'},{h:'Sector',k:'s'},{h:'Calificación',k:'c'},{h:'País',k:'p'}],[['ECOPETROL S.A.','Energía','AAA','Colombia'],['BANCOLOMBIA S.A.','Financiero','AAA','Colombia'],['BANCO DAVIVIENDA','Financiero','AAA','Colombia'],['BANCO DE BOGOTÁ','Financiero','AAA','Colombia'],['GRUPO SURA','Holding','AA+','Colombia'],['ISA S.A. E.S.P.','Energía','AAA','Colombia'],['FINDETER','Fomento','AAA','Colombia'],['TITULARIZADORA COLOMBIANA','Financiero','AAA','Colombia'],['COLPENSIONES','Seguridad social','AAA','Colombia'],['CEMENTOS ARGOS','Industrial','AA+','Colombia'],['MINISTERIO DE HACIENDA (TES)','Gobierno','AAA','Colombia']].map(a=>({n:a[0],s:a[1],c:a[2],p:a[3]}))],
  ['Calificaciones',[{h:'Calificación',k:'c'},{h:'Grado',k:'g'},{h:'Descripción',k:'d'}],[['AAA','Grado de inversión','Capacidad de pago excepcional'],['AA+','Grado de inversión','Capacidad de pago muy alta'],['AA','Grado de inversión','Capacidad de pago muy alta'],['AA-','Grado de inversión','Capacidad de pago muy alta'],['A','Grado de inversión','Capacidad de pago alta'],['A-','Grado de inversión','Capacidad de pago alta'],['BBB','Grado de inversión','Capacidad de pago adecuada']].map(a=>({c:a[0],g:a[1],d:a[2]}))],
  ['Monedas',[{h:'Código',k:'c'},{h:'Moneda',k:'n'},{h:'Uso',k:'u'}],[['COP','Peso colombiano','Moneda base'],['USD','Dólar estadounidense','Inversiones internacionales'],['EUR','Euro','Inversiones internacionales'],['UVR','Unidad de Valor Real','Títulos indexados a la inflación']].map(a=>({c:a[0],n:a[1],u:a[2]}))],
  ['Tipos de límite',[{h:'Tipo de límite',k:'t'},{h:'Valores posibles',k:'v'}],Object.keys(SUBLIMITS).map(k=>({t:k,v:SUBLIMITS[k].join(', ')})).concat(DENOMS.map(d=>({t:'Denominador',v:d})))],
  ['Operaciones monetarias',[{h:'Operación',k:'o'},{h:'Descripción',k:'d'},{h:'Plazo típico',k:'p'}],[['CDT','Certificado de depósito a término con un banco','30 a 360 días'],['SIMULTÁNEA','Compra con compromiso de reventa, respaldada en títulos','1 a 30 días'],['INTERBANCARIO','Préstamo de liquidez entre entidades financieras','1 a 7 días'],['OVERNIGHT','Colocación de excedentes a un día','1 día'],['TES CORTO','Título de deuda pública de corto plazo','Hasta 365 días']].map(a=>({o:a[0],d:a[1],p:a[2]}))]
 ];
 CATS[0][2].forEach(o=>{Object.keys(o).forEach(k=>{o[k]=loc(o[k])})});CATS[4][2].forEach(o=>{Object.keys(o).forEach(k=>{o[k]=loc(o[k])})});CATS[2][2]=CURR[S.pais].map(a=>({c:a[0],n:a[1],u:a[2]}));
 pg.innerHTML='<div class="mk-tabs mk-mt" role="tablist">'+CATS.map((c,i)=>'<button class="mk-tab'+(i===0?' active':'')+'" data-t="'+i+'" role="tab">'+c[0]+'</button>').join('')+'</div><div class="mk-tabpanel" id="cp"></div>';
 const show=()=>{const c=CATS[st.tab];$('#cp',pg).innerHTML=apoyaHTML(APO.cat[st.tab])+'<div id="ct"></div>';DataTable($('#ct',pg),{cols:c[1],rows:()=>c[2],noPage:true,fileName:'catalogo-'+c[0].toLowerCase().replace(/\s+/g,'-'),searchPh:'Buscar...',noun:'registros'})};
 $$('[data-t]',pg).forEach(b=>b.addEventListener('click',()=>{st.tab=+b.dataset.t;$$('[data-t]',pg).forEach(x=>x.classList.toggle('active',x===b));show()}));
 show();
};
PAGES.pflow=function(view,meta){
 const pg=mountPage(view,meta,'Flujo de órdenes','Estados de una orden y las acciones permitidas en cada uno.');
 pg.insertAdjacentHTML('beforebegin',apoyaHTML(APO.flow));
 const ST=[['R','Registrada','info','La orden se captura y queda pendiente de completar.'],['C','Complementación','warning','Se completa la información faltante (tasa, valor giro, contraparte).'],['F','Finalizada','success','La orden queda cerrada; solo se consulta.'],['A','Anulada','danger','La orden se cancela antes de finalizar; no se puede deshacer.']];
 const box=(s,w)=>'<div style="flex:1;min-width:'+(w||170)+'px;border:1px solid var(--mk-border);border-radius:10px;padding:14px;background:#fff;text-align:center"><div>'+badge(s[1],s[2],true)+'</div><div class="mk-help" style="margin-top:8px">'+s[3]+'</div></div>';
 const arrow=c=>'<div style="display:flex;align-items:center;color:var(--mk-primary);font-size:24px;font-weight:700">'+c+'</div>';
 pg.innerHTML='<div class="mk-subhead">'+ic('flows')+'Ciclo de vida de una orden</div><div style="display:flex;gap:10px;flex-wrap:wrap;align-items:stretch">'+box(ST[0])+arrow('→')+box(ST[1])+arrow('→')+box(ST[2])+'</div><div style="display:flex;gap:12px;margin-top:12px;align-items:center;flex-wrap:wrap"><span class="mk-help">Desde Registrada o Complementación también se puede anular:</span>'+arrow('→')+'<div style="width:260px">'+box(ST[3],200)+'</div></div><div class="mk-subhead mk-mt">'+ic('check')+'Acciones permitidas por estado</div><div id="ft"></div>';
 const Y='<span class="pos">Sí</span>',N='<span class="mk-na">No</span>';
 const rows=[['Registrada',Y,Y,Y,'Complementación, Anulada'],['Complementación',Y,Y,Y,'Finalizada, Anulada'],['Finalizada',Y,N,N,'—'],['Anulada',Y,N,N,'—']].map((a,i)=>({p:['1','2','3','Alterno'][i],e:a[0],v:a[1],ed:a[2],an:a[3],sig:a[4]}));
 const strip=h=>h.replace(/<[^>]+>/g,'');
 DataTable($('#ft',pg),{cols:[{h:'Paso',k:'p'},{h:'Ver detalle',k:'v',html:r=>r.v,txt:r=>strip(r.v)},{h:'Editar',k:'ed',html:r=>r.ed,txt:r=>strip(r.ed)},{h:'Anular',k:'an',html:r=>r.an,txt:r=>strip(r.an)},{h:'Siguiente estado',k:'sig'},{h:'Estado',k:'e',html:r=>badge(r.e,r.e==='Registrada'?'info':r.e==='Complementación'?'warning':r.e==='Finalizada'?'success':'danger',true),txt:r=>r.e}],rows:()=>rows,noPage:true,noFilters:true,noTools:true,noFoot:true});
};


/* =============== País: datos de ejemplo por país =============== */
const CURR={
 'Colombia':[['COP','Peso colombiano','Moneda base'],['USD','Dólar estadounidense','Inversiones internacionales'],['EUR','Euro','Inversiones internacionales'],['UVR','Unidad de Valor Real','Títulos indexados a la inflación']],
 'Chile':[['CLP','Peso chileno','Moneda base'],['USD','Dólar estadounidense','Inversiones internacionales'],['EUR','Euro','Inversiones internacionales'],['UF','Unidad de Fomento','Títulos indexados a la inflación']],
 'República Dominicana':[['DOP','Peso dominicano','Moneda base'],['USD','Dólar estadounidense','Inversiones internacionales'],['EUR','Euro','Inversiones internacionales']]
};
const TIPOS_P={'Colombia':['DESCUENTO','IBR','IPC','TASA FIJA','UVR','DTF'],'Chile':['DESCUENTO','TAB','IPC','TASA FIJA','UF','TPM'],'República Dominicana':['DESCUENTO','TASA REFERENCIA','IPC','TASA FIJA','TASA VARIABLE','TPM']};
const MON_P={'Colombia':['COP','UVR','USD','EUR'],'Chile':['CLP','UF','USD','EUR'],'República Dominicana':['DOP','USD','EUR']};
const TIPOS=()=>TIPOS_P[S.pais].slice(),MONEDAS=()=>MON_P[S.pais].slice();
const CTRY={
 'Chile':{
  m:[['BANCO POPULAR S.A.','BANCO SECURITY'],['BANCO AV VILLAS','BANCO FALABELLA'],['SCOTIABANK COLPATRIA','SCOTIABANK CHILE'],['CORFICOLOMBIANA','BICE INVERSIONES'],['BANCO COOMEVA','BANCO ITAÚ CHILE'],['SIMULTÁNEAS','PACTOS DE RETROCOMPRA'],['SIMULTÁNEA','PACTO DE RETROCOMPRA'],['Simultánea','Pacto de retrocompra'],['TES CORTO','BONO GOBIERNO CORTO'],['IBR OVERNIGHT','TAB OVERNIGHT'],['TASA DE REPO BANREP','TASA DE PACTO BCCH'],['Indicador Bancario de Referencia a 1 día','Tasa Activa Bancaria a 1 día'],['Comisionista','Corredora de bolsa'],['MINISTERIO DE HACIENDA (TES)','TESORERÍA GENERAL DE LA REPÚBLICA'],['BANCO DE LA REPÚBLICA','BANCO CENTRAL DE CHILE'],['FIDUCIARIA BANCOLOMBIA','ADMINISTRADORA GENERAL DE FONDOS SURA'],['BANCOLOMBIA S.A.','BANCO SANTANDER CHILE'],['BANCO DAVIVIENDA','BANCO DE CHILE'],['BANCO DE BOGOTÁ','BANCO BCI'],['ECOPETROL S.A.','EMPRESAS COPEC S.A.'],['ISA S.A. E.S.P.','ENEL CHILE S.A.'],['GRUPO SURA','FALABELLA S.A.'],['TITULARIZADORA COLOMBIANA','BANCOESTADO'],['FINDETER','CORFO'],['COLPENSIONES','AFP HABITAT'],['CEMENTOS ARGOS','CMPC S.A.'],['Bolsa de Valores de Colombia','Bolsa de Comercio de Santiago'],['Banco de la República','Banco Central de Chile'],['DANE','INE'],['Índice de TES de corto plazo','Índice de bonos del Gobierno de corto plazo'],['Índice de TES de largo plazo','Índice de bonos del Gobierno de largo plazo'],['Índice TES Corto','Índice Bonos Gobierno Corto'],['Índice TES Largo','Índice Bonos Gobierno Largo'],['de TES','de bonos del Gobierno'],['Índice de capitalización bursátil','Índice de precios selectivo de acciones'],['COLCAP','IPSA'],['Indicador Bancario de Referencia a 1 mes','Tasa Activa Bancaria a 30 días'],['Indicador Bancario de Referencia a 3 meses','Tasa Activa Bancaria a 90 días'],['Depósito a Término Fijo a 90 días','Tasa de Política Monetaria'],['IBR 1M','TAB 30D'],['IBR 3M','TAB 90D'],['DTF 90D','TPM'],['Benchmark FIC','Benchmark Fondo Mutuo'],['FIC ','FONDO MUTUO '],['"FIC"','"Fondo mutuo"'],['"IBR"','"TAB"'],['"DTF"','"TPM"'],['"UVR"','"UF"'],['"COP"','"CLP"'],['TFIT','BTU'],['CDT','DPF'],['ECOPETROL','COPEC'],['CELSIA','ENELCHILE'],['CEMARGOS','CMPC'],['BOGOTA','BCHILE'],['BSANTANDER','SANTANDER'],['BVC','CENCOSUD'],['Colombia','Chile']],
  ex:{FIC:'Fondo mutuo',IBR:'TAB',UVR:'UF',DTF:'TPM',COP:'CLP','Cédula de Ciudadanía':'RUT persona natural',NIT:'RUT empresa','Cédula de Extranjería':'RUT extranjero'}
 },
 'República Dominicana':{
  m:[['BANCO POPULAR S.A.','BANCO LÓPEZ DE HARO'],['BANCO AV VILLAS','BANCO PROMERICA'],['SCOTIABANK COLPATRIA','SCOTIABANK DOMINICANA'],['CORFICOLOMBIANA','PUESTO DE BOLSA PARALLAX'],['BANCO COOMEVA','BANCO SANTA CRUZ'],['SIMULTÁNEAS','REPORTOS'],['SIMULTÁNEA','REPORTO'],['Simultánea','Reporto'],['TES CORTO','BONO SOBERANO CORTO'],['IBR OVERNIGHT','TASA PASIVA OVERNIGHT'],['TASA DE REPO BANREP','TASA DE REPORTO BCRD'],['Indicador Bancario de Referencia a 1 día','Tasa pasiva promedio a 1 día'],['Comisionista','Puesto de bolsa'],['MINISTERIO DE HACIENDA (TES)','MINISTERIO DE HACIENDA (BONOS SOBERANOS)'],['BANCO DE LA REPÚBLICA','BANCO CENTRAL DE LA REPÚBLICA DOMINICANA'],['FIDUCIARIA BANCOLOMBIA','ADMINISTRADORA DE FONDOS POPULAR'],['BANCOLOMBIA S.A.','BANCO POPULAR DOMINICANO'],['BANCO DAVIVIENDA','BANCO DE RESERVAS'],['BANCO DE BOGOTÁ','BANCO BHD'],['ECOPETROL S.A.','EGE HAINA'],['ISA S.A. E.S.P.','EDESUR DOMINICANA'],['GRUPO SURA','GRUPO POPULAR'],['TITULARIZADORA COLOMBIANA','ASOCIACIÓN CIBAO'],['FINDETER','BANCO ADEMI'],['COLPENSIONES','AFP SIEMBRA'],['CEMENTOS ARGOS','CEMENTOS COSMOS'],['Bolsa de Valores de Colombia','Bolsa de Valores de la República Dominicana'],['Banco de la República','Banco Central de la República Dominicana'],['DANE','Banco Central'],['Índice de TES de corto plazo','Índice de bonos soberanos de corto plazo'],['Índice de TES de largo plazo','Índice de bonos soberanos de largo plazo'],['Índice TES Corto','Índice Bonos Soberanos Corto'],['Índice TES Largo','Índice Bonos Soberanos Largo'],['de TES','de bonos soberanos'],['Índice de capitalización bursátil','Índice bursátil de la BVRD'],['COLCAP','Índice BVRD'],['Indicador Bancario de Referencia a 1 mes','Tasa pasiva promedio a 30 días'],['Indicador Bancario de Referencia a 3 meses','Tasa pasiva promedio a 90 días'],['Depósito a Término Fijo a 90 días','Tasa de política monetaria'],['IBR 1M','Tasa pasiva 30D'],['IBR 3M','Tasa pasiva 90D'],['DTF 90D','TPM'],['Benchmark FIC','Benchmark Fondo'],['FIC ','FONDO ABIERTO '],['"FIC"','"Fondo abierto"'],['"IBR"','"TASA REFERENCIA"'],['"DTF"','"TPM"'],['"UVR"','"USD"'],['"COP"','"DOP"'],['TFIT','BSRD'],['CDT','CDP'],['ECOPETROL','EGEHAINA'],['CELSIA','EDESUR'],['CEMARGOS','CEMCOSMOS'],['BOGOTA','BHD'],['BSANTANDER','POPULAR'],['BVC','BVRD'],['Colombia','República Dominicana']],
  ex:{FIC:'Fondo abierto',IBR:'TASA REFERENCIA',UVR:'USD',DTF:'TPM',COP:'DOP','Cédula de Ciudadanía':'Cédula de identidad',NIT:'RNC','Cédula de Extranjería':'Cédula de residencia'},
  fix:()=>{const ok=TIPOS_P['República Dominicana'];INSTRUMENTS.forEach(r=>{if(!ok.includes(r.tipo))r.tipo='TASA FIJA'});LEVELS.Moneda=['DOP','USD','EUR'];SUBLIMITS.MONEDA=['DOP','USD','EUR'];HOLDINGS_BASE.forEach(h=>{if(/LOCAL/.test(h[1])&&h[2]==='USD')h[2]='DOP'})}
 }
};
function mapStr(str,c){const cfg=CTRY[c];if(!cfg)return str;let r=str;cfg.m.forEach(p=>{r=r.split(p[0]).join(p[1])});return r}
function loc(x){const cfg=CTRY[S.pais];if(!cfg||typeof x!=='string')return x;if(cfg.ex[x]!==undefined)return cfg.ex[x];return mapStr(x,S.pais)}
const LOCL=a=>{const o=a.map(loc);return o.filter((v,i)=>o.indexOf(v)===i)};
const DS={FI_ORDERS,VI_ORDERS,INSTRUMENTS,LIMITS,BENCH_DEF,PORTS,INDICES,SENS,PNAMES,FUNDS,PORTFOLIOS,HOLDINGS_BASE,SUBLIMITS,DENOMS,LEVELS,BENCH_COMPS,INSTR_NAMES,ISSUERS,MM_ORDERS,MM_POS,MM_CP,MM_RATES};
const SNAP={};Object.keys(DS).forEach(k=>SNAP[k]=JSON.stringify(DS[k]));
function applyCountry(c){
 S.pais=c;
 Object.keys(DS).forEach(k=>{const v=JSON.parse(CTRY[c]?mapStr(SNAP[k],c):SNAP[k]),t=DS[k];if(Array.isArray(t)){t.length=0;v.forEach(x=>t.push(x))}else{Object.keys(t).forEach(x=>delete t[x]);Object.assign(t,v)}});
 const f=CTRY[c]&&CTRY[c].fix;if(f)f();
 const sel=$('#pais');if(sel)sel.value=c;
 toast('Se actualizaron emisores, monedas e índices ('+MON_P[c][0]+').','info','País: '+c);
 route();
}

/* =============== Shell: navbar, sidebar, breadcrumb, notificaciones =============== */
const NAV=[
 {key:'param',label:'Parametrización',icon:'sliders',desc:'Flujo de órdenes, maestros, benchmarks y límites que alimentan el Front de inversiones.',home:'#/m/param',items:[['#/parametrizacion/flow','Flujo de órdenes','flows','pflow','Estados de una orden y las acciones permitidas en cada uno.'],['#/parametrizacion/portfolios','Portafolios','pie','pport','Fondos, mandatos y clientes sobre los que se opera.'],['#/parametrizacion/instruments','Instrumentos','coins','instruments','Consulta, registra y administra los instrumentos disponibles.'],['#/parametrizacion/indices','Índices de referencia','network','pindex','Índices que componen los benchmarks.'],['#/parametrizacion/benchmarks','Benchmarks','sliders','pabench','Composición del benchmark de cada portafolio.'],['#/parametrizacion/counterparties','Contrapartes y cupos','network','pcp','Entidades de mercado monetario y su cupo autorizado.'],['#/parametrizacion/rates','Tasas de referencia','scale','prates','Tasas de mercado para valorar y comparar el desempeño.'],['#/parametrizacion/limits','Configuración de límites','limits','limitcfg','Límites por emisor, calificación, moneda y plazo.'],['#/parametrizacion/catalogs','Catálogos','doc','pcat','Emisores, calificaciones, monedas y tipos de límite.']]},
 {key:'dashboard',label:'Dashboard',icon:'dashboard',desc:'Consulta de portafolios, flujos y sensibilidades.',home:'#/m/dashboard',items:[['#/dashboard/graphics','Visor de portafolio','pie','graphics','Consulta gráficas interactivas por portafolio.'],['#/dashboard/future-flows','Flujos futuros','flows','flows','Revisa los flujos proyectados por instrumento.'],['#/dashboard/sensitivity-measures','Medidas de sensibilidad','network','sens','Analiza duración, convexidad y DV01.'],['#/dashboard/money-market','Mercado monetario','coins','mmpos','Posición, vencimientos y devengo de las operaciones monetarias.']]},
 {key:'orders',label:'Ordenes',icon:'orders',desc:'Captura y gestión de órdenes de renta fija, renta variable y mercado monetario, y su libro de órdenes.',home:'#/m/orders',items:[['#/orders/fixed-income','Renta fija','colinc','fixed','Opera y administra inversiones en instrumentos de deuda.'],['#/orders/variable-income','Renta variable','col','variable','Opera y administra inversiones en acciones.'],['#/orders/money-market','Mercado monetario','coins','mm','Opera depósitos a término, repos, interbancarios y overnight con control de cupo.'],['#/orders/reports','Reportes','doc','oreports','Libro de órdenes de todos los mercados, listo para descargar.']]},
 {key:'limits',label:'Control de límites',icon:'limits',desc:'Seguimiento del cumplimiento de los límites definidos en Parametrización.',home:'#/m/limits',items:[['#/limit-control/limit-evaluation','Evaluación','badge','limiteval','Evalúa el cumplimiento de los límites.']]},
 {key:'pa',label:'Performance attribution',icon:'pa',desc:'Mide, explica y reporta el desempeño de portafolios y mandatos frente a su benchmark.',home:'#/m/pa',items:[['#/performance-attribution/summary','Resumen de desempeño','pa','pasummary','Rentabilidad, riesgo y comparación contra el benchmark.'],['#/performance-attribution/brinson','Atribución de retorno','scale','pabrinson','Asignación, selección e interacción (Brinson-Fachler).'],['#/performance-attribution/contribution','Contribución por activo','layers','pacontrib','Qué posiciones suman o restan al retorno.'],['#/performance-attribution/fixed-income','Atribución renta fija','colinc','pafixed','Curva, spread y selección en renta fija.'],['#/performance-attribution/money-market','Atribución mercado monetario','coins','pamm','Devengo, plazo, contraparte y liquidez en operaciones monetarias.'],['#/performance-attribution/reports','Reportes','doc','pareports','Genera y descarga los informes de desempeño.']]},

];
const S={hash:'',pais:'Colombia',token:0,open:{}};
function current(){const h=S.hash||location.hash||'#/';let grp=null,it=null,land=null;NAV.forEach(g=>{if(g.home===h)land=g;g.items.forEach(i=>{if(i[0]===h){grp=g;it=i}})});return {h,grp,it,land,home:h==='#/'||h===''||h==='#'}}
function go(h){S.hash=h;try{history.replaceState(null,'',h)}catch(e){}route()}
window.__go=go;
function crumbHTML(r){const parts=[];parts.push('<a class="crumb" data-go="#/">'+MODULE_NAME+'</a>');if(r.grp||r.land){const g=r.grp||r.land;parts.push(r.it?'<a class="crumb" data-go="'+g.home+'">'+g.label+'</a>':'<span class="current">'+g.label+'</span>')}if(r.it)parts.push('<span class="current">'+r.it[1]+'</span>');if(r.home)return '<span class="current">'+MODULE_NAME+'</span>';return parts.join('<span class="sep">›</span>')}
function sidebarNav(r){return '<a class="mk-navitem'+(r.home?' active':'')+'" data-go="#/" href="#/">'+ic('home')+' '+MODULE_NAME+'</a><div class="mk-navgroup">Módulos del dominio</div>'+NAV.map(g=>{const open=S.open[g.key]!==undefined?S.open[g.key]:(r.grp===g||r.land===g),cls=(r.land===g?' active':r.grp===g?' mk-navitem--parent':'')+(open?' open':'');return '<a class="mk-navitem'+cls+'" data-go="'+g.home+'" href="'+g.home+'" aria-expanded="'+open+'">'+ic(g.icon)+' '+g.label+'<span class="mk-tree__chev" data-tg="'+g.key+'" role="button" tabindex="0" aria-label="Mostrar u ocultar '+g.label+'">'+ic('chevron')+'</span></a>'+(open?'<div class="mk-subnav">'+g.items.map(i=>'<a class="mk-navitem mk-navitem--sub'+(r.h===i[0]?' active':'')+'" data-go="'+i[0]+'" href="'+i[0]+'">'+ic(i[2])+' '+i[1]+'</a>').join('')+'</div>':'')}).join('')}
const NOTIFS=[['warn','Límite de emisor al 92%','FIC LIQUIDEZ se acerca al tope del 20% definido para FINDETER.','Límites','Advertencia','lim-014',1],['info','Orden pendiente de complementación','Orden de compra de TES sobre FIC RENTA FIJA requiere completar la tasa.','Órdenes','Informativo','ord-231',1],['ok','Reporte mensual generado','El informe de rentabilidad de septiembre está listo para descargar.','Reportes','Exitoso','rep-001',1],['err','Falló la carga de instrumentos','El archivo tiene 3 filas con ISIN inválido.','Importación','Error','imp-008',0],['warn','Cupo de contraparte al 93%','BANCOLOMBIA S.A. está cerca de su cupo autorizado de $7.200 M en mercado monetario.','Límites','Advertencia','cup-021',1],['info','CDT próximo a vencer','Vence en 12 días un CDT de FIC MONETARIO con BANCOLOMBIA S.A.; revisa el rollover.','Órdenes','Informativo','mm-044',1],['ok','Benchmark actualizado','Se actualizó la composición del benchmark de FIC RENTA FIJA.','Performance','Exitoso','bch-003',0]];
function ntfRender(){const t=$('#ntfTipo').value,e=$('#ntfEstado').value,list=NOTIFS.filter(n=>(!t||n[3]===t)&&(!e||n[4]===e));$('#ntfList').innerHTML=list.length?list.map(n=>'<div class="mk-ncard'+(n[6]?' unread':'')+'"><div class="mk-ncard__top"><span class="mk-ncard__ico mk-ncard__ico--'+n[0]+'">'+ic(n[0]==='err'?'alert':n[0]==='ok'?'check':'info')+'</span><div><div class="mk-ncard__t">'+loc(n[1])+'</div><div class="mk-ncard__d">'+loc(n[2])+'</div></div></div><div class="mk-ncard__meta"><span class="mk-ncard__tag">'+n[3]+'</span><span>'+n[5]+'</span></div>'+(n[6]?'<span class="mk-ncard__unread"></span>':'')+'</div>').join(''):'<div class="mk-empty">Sin notificaciones</div>';const d=$('#ntfDot');const c=NOTIFS.filter(n=>n[6]).length;d.textContent=c;d.style.display=c?'':'none'}
function ntfToggle(open){$('#ntfPanel').classList.toggle('open',open);$('#ntfOverlay').classList.toggle('open',open)}
function sbToggle(open){$('#mkSidebar').classList.toggle('open',open);$('#mkOverlay').classList.toggle('open',open)}
function shell(){
 $('#root').innerHTML='<header class="mk-navbar"><button class="mk-navbar__burger" id="burger"'+TIP('Abrir el menú de módulos')+' aria-label="Menú">'+ic('menu')+'</button><div class="mk-brand"><b>makers</b> Platform | '+MODULE_NAME+'</div><span style="margin-left:auto;position:relative"><button class="mk-bell" id="bell" style="margin-left:0"'+TIP('Centro de Notificaciones')+' aria-label="Centro de Notificaciones">'+ic('bell')+'<span class="mk-bell__dot" id="ntfDot">3</span></button></span><span class="mk-country" style="margin-left:12px"><span class="mk-country__lb">País</span><span style="position:relative;display:inline-flex;align-items:center"><select id="pais" aria-label="País en el que opera la Plataforma"><option>Colombia</option><option>Chile</option><option>República Dominicana</option></select><span class="mk-country__chev">'+ic('chevron')+'</span></span></span><button class="mk-bell" id="theme" type="button" style="margin-left:12px"></button></header>'
 +'<div class="mk-overlay" id="ntfOverlay"></div><aside class="mk-notif mk-drawer" id="ntfPanel" aria-label="Centro de Notificaciones"><div class="mk-notif__head"><h2>Centro de Notificaciones</h2><div class="mk-notif__mail">'+esc(USER.email)+'</div><button class="mk-notif__close" id="ntfClose" aria-label="Cerrar">&times;</button></div><div class="mk-notif__filtros"><div class="mk-field"><label class="mk-label"><span>Tipo</span>'+info('Proceso de la Plataforma que originó el aviso.')+'</label><div class="mk-combobox"><select class="mk-select" id="ntfTipo"><option value="">Todos</option><option>Reportes</option><option>Límites</option><option>Órdenes</option><option>Importación</option><option>Performance</option></select></div></div><div class="mk-field"><label class="mk-label"><span>Estado</span>'+info('Resultado del proceso: exitoso, informativo, advertencia o error.')+'</label><div class="mk-combobox"><select class="mk-select" id="ntfEstado"><option value="">Todos</option><option>Exitoso</option><option>Informativo</option><option>Advertencia</option><option>Error</option></select></div></div><button class="mk-btn" id="ntfGo">Consultar</button></div><div class="mk-notif__list" id="ntfList"></div></aside>'
 +'<nav class="mk-breadcrumb" id="mkBreadcrumb"></nav><div class="mk-overlay" id="mkOverlay"></div><aside class="mk-sidebar" id="mkSidebar"><div class="mk-sidebar__head"><div class="mk-sidebar__name">'+esc(USER.name)+'</div><div class="mk-sidebar__mail">'+esc(USER.email)+'</div><button class="mk-sidebar__close" id="sbClose" aria-label="Cerrar menú">&times;</button></div><nav class="mk-sidebar__nav" id="sbNav"></nav><div class="mk-sidebar__foot"><a href="#" id="logout">Cerrar sesión</a></div></aside><main class="mk-page" id="mkMain"><section class="mk-view active" id="view"></section></main><div class="mk-sonner" id="mkSonner" aria-live="polite"></div><div id="mkTip" role="tooltip"></div>';
 $('#burger').addEventListener('click',()=>sbToggle(true));$('#mkOverlay').addEventListener('click',()=>sbToggle(false));$('#sbClose').addEventListener('click',()=>sbToggle(false));
 $('#bell').addEventListener('click',()=>{ntfRender();ntfToggle(true)});$('#ntfOverlay').addEventListener('click',()=>ntfToggle(false));$('#ntfClose').addEventListener('click',()=>ntfToggle(false));$('#ntfGo').addEventListener('click',ntfRender);ntfRender();
 $('#pais').addEventListener('change',e=>applyCountry(e.target.value));
 $('#theme').addEventListener('click',()=>{const d=document.documentElement.classList.toggle('dark');try{localStorage.setItem('mkTheme',d?'dark':'light')}catch(x){}themeIcon()});themeIcon();
 $('#logout').addEventListener('click',e=>{e.preventDefault();sbToggle(false);toast('Esta es una sesión de demostración.','info')});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){sbToggle(false);ntfToggle(false)}});
}
function themeIcon(){const d=document.documentElement.classList.contains('dark'),b=$('#theme');if(!b)return;b.innerHTML=ic(d?'sun':'moon');b.setAttribute('data-tip',d?'Cambiar a tema claro':'Cambiar a tema oscuro');b.setAttribute('aria-label',d?'Cambiar a tema claro':'Cambiar a tema oscuro')}
function landing(view,g){
 view.innerHTML='<div class="mk-section"><div class="mk-headerpage"><div><h1>'+g.label+'</h1><div class="mk-help">'+g.desc+'</div></div><div><button class="mk-iconbtn mk-iconbtn--dark" data-back'+TIP('Volver a '+MODULE_NAME)+' aria-label="Volver">'+ic('back')+'</button></div></div><div class="mk-grid cols-4">'+g.items.map(i=>'<a class="mk-linkcard" href="'+i[0]+'" data-go="'+i[0]+'"><span class="mk-linkcard__icon">'+ic(i[2],'lg')+'</span><span class="mk-linkcard__title">'+i[1]+'</span><span class="mk-linkcard__sub">'+i[4]+'</span></a>').join('')+'</div></div>';
 $('[data-back]',view).addEventListener('click',()=>go('#/'));
}
function homePage(view){
 view.innerHTML='<div class="mk-section"><div class="mk-headerpage"><h1>'+MODULE_NAME+'</h1></div><p class="mk-help mk-mb">Consulta de portafolios, operación de órdenes de inversión (renta fija, renta variable y mercado monetario), control de límites y análisis de desempeño (Performance attribution).</p>'+NAV.map((g,k)=>'<div class="mk-accordion collapsed" id="acc-'+g.key+'"><div class="mk-accordion__head"><span class="mk-accordion__ico">'+ic(g.icon,'lg')+'</span><span><span class="mk-accordion__t">'+g.label+'</span><span class="mk-accordion__d">'+g.desc+'</span></span><span class="mk-accordion__chev">&#9662;</span></div><div class="mk-accordion__body"><div class="mk-grid cols-4">'+g.items.map(i=>'<a class="mk-linkcard" href="'+i[0]+'" data-go="'+i[0]+'"><span class="mk-linkcard__icon">'+ic(i[2],'lg')+'</span><span class="mk-linkcard__title">'+i[1]+'</span><span class="mk-linkcard__sub">'+i[4]+'</span></a>').join('')+'</div></div></div>').join('')+'</div>';
 $$('.mk-accordion',view).forEach(bindAcc);
}
function notFound(view){view.innerHTML='<div class="mk-section"><div class="mk-notfound"><h2>404</h2><h3 style="color:var(--mk-primary)">Página no encontrada</h3><p>No pudimos encontrar la página que estás buscando. Verifica la URL o vuelve al inicio.</p><button class="mk-btn" data-go="#/">Volver al inicio</button></div></div>'}
function route(){
 if(!$('#view'))shell();
 const r=current();$('#mkBreadcrumb').innerHTML=crumbHTML(r);$('#sbNav').innerHTML=sidebarNav(r);sbToggle(false);
 hideTip();$$('.mk-modal-overlay').forEach(m=>m.remove());const v=$('#view'),tk=++S.token;window.scrollTo(0,0);v.innerHTML='<div class="mk-loading"><div class="mk-spinner"></div></div>';
 setTimeout(()=>{if(tk!==S.token)return;if(r.it)PAGES[r.it[3]](v,r);else if(r.land)landing(v,r.land);else if(r.home)homePage(v);else notFound(v);v.classList.remove('active');void v.offsetWidth;v.classList.add('active')},180);
}
document.addEventListener('click',e=>{const t=e.target.closest('[data-tg]');if(t){e.preventDefault();e.stopPropagation();const k=t.dataset.tg,r=current(),auto=(r.grp&&r.grp.key===k)||(r.land&&r.land.key===k),cur=S.open[k]!==undefined?S.open[k]:auto;S.open[k]=!cur;document.getElementById('sbNav').innerHTML=sidebarNav(r);return}const a=e.target.closest('[data-go]');if(a){e.preventDefault();go(a.dataset.go)}});
window.addEventListener('hashchange',()=>{S.hash='';route()});
window.__mk={contributions,brinson,perfStats,fiAttr,mmAttr,evalRows,holdingsFor,cpUsed,mmCalc,get NAV(){return NAV},get PAGES(){return PAGES},get S(){return S},get CTRY(){return CTRY},get DS(){return DS},MASS,buildXlsx,buildBook,exportTable,readXlsx,parseCSV,demoCsv,zipStore,applyCountry,reportData,mmCalc,cpUsed,bookRows,files:id=>{const m=MASS[id];return {nombre:m.nombre,pre:m.pre||'',head:m.cols.map(c=>c[0]),rows:m.demo(),xlsx:buildXlsx(m,m.demo()),csv:demoCsv(m),estructura:buildXlsx(m)}}};
try{if(localStorage.getItem('mkTheme')==='dark')document.documentElement.classList.add('dark')}catch(e){}
route();
})();
